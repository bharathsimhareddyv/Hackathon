======================================================================
  JS-15  |  JavaScript  |  Daily Needs Mart
======================================================================

File to fix      : script.js
Errors hidden    : 52
Difficulty       : 39 / 100   (Easy 26, Medium 21, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 26
  ReferenceError                           x 8
  Logic Error                              x 5
  Function / Return Error                  x 4
  Loop Error                               x 3
  TypeError                                x 2
  String Method Error                      x 2
  Object / Class Error                     x 1
  JSON Error                               x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * String Method Error
    ${ } only works inside backticks ` `. Check string method names (trim, toUpperCase).

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * JSON Error
    JSON keys need double quotes and there must be no comma before }. Use JSON.parse() to read it.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 12         Task 1                           2  (Object / Class Error, SyntaxError)
  13 - 22        Task 2                           4  (Function / Return Error, Loop Error, SyntaxError, TypeError)
  23 - 28        Task 3                           3  (SyntaxError)
  29 - 38        Task 4                           3  (SyntaxError)
  39 - 47        Task 5                           4  (Logic Error, SyntaxError, TypeError)
  48 - 53        Task 6                           2  (ReferenceError, SyntaxError)
  54 - 59        Task 7                           1  (String Method Error)
  60 - 70        Task 8                           4  (Function / Return Error, SyntaxError)
  71 - 83        Task 9                           4  (Function / Return Error, ReferenceError, SyntaxError)
  84 - 89        Task 10                          2  (Logic Error, SyntaxError)
  96 - 101       Task 12                          1  (Function / Return Error)
  102 - 109      Task 13                          3  (Logic Error, ReferenceError, SyntaxError)
  110 - 125      Task 14                          3  (ReferenceError, SyntaxError)
  126 - 134      Task 15                          3  (Loop Error, ReferenceError, SyntaxError)
  135 - 141      Task 16                          2  (ReferenceError, String Method Error)
  142 - 147      Task 17                          2  (JSON Error, SyntaxError)
  148 - 153      Task 18                          1  (Logic Error)
  154 - 160      Task 19                          2  (ReferenceError)
  161 - 166      Task 20                          2  (Logic Error, SyntaxError)
  167 - 175      Task 21                          4  (Loop Error, SyntaxError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
