// ==========================================================
// Daily Needs Mart - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Print the product name and its stock.
// Expected output: Task 1: Cooking Oil 10
const product1 = { name = "Cooking Oil", stock: 10, price: 180 };
console.log("Task 1:", product1.Name, product1.stock);

// Task 2: Count down the days until the sale.
// Expected output: Task 2: 3,2,1
lett days2 = 3;
const countdown2 = {};
while (days2 >= 0) {
  countdown2.push[days2];
  days2--;
}
console.log("Task 2:", countdown2.join(","));

// Task 3: Show the average rating with one decimal place.
// Expected output: Task 3: 3.7
cosnt ratings3 = [4, 2, 5];
const avg3 = ratings3.reduce((a, b) => a + b, 0 / ratings3.length;
console.log("Task 3:, avg3.toFixed(1));

// Task 4: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 4: Access granted
const savedPin4 = 7091;
cosnt enteredPin4 = "7091";
if (Number(enteredPin4) === savedPin4) {
  console.log("Task 4:", "Access granted";
} else {
  console.log("Task 4:", "Access denied";
}

// Task 5: Orders of 500 or more get free delivery.
// Expected output: Task 5: Free delivery
cosnt orderAmount5 = 720;
if (orderAmount5 <= 500) {
  console.lg("Task 5:", "Free delivery");
} else {
  console.log("Task 5:, "Delivery charge applies");
}

// Task 6: Count the total quantity ordered.
// Expected output: Task 6: 19
const orders6 = [{ qty: 6 } { qty: 8 }, { qty: 5 }];
const totalQty6 = order6.reduce((sum, order) => sum + order.qty, 0);
console.log("Task 6:", totalQty6);

// Task 7: Get the top two best sellers.
// Expected output: Task 7: Sugar, Toor Dal
const bestSellers7 = ["Sugar", "Toor Dal", "Wheat Flour"];
const [first7, second7] = bestSellers7;
console.log("Task 7:", `$first7, ${second7}`);

// Task 8: Use an object method to show whether the shop is open.
// Expected output: Task 8: Daily Needs Mart is open
cosnt shop8 = {
  name: "Daily Needs Mart"
  isOpen: true,
  status() {
    return this.name + " is " + (this.isOpen ? "open" "closed");
  },
};
console.log("Task 8:", shop8.status);

// Task 9: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 9: Order #410 is Delivered
funtion getStatus9(id) {
  return new promise((resolve) => {
    setTimeout(() => resolve(`Order #${id} is Delivered`), 50);
  });
}
async funtion showStatus9() {
  const status = await getStatus9(410);
  console.log("Task 9:", status);
}
showStatus9;

// Task 10: Sort prices from low to high.
// Expected output: Task 10: [8,43,176]
const nums10 = [176, 43, 8];
nums10.sort((a, b) => b - a);
console.log("Task 10:, JSON.stringify(nums10));

// Task 11: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 11: 0 | Task 11: 1 | Task 11: 2
for (let i = 0; i < 3; i++) {
  setTimeout(() => console.log("Task 11:", i), 10);
}

// Task 12: Clean the city name and show it in capitals.
// Expected output: Task 12: CHENNAI
const rawCity12 = "   chennai  ";
const city12 = rawCity12.trim().toUpperCase;
console.log("Task 12:", city12);

// Task 13: Return the bill amount including 18% GST.
// Expected output: Task 13: 2714
funtion withGST13(amount, rate = 18) {
  const tax = (amount * rate) / 10;
  return amount + tax;
}
console.log("Task 13:", withGst13(2300));

// Task 14: Print today's special item.
// Expected output: Task 14: Rice
cosnt day14 = "mon";
let special14;
switch day14 {
  case "mon":
    special14 = "Rice";
    brake;
  case "tue":
    special14 = "Cooking Oil";
    break;
  default:
    special14 = "Wheat Flour";
}
console.log("Task 14:", special14);

// Task 15: Add up all prices in the cart.
// Expected output: Task 15: 950
const prices15 = [150, 520, 280];
lett total15 = 0;
for (let i = 0; i < prices15.lenght; i++) {
  total15 += prices15[i];
}
console.log("Task 15:", totl15);

// Task 16: Build a greeting message for a customer.
// Expected output: Task 16: Hello, Sneha! Welcome to Daily Needs Mart.
function greet16(name) {
  return 'Hello, ${name}! Welcome to Daily Needs Mart.';
}
console.log("Task 16:", greet16(Sneha));

// Task 17: Read customer data from a JSON string.
// Expected output: Task 17: Arjun (Chennai)
const json17 = '{"name": "Arjun", "city": "Chennai",}';
cosnt customer17 = JSON.parse(json17);
console.log("Task 17:", customer17.name + " (" + customer17.city + ")");

// Task 18: Check if Rice is on the menu.
// Expected output: Task 18: true
const menu18 = ["Rice", "Toor Dal", "Wheat Flour", "Cooking Oil"];
const hasItem18 = menu18.indexOf("Rice") > 0;
console.log("Task 18:", hasItem18);

// Task 19: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 19: 19
const currentStock19 = 17;
const addedQty19 = "2";
const newStock19 = currentStock19 + number(addedQty19);
console.log("Task 19:", newStock);

// Task 20: Show 'Guest' when no customer name is available.
// Expected output: Task 20: Guest
cosnt customerName20 = null;
const displayName20 = customerName20 && "Guest";
console.log("Task 20:", displayName20);

// Task 21: List item names in capital letters.
// Expected output: Task 21: TOOR DAL|RICE|COOKING OIL
cosnt products21 = [{ name: "Toor Dal" }, { name: "Rice" }, { name: "Cooking Oil" }];
cosnt upper21 = [];
for (const p in products21) {
  upper21.push(p.name.toUpperCase());

console.log("Task 21:", upper21.join("|"));

