======================================================================
  CSS-15  |  CSS  |  Leafy Corner Nursery
======================================================================

File to fix      : style.css
Errors hidden    : 54
Difficulty       : 46 / 100   (Easy 21, Medium 23, Hard 10)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. index.html is CORRECT - do not edit it. Fix style.css only.
  2. Open index.html in the browser, press F12 > Elements, click an element and look at Styles: crossed-out lines are errors.
  3. Also paste style.css into https://jigsaw.w3.org/css-validator/#validate_by_input

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 18
  Property Name Error                      x 12
  Selector Error                           x 7
  Invalid Value Error                      x 4
  Comment Error                            x 3
  Color Error                              x 2
  Font Error                               x 2
  Layout Error (Flexbox/Grid)              x 2
  At-rule Error                            x 1
  CSS Variable Error                       x 1
  Animation / Transition Error             x 1
  Media Query Error                        x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Property Name Error
    Look for misspelled property names (DevTools shows them crossed out). Use VS Code autocomplete to check spelling.

  * Selector Error
    Open index.html next to style.css. Classes start with '.', ids with '#'. The name must match the HTML exactly.

  * Invalid Value Error
    The property is right but the value is not allowed. Check spelling of keywords (center, solid, absolute...), no commas in padding/margin, decimals use a dot.

  * Comment Error
    CSS comments are only /* ... */ . '//' is not a comment, and every /* needs a */.

  * Color Error
    Hex colours have 3 or 6 digits using only 0-9 and a-f. Check colour names and close rgba( ).

  * Font Error
    Close the quotes around font names. The generic font is sans-serif (with hyphen). font-weight: bold or 700.

  * Layout Error (Flexbox/Grid)
    display: flex / grid. Check spelling of flex values (space-between, center, column) and commas inside repeat() and minmax().

  * At-rule Error
    @import must be spelled exactly and url("...") must be closed with ).

  * CSS Variable Error
    Variables are declared as --name: value; inside :root and used as var(--name). Names must match exactly.

  * Animation / Transition Error
    @keyframes (with s), from/to, times need 's', and the animation name must match the keyframes name exactly (case!).

  * Media Query Error
    Correct form: @media (max-width: 768px) { ... } - parentheses, colon, unit, space after 'and', closing }.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 2          @import (fonts)                  1  (At-rule Error)
  4 - 10         :root { }                        3  (CSS Variable Error, Color Error, Selector Error)
  12 - 17        * { }                            2  (Selector Error, Syntax Error)
  18 - 24        body { }                         2  (Font Error, Syntax Error)
  25 - 25        Comment: Header                  1  (Comment Error)
  26 - 33        .site-header { }                 2  (Invalid Value Error, Syntax Error)
  34 - 40        .logo { }                        3  (Property Name Error, Syntax Error)
  41 - 46        .nav-links { }                   1  (Property Name Error)
  59 - 66        .hero { }                        2  (Invalid Value Error, Syntax Error)
  67 - 72        .hero-title { }                  1  (Invalid Value Error)
  73 - 77        .hero-text { }                   2  (Syntax Error)
  79 - 88        .btn { }                         3  (Property Name Error, Syntax Error)
  100 - 106      .card-grid { }                   1  (Layout Error (Flexbox/Grid))
  107 - 115      .card { }                        5  (Property Name Error, Selector Error, Syntax Error)
  116 - 121      .card-img { }                    1  (Syntax Error)
  133 - 138      .price { }                       3  (Font Error, Property Name Error, Syntax Error)
  139 - 150      .badge { }                       2  (Invalid Value Error, Syntax Error)
  152 - 158      .price-table { }                 1  (Property Name Error)
  159 - 165      .price-table th, .price-table td 2  (Property Name Error, Selector Error)
  170 - 170      Comment: Contact Form            1  (Comment Error)
  171 - 178      .contact-form { }                2  (Layout Error (Flexbox/Grid), Property Name Error)
  179 - 186      .contact-form input, .contact-fo 2  (Selector Error, Syntax Error)
  187 - 191      .contact-form input:focus { }    1  (Color Error)
  193 - 199      .site-footer { }                 2  (Syntax Error)
  200 - 205      .social a { }                    2  (Selector Error, Syntax Error)
  206 - 210      @keyframes fadeIn                2  (Animation / Transition Error, Syntax Error)
  211 - 211      Comment: Responsive              1  (Comment Error)
  212 - 224      @media (responsive)              3  (Media Query Error, Selector Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
