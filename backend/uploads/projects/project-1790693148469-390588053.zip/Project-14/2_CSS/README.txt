======================================================================
  CSS-14  |  CSS  |  WoodWorks Furniture
======================================================================

File to fix      : style.css
Errors hidden    : 54
Difficulty       : 50 / 100   (Easy 15, Medium 28, Hard 11)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. index.html is CORRECT - do not edit it. Fix style.css only.
  2. Open index.html in the browser, press F12 > Elements, click an element and look at Styles: crossed-out lines are errors.
  3. Also paste style.css into https://jigsaw.w3.org/css-validator/#validate_by_input

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 13
  Property Name Error                      x 12
  Selector Error                           x 5
  Color Error                              x 4
  Layout Error (Flexbox/Grid)              x 4
  Unit Error                               x 4
  Pseudo-class / Pseudo-element Error      x 3
  CSS Variable Error                       x 2
  Animation / Transition Error             x 2
  Comment Error                            x 2
  Invalid Value Error                      x 2
  Media Query Error                        x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Property Name Error
    Look for misspelled property names (DevTools shows them crossed out). Use VS Code autocomplete to check spelling.

  * Selector Error
    Open index.html next to style.css. Classes start with '.', ids with '#'. The name must match the HTML exactly.

  * Color Error
    Hex colours have 3 or 6 digits using only 0-9 and a-f. Check colour names and close rgba( ).

  * Layout Error (Flexbox/Grid)
    display: flex / grid. Check spelling of flex values (space-between, center, column) and commas inside repeat() and minmax().

  * Unit Error
    Numbers need a unit (px, rem, %, s, deg) with NO space: 12px not 12 px. z-index and font-weight have NO unit.

  * Pseudo-class / Pseudo-element Error
    :hover :focus :nth-child() use ONE colon; ::before ::after use TWO. Check spelling.

  * CSS Variable Error
    Variables are declared as --name: value; inside :root and used as var(--name). Names must match exactly.

  * Animation / Transition Error
    @keyframes (with s), from/to, times need 's', and the animation name must match the keyframes name exactly (case!).

  * Comment Error
    CSS comments are only /* ... */ . '//' is not a comment, and every /* needs a */.

  * Invalid Value Error
    The property is right but the value is not allowed. Check spelling of keywords (center, solid, absolute...), no commas in padding/margin, decimals use a dot.

  * Media Query Error
    Correct form: @media (max-width: 768px) { ... } - parentheses, colon, unit, space after 'and', closing }.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  4 - 10         :root { }                        3  (CSS Variable Error, Color Error, Selector Error)
  18 - 24        body { }                         3  (CSS Variable Error, Color Error, Syntax Error)
  26 - 33        .site-header { }                 2  (Layout Error (Flexbox/Grid))
  34 - 40        .logo { }                        1  (Unit Error)
  41 - 46        .nav-links { }                   2  (Syntax Error)
  47 - 52        .nav-links a { }                 2  (Property Name Error, Syntax Error)
  53 - 57        .nav-links a:hover { }           1  (Property Name Error)
  59 - 66        .hero { }                        2  (Syntax Error, Unit Error)
  73 - 77        .hero-text { }                   2  (Animation / Transition Error, Property Name Error)
  79 - 88        .btn { }                         2  (Property Name Error, Selector Error)
  89 - 93        .btn:hover { }                   1  (Color Error)
  99 - 99        Comment: Product Cards           1  (Comment Error)
  100 - 106      .card-grid { }                   5  (Layout Error (Flexbox/Grid), Property Name Error, Syntax Error)
  107 - 115      .card { }                        2  (Invalid Value Error, Property Name Error)
  122 - 127      .card-title { }                  1  (Property Name Error)
  128 - 132      .card-title::before { }          2  (Invalid Value Error, Pseudo-class / Pseudo-element Error)
  133 - 138      .price { }                       1  (Selector Error)
  139 - 150      .badge { }                       2  (Property Name Error)
  152 - 158      .price-table { }                 2  (Property Name Error, Syntax Error)
  159 - 165      .price-table th, .price-table td 3  (Color Error, Selector Error, Syntax Error)
  166 - 169      .price-table tr:nth-child(even)  1  (Pseudo-class / Pseudo-element Error)
  171 - 178      .contact-form { }                1  (Property Name Error)
  179 - 186      .contact-form input, .contact-fo 1  (Syntax Error)
  187 - 191      .contact-form input:focus { }    1  (Pseudo-class / Pseudo-element Error)
  193 - 199      .site-footer { }                 1  (Syntax Error)
  200 - 205      .social a { }                    1  (Syntax Error)
  206 - 210      @keyframes fadeIn                1  (Animation / Transition Error)
  211 - 211      Comment: Responsive              1  (Comment Error)
  212 - 224      @media (responsive)              6  (Layout Error (Flexbox/Grid), Media Query Error, Selector Error, Syntax Error, Unit Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
