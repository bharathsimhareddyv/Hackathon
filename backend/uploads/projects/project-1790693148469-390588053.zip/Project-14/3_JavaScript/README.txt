======================================================================
  JS-14  |  JavaScript  |  FixIt Mobile Care
======================================================================

File to fix      : script.js
Errors hidden    : 52
Difficulty       : 39 / 100   (Easy 26, Medium 21, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 26
  ReferenceError                           x 8
  Logic Error                              x 4
  Function / Return Error                  x 3
  Object / Class Error                     x 3
  JSON Error                               x 2
  Loop Error                               x 2
  String Method Error                      x 1
  TypeError                                x 1
  Array Method Error                       x 1
  Type Coercion Error                      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * JSON Error
    JSON keys need double quotes and there must be no comma before }. Use JSON.parse() to read it.

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * String Method Error
    ${ } only works inside backticks ` `. Check string method names (trim, toUpperCase).

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Array Method Error
    map() makes a new array (forEach doesn't). sort numbers with (a, b) => a - b. Give reduce a starting value 0.

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 13         Task 1                           1  (SyntaxError)
  14 - 19        Task 2                           2  (JSON Error)
  20 - 25        Task 3                           2  (String Method Error, SyntaxError)
  26 - 33        Task 4                           4  (Function / Return Error, SyntaxError)
  34 - 39        Task 5                           2  (Logic Error, SyntaxError)
  40 - 45        Task 6                           2  (ReferenceError, SyntaxError)
  46 - 51        Task 7                           3  (Object / Class Error, SyntaxError)
  52 - 59        Task 8                           2  (Logic Error, ReferenceError)
  60 - 69        Task 9                           2  (SyntaxError)
  70 - 76        Task 10                          1  (ReferenceError)
  77 - 85        Task 11                          4  (SyntaxError)
  86 - 91        Task 12                          1  (ReferenceError)
  92 - 100       Task 13                          4  (Logic Error, Loop Error, SyntaxError)
  101 - 114      Task 14                          5  (Object / Class Error, ReferenceError, SyntaxError, TypeError)
  115 - 123      Task 15                          5  (Logic Error, Loop Error, SyntaxError)
  124 - 129      Task 16                          3  (Array Method Error, SyntaxError)
  136 - 148      Task 18                          3  (Function / Return Error, ReferenceError)
  149 - 153      Task 19                          2  (SyntaxError)
  154 - 164      Task 20                          1  (Function / Return Error)
  165 - 171      Task 21                          3  (ReferenceError, SyntaxError, Type Coercion Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
