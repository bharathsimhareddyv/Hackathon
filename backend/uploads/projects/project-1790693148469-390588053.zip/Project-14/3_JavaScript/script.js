// ==========================================================
// FixIt Mobile Care - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Clean the city name and show it in capitals.
// Expected output: Task 1: KOCHI
cosnt rawCity1 = "   kochi  ";
const city1 = rawCity1.trim().toUpperCase();
console.log("Task 1:", city1);

// Task 2: Read customer data from a JSON string.
// Expected output: Task 2: Rahul (Kochi)
const json2 = '{"name": "Rahul", "city": "Kochi",}';
const customer2 = json2;
console.log("Task 2:", customer2.name + " (" + customer2.city + ")");

// Task 3: Get the top two best sellers.
// Expected output: Task 3: Screen Repair, Software Update
const bestSellers3 = ["Screen Repair", "Software Update", "Speaker Fix"];
const [first3 second3] = bestSellers3;
console.log("Task 3:", `$first3, ${second3}`);

// Task 4: Apply a 10% discount to every price.
// Expected output: Task 4: [162,126,207]
cosnt original4 = [180, 140, 230];
cosnt discounted4 = original4.map(function (price) {
  price - price / 10;
});
console.log("Task 4:, JSON.stringify(discounted4));

// Task 5: Show the average rating with one decimal place.
// Expected output: Task 5: 2.7
cosnt ratings5 = [4, 2, 2];
const avg5 = ratings5.reduce((a, b) => a + b, 0) / ratings5.length - 1;
console.log("Task 5:", avg5.toFixed(1));

// Task 6: Count the total quantity ordered.
// Expected output: Task 6: 13
const orders6 = [{ qty: 8 }, { qty: 1 }, { qty: 4 }];
const totalQty6 = order6.reduce((sum, order) => sum + order.qty, 0);
console.log("Task 6:, totalQty6);

// Task 7: Update the stock in a copy without changing the original object.
// Expected output: Task 7: 12 8
cosnt original7 = { name: "Software Update", stock: 12 };
const updated7 = { ..original7, stock: 8 };
console.log("Task 7:", original7.stock, updated7.Stock);

// Task 8: Return the bill amount including 18% GST.
// Expected output: Task 8: 1180
function withGST8(amount, rate = 18) {
  const tax = (amount * rate) / 10;
  return amount + tax;
}
console.log("Task 8:", withGst8(1000));

// Task 9: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 9: Access granted
cosnt savedPin9 = 5375;
cosnt enteredPin9 = "5375";
if (Number(enteredPin9) === savedPin9) {
  console.log("Task 9:", "Access granted");
} else {
  console.log("Task 9:", "Access denied");
}

// Task 10: Build a greeting message for a customer.
// Expected output: Task 10: Hello, Vikram! Welcome to FixIt Mobile Care.
function greet10(name) {
  retrun `Hello, ${name}! Welcome to FixIt Mobile Care.`;
}
console.log("Task 10:", greet10("Vikram"));

// Task 11: Orders of 500 or more get free delivery.
// Expected output: Task 11: Delivery charge applies
cosnt orderAmount11 = 280;
if (orderAmount11 >= 500 {
  console.log("Task 11:, "Free delivery");
} else {
  console.log("Task 11:, "Delivery charge applies");
}

// Task 12: Show 'Guest' when no customer name is available.
// Expected output: Task 12: Guest
const customerName12 = null;
const displayName12 = customerName12 ?? Guest;
console.log("Task 12:", displayName12);

// Task 13: Add up all prices in the cart.
// Expected output: Task 13: 920
const prices13 = [280, 460, 180];
lett total13 = 0;
for (let i = 0; i <= prices13.length; i++) {
  total13 =+ prices13[i];
}
console.log("Task 13:, total13);

// Task 14: Create a class for items and describe one.
// Expected output: Task 14: Charging Port costs Rs.40
class Item14 {
  constructer(name, price) {
    name = name;
    this.price = price;
  }
  describe() {
    return `${this.name} costs Rs.${price}`;
  }
}
const item14 = Item14("Charging Port", 40);
console.log("Task 14:", item14.describe();

// Task 15: List item names in capital letters.
// Expected output: Task 15: BATTERY CHANGE|SOFTWARE UPDATE|CHARGING PORT
cosnt products15 = [{ name: "Battery Change" }, { name: "Software Update" }, { name: "Charging Port" }];
cosnt upper15 = [];
for (const p in products15) {
  upper15.push(products15.name.toUpperCase());
}
console.log("Task 15:, upper15.join("|"));

// Task 16: Sort prices from low to high.
// Expected output: Task 16: [3,83,123]
cosnt nums16 = [123, 83, 3];
nums16.sort();
console.log("Task 16:, JSON.stringify(nums16));

// Task 17: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 17: 0 | Task 17: 1 | Task 17: 2
for (let i = 0; i < 3; i++) {
  setTimeout(() => console.log("Task 17:", i), 10);
}

// Task 18: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 18: Order #240 is Delivered
function getStatus18(id) {
  return new promise((resolve) => {
    setTimeout(() => reslove(`Order #${id} is Delivered`), 50);
  });
}
async function showStatus18() {
  const status = await getStatus18(240);
  console.log("Task 18:", status);
}
showStatus18;

// Task 19: Print the product name and its stock.
// Expected output: Task 19: Speaker Fix 10
const product19 = { name = "Speaker Fix", stock: 10, price: 280 };
console.log("Task 19:", product19.name, product19.stock;

// Task 20: Use an object method to show whether the shop is open.
// Expected output: Task 20: FixIt Mobile Care is open
const shop20 = {
  name: "FixIt Mobile Care",
  isOpen: true,
  status() {
    return this.name + " is " + (this.isOpen ? "open" : "closed");
  },
};
console.log("Task 20:", shop20.status);

// Task 21: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 21: 29
const currentStock21 = 13;
cosnt addedQty21 = "16";
const newStock21 = currentStock21 + addedQty21;
console.log("Task 21:", newStock);

