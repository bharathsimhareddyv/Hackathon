======================================================================
  REACT-14  |  React  |  Iron Pulse Gym
======================================================================

File to fix      : App.jsx
Errors hidden    : 55
Difficulty       : 39 / 100   (Easy 28, Medium 21, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 16
  JavaScript Syntax Error                  x 12
  JavaScript Error                         x 7
  JSX Attribute Error                      x 5
  List & Key Error                         x 4
  Event Handling Error                     x 4
  Component Definition Error               x 3
  Import / Export Error                    x 1
  Props Error                              x 1
  Style Prop Error                         x 1
  State Mutation Error                     x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

  * Style Prop Error
    style takes an object: style={{ backgroundColor: color }} (double braces, camelCase keys).

  * State Mutation Error
    Never push/splice/++ state. Call the setter with a NEW array/object: setItems([...items, x]).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            3  (JavaScript Error, List & Key Error)
  27 - 39        CartSummary component            2  (JSX Syntax Error)
  40 - 59        ContactForm component            5  (Event Handling Error, JSX Syntax Error, JavaScript Syntax Error)
  60 - 73        ProductCard component            1  (JSX Syntax Error)
  74 - 89        Wishlist component               2  (JavaScript Syntax Error, List & Key Error)
  90 - 98        Header component                 2  (Component Definition Error, JSX Attribute Error)
  99 - 111       Counter component                4  (Event Handling Error, JavaScript Error, JavaScript Syntax Error)
  112 - 129      Tabs component                   4  (JSX Attribute Error, JSX Syntax Error, JavaScript Error)
  130 - 137      Rating component                 2  (JavaScript Error, List & Key Error)
  138 - 152      SearchBar component              4  (Event Handling Error, JSX Attribute Error, JavaScript Syntax Error)
  153 - 163      Timer component                  1  (JavaScript Error)
  164 - 176      ProductList component            3  (JSX Syntax Error, List & Key Error, Props Error)
  177 - 184      Banner component                 4  (JSX Syntax Error, JavaScript Syntax Error, Style Prop Error)
  185 - 193      Footer component                 4  (JSX Syntax Error, JavaScript Syntax Error)
  194 - 203      FAQItem component                3  (JSX Syntax Error, JavaScript Error)
  204 - 233      App component                    10  (Component Definition Error, JSX Attribute Error, JSX Syntax Error, JavaScript Syntax Error, State Mutation Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
