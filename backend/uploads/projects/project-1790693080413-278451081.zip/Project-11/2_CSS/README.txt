======================================================================
  CSS-11  |  CSS  |  Frosty Scoops
======================================================================

File to fix      : style.css
Errors hidden    : 52
Difficulty       : 43 / 100   (Easy 22, Medium 23, Hard 7)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. index.html is CORRECT - do not edit it. Fix style.css only.
  2. Open index.html in the browser, press F12 > Elements, click an element and look at Styles: crossed-out lines are errors.
  3. Also paste style.css into https://jigsaw.w3.org/css-validator/#validate_by_input

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 19
  Property Name Error                      x 10
  Invalid Value Error                      x 6
  Unit Error                               x 4
  Comment Error                            x 3
  Layout Error (Flexbox/Grid)              x 3
  Selector Error                           x 3
  At-rule Error                            x 1
  CSS Variable Error                       x 1
  Font Error                               x 1
  Pseudo-class / Pseudo-element Error      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Property Name Error
    Look for misspelled property names (DevTools shows them crossed out). Use VS Code autocomplete to check spelling.

  * Invalid Value Error
    The property is right but the value is not allowed. Check spelling of keywords (center, solid, absolute...), no commas in padding/margin, decimals use a dot.

  * Unit Error
    Numbers need a unit (px, rem, %, s, deg) with NO space: 12px not 12 px. z-index and font-weight have NO unit.

  * Comment Error
    CSS comments are only /* ... */ . '//' is not a comment, and every /* needs a */.

  * Layout Error (Flexbox/Grid)
    display: flex / grid. Check spelling of flex values (space-between, center, column) and commas inside repeat() and minmax().

  * Selector Error
    Open index.html next to style.css. Classes start with '.', ids with '#'. The name must match the HTML exactly.

  * At-rule Error
    @import must be spelled exactly and url("...") must be closed with ).

  * CSS Variable Error
    Variables are declared as --name: value; inside :root and used as var(--name). Names must match exactly.

  * Font Error
    Close the quotes around font names. The generic font is sans-serif (with hyphen). font-weight: bold or 700.

  * Pseudo-class / Pseudo-element Error
    :hover :focus :nth-child() use ONE colon; ::before ::after use TWO. Check spelling.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 2          @import (fonts)                  1  (At-rule Error)
  3 - 3          Comment: Theme Variables         1  (Comment Error)
  4 - 10         :root { }                        1  (Syntax Error)
  12 - 17        * { }                            2  (Syntax Error)
  18 - 24        body { }                         2  (Syntax Error)
  26 - 33        .site-header { }                 3  (CSS Variable Error, Invalid Value Error, Layout Error (Flexbox/Grid))
  34 - 40        .logo { }                        3  (Font Error, Property Name Error, Unit Error)
  47 - 52        .nav-links a { }                 2  (Selector Error, Syntax Error)
  53 - 57        .nav-links a:hover { }           2  (Property Name Error, Syntax Error)
  58 - 58        Comment: Hero                    1  (Comment Error)
  59 - 66        .hero { }                        1  (Syntax Error)
  67 - 72        .hero-title { }                  2  (Invalid Value Error, Unit Error)
  79 - 88        .btn { }                         1  (Syntax Error)
  94 - 98        .btn-primary { }                 1  (Syntax Error)
  99 - 99        Comment: Product Cards           1  (Comment Error)
  100 - 106      .card-grid { }                   1  (Syntax Error)
  107 - 115      .card { }                        3  (Invalid Value Error, Syntax Error)
  116 - 121      .card-img { }                    3  (Invalid Value Error, Syntax Error)
  122 - 127      .card-title { }                  3  (Property Name Error, Syntax Error)
  133 - 138      .price { }                       1  (Property Name Error)
  139 - 150      .badge { }                       1  (Invalid Value Error)
  152 - 158      .price-table { }                 1  (Property Name Error)
  159 - 165      .price-table th, .price-table td 2  (Property Name Error, Selector Error)
  166 - 169      .price-table tr:nth-child(even)  2  (Property Name Error, Pseudo-class / Pseudo-element Error)
  171 - 178      .contact-form { }                3  (Layout Error (Flexbox/Grid), Property Name Error, Syntax Error)
  179 - 186      .contact-form input, .contact-fo 3  (Property Name Error, Selector Error)
  193 - 199      .site-footer { }                 1  (Syntax Error)
  212 - 224      @media (responsive)              4  (Layout Error (Flexbox/Grid), Syntax Error, Unit Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
