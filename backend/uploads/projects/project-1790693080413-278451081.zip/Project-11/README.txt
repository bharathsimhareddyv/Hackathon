========================================================================
  Project-11  -  Debugging Hackathon (all 4 sections)
========================================================================

This project has 4 sections. Each section is a separate broken page:

  1_HTML        HTML-11_Melody-Academy               58 errors  (difficulty 40/100)
  2_CSS         CSS-11_Frosty-Scoops                 52 errors  (difficulty 43/100)
  3_JavaScript  JS-11_Colour-Canvas                  53 errors  (difficulty 39/100)
  4_React       REACT-11_Sweet-Crumbs-Bakery         54 errors  (difficulty 39/100)

  TOTAL ERRORS IN THIS PROJECT: 217

HOW TO START
  1. Read Guides/00_Hackathon_Rules_and_Debugging_Process.pdf
  2. Open a section folder and read its README.txt (run steps + 3 levels of hints).
  3. Read the matching error guide PDF in Guides/ for that section.
  4. Fix each error on the SAME line. Do not add or delete lines.
  5. Write each fix on your answer sheet: section, line, what was wrong, what you changed.

Suggested order: 1_HTML -> 2_CSS -> 3_JavaScript -> 4_React (easiest to hardest).
