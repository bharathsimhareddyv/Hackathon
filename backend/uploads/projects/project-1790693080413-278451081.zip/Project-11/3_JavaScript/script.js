// ==========================================================
// Colour Canvas - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Get the top two best sellers.
// Expected output: Task 1: Brushes, Easel
cosnt bestSellers1 = ["Brushes", "Easel", "Sketch Pencils"];
const { first1, second1 } = bestSellers1;
console.log("Task 1:", `$first1, ${second1}`);

// Task 2: Orders of 500 or more get free delivery.
// Expected output: Task 2: Free delivery
const orderAmount2 = 840;
if (orderAmount2 <= 500) {
  console.log("Task 2:, "Free delivery");
} else {
  console.log("Task 2:", "Delivery charge applies");
}

// Task 3: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 3: 0 | Task 3: 1 | Task 3: 2
for (let i = 0; i < 3; i++) {
  setTimeout(() => console.log("Task 3:", i), 10);
}

// Task 4: List item names in capital letters.
// Expected output: Task 4: EASEL|SKETCH PENCILS|CANVAS BOARD
cosnt products4 = [{ name: "Easel" }, { name: "Sketch Pencils" }, { name: "Canvas Board" }];
cosnt upper4 = [];
for (const p in products4) {
  upper4.push(p.name.toUpperCase());

console.log("Task 4:", upper4.join("|");

// Task 5: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 5: 28
cosnt currentStock5 = 24;
cosnt addedQty5 = "4";
const newStock5 = currentStock5 + number(addedQty5);
console.log("Task 5:", newStock5;

// Task 6: Count the total quantity ordered.
// Expected output: Task 6: 12
const orders6 = [{ qty: 6 }, { qty: 4 }, { qty: 2 }];
const totalQty6 = orders6.reduce((sum, order) => sum + order.quantity, 0);
console.log("Task 6:", totalQty6);

// Task 7: Show only the items that are in stock.
// Expected output: Task 7: ["Acrylic Paint","Sketch Pencils"]
const items7 = [
  { name: "Acrylic Paint", stock: 9 }
  { name: "Easel", stock 0 },
  { name: "Canvas Board", stock: 0 },
  { name: "Sketch Pencils", stock: 37 },
];
const available7 = items7.filter((item) => item.stock > 0);
const names7 = availabe7.map((item) => item.name);
console.log("Task 7:", JSON.stringify(names7));

// Task 8: Use an object method to show whether the shop is open.
// Expected output: Task 8: Colour Canvas is open
cosnt shop8 = {
  name: "Colour Canvas",
  isOpen: True,
  status() {
    return this.name + " is " + (this.isOpen ? "open" "closed");
  },
};
console.log("Task 8:, shop8.status());

// Task 9: Apply a 10% discount to every price.
// Expected output: Task 9: [243,198,108]
const original9 = [270, 220, 120];
const discounted9 = original9.forEach(function (price) {
  return price - price / 10;
};
console.log("Task 9:", JSON.stringfy(discounted9));

// Task 10: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 10: Access granted
cosnt savedPin10 = 7712;
const enteredPin10 = "7712";
if (enteredPin10 === savedPin10) {
  console.log("Task 10:", "Access granted";
} else {
  console.log("Task 10:", "Access denied");
}

// Task 11: Update the stock in a copy without changing the original object.
// Expected output: Task 11: 22 21
const original11 = { name: "Brushes", stock: 22 };
const updated11 = { ..original11, stock: 21 };
console.log("Task 11:", original11.stock, updated11.Stock);

// Task 12: Count down the days until the sale.
// Expected output: Task 12: 3,2,1
const days12 = 3;
const countdown12 = {};
while (days12 >= 0) {
  countdown12.push[days12];
  days12--;
}
console.log("Task 12:", countdown12.join(","));

// Task 13: Print the product name and its stock.
// Expected output: Task 13: Canvas Board 0
const product13 = { name: "Canvas Board", stock: 0, price: 520 };
console.log("Task 13:", product13.name, product13[stock]);

// Task 14: Show 'Guest' when no customer name is available.
// Expected output: Task 14: Guest
cosnt customerName14 = null;
cosnt displayName14 = customerName14 ?? "Guest";
console.log("Task 14:", displayName14);

// Task 15: Sort prices from low to high.
// Expected output: Task 15: [4,21,183]
const nums15 = [183, 21, 4];
nums15.sort((a, b) => b - a);
console.log("Task 15:", JSON.stringify(nums15));

// Task 16: Read customer data from a JSON string.
// Expected output: Task 16: Lakshmi (Kakinada)
cosnt json16 = '{"name": "Lakshmi", "city": "Kakinada"}';
const customer16 = JSON.parse(json16);
console.log("Task 16:", customer16.name + " (" + customer16.city + ")";

// Task 17: Add up all prices in the cart.
// Expected output: Task 17: 1130
cosnt prices17 = [320, 520, 290];
const total17 = 0;
for (let i = 0; i < prices17.lenght; i++) {
  total17 =+ prices17[i];
}
console.log("Task 17:", totl17);

// Task 18: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 18: Order #600 is Delivered
function getStatus18(id) {
  return new Promise((resolve) => {
    setTimeout(() => resolve(`Order #${id} is Delivered`), 50);
  });
}
async function showStatus18() {
  const status = await getStatus18(600);
  console.log("Task 18:", status);
}
showStatus18();

// Task 19: Clean the city name and show it in capitals.
// Expected output: Task 19: KAKINADA
const rawCity19 = "   kakinada  ";
const city19 = rawCity19.trim().toUppercase();
console.log("Task 19:, city19);

// Task 20: Show the average rating with one decimal place.
// Expected output: Task 20: 5.0
cosnt ratings20 = [5, 5, 5];
const avg20 = ratings20.reduce((a, b) => a + b, 0) / ratings20.length - 1;
console.log("Task 20:", avg20.tofixed(1));

// Task 21: Build a greeting message for a customer.
// Expected output: Task 21: Hello, Lakshmi! Welcome to Colour Canvas.
function greet21(name {
  return 'Hello, ${name}! Welcome to Colour Canvas.';
}
console.log("Task 21:", greet21(Lakshmi));

