======================================================================
  JS-11  |  JavaScript  |  Colour Canvas
======================================================================

File to fix      : script.js
Errors hidden    : 53
Difficulty       : 39 / 100   (Easy 26, Medium 22, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 26
  ReferenceError                           x 6
  TypeError                                x 5
  Logic Error                              x 4
  Object / Class Error                     x 3
  String Method Error                      x 3
  Loop Error                               x 3
  Array Method Error                       x 1
  Type Coercion Error                      x 1
  Function / Return Error                  x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * String Method Error
    ${ } only works inside backticks ` `. Check string method names (trim, toUpperCase).

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * Array Method Error
    map() makes a new array (forEach doesn't). sort numbers with (a, b) => a - b. Give reduce a starting value 0.

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 13         Task 1                           3  (Object / Class Error, String Method Error, SyntaxError)
  14 - 22        Task 2                           2  (Logic Error, SyntaxError)
  29 - 37        Task 4                           5  (Loop Error, SyntaxError)
  38 - 44        Task 5                           4  (ReferenceError, SyntaxError)
  45 - 50        Task 6                           1  (Object / Class Error)
  51 - 62        Task 7                           3  (ReferenceError, SyntaxError)
  63 - 73        Task 8                           4  (ReferenceError, SyntaxError)
  74 - 81        Task 9                           3  (Array Method Error, SyntaxError, TypeError)
  82 - 91        Task 10                          3  (SyntaxError, Type Coercion Error)
  92 - 97        Task 11                          2  (Object / Class Error, SyntaxError)
  98 - 107       Task 12                          4  (Function / Return Error, Loop Error, TypeError)
  108 - 112      Task 13                          1  (ReferenceError)
  113 - 118      Task 14                          2  (SyntaxError)
  119 - 124      Task 15                          1  (Logic Error)
  125 - 130      Task 16                          2  (SyntaxError)
  131 - 139      Task 17                          5  (Logic Error, Loop Error, ReferenceError, SyntaxError, TypeError)
  153 - 158      Task 19                          2  (String Method Error, SyntaxError)
  159 - 164      Task 20                          3  (Logic Error, SyntaxError, TypeError)
  165 - 171      Task 21                          3  (ReferenceError, String Method Error, SyntaxError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
