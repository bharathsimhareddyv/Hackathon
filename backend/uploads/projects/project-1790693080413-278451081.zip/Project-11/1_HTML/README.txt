======================================================================
  HTML-11  |  HTML  |  Melody Academy
======================================================================

File to fix      : index.html
Errors hidden    : 58
Difficulty       : 40 / 100   (Easy 32, Medium 16, Hard 10)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. Open index.html in Chrome/Firefox.
  2. Go to https://validator.w3.org/#validate_by_input and paste the whole file. Fix the FIRST error, re-check, repeat.
  3. Then click every link and try the form.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 31
  Attribute Error                          x 11
  Link / Path Error                        x 5
  Nesting / Structure Error                x 3
  Form Error                               x 2
  Document Setup Error                     x 1
  Media Error                              x 1
  Table Error                              x 1
  Duplicate ID Error                       x 1
  Accessibility Error                      x 1
  Entity / Special Character Error         x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Attribute Error
    Every attribute looks like name="value" - check spelling (class, href, src, required), the = sign, and BOTH quotes. a/link use href; img/script/source use src.

  * Link / Path Error
    Click every link. #links must match an id exactly. URLs start with https:// . Paths use / not \. Email = mailto: , phone = tel: .

  * Nesting / Structure Error
    Tags close in reverse order: <li><a>..</a></li>. Lists (ul/ol) can only contain <li>.

  * Form Error
    Valid input types: text, email, tel, date, checkbox... Form method is get or post. Button type is submit. Close <textarea>.

  * Document Setup Error
    Compare the first lines with the standard skeleton: <!DOCTYPE html>, <meta charset="UTF-8">, <meta name="viewport" content="width=device-width, initial-scale=1.0">.

  * Media Error
    The attribute is 'controls'. MIME types: video/mp4, audio/mpeg.

  * Table Error
    Each row is <tr><td>..</td><td>..</td></tr>. A <th> closes with </th>, a <td> with </td>.

  * Duplicate ID Error
    Use Ctrl+F on id=" - every id value must appear only once on the page.

  * Accessibility Error
    Every <img> needs alt="...". A <label for="x"> must match an input with id="x". Every <iframe> needs a title.

  * Entity / Special Character Error
    Codes like &copy; &amp; &#8377; must end with a semicolon. Write &lt; instead of a raw < in text.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 10         Head (document setup)            6  (Attribute Error, Document Setup Error, Syntax Error)
  11 - 22        Header & navigation              8  (Attribute Error, Link / Path Error, Syntax Error)
  23 - 34        Media section                    2  (Media Error, Syntax Error)
  35 - 46        FAQ section                      4  (Attribute Error, Syntax Error)
  47 - 66        Price table                      7  (Syntax Error, Table Error)
  67 - 81        Team section                     7  (Nesting / Structure Error, Syntax Error)
  82 - 106       Contact form                     5  (Attribute Error, Form Error, Link / Path Error)
  107 - 118      Products list                    3  (Duplicate ID Error, Syntax Error)
  119 - 127      About section                    3  (Attribute Error, Link / Path Error, Nesting / Structure Error)
  128 - 134      Hero section                     3  (Attribute Error, Link / Path Error)
  135 - 150      Gallery                          6  (Accessibility Error, Link / Path Error, Syntax Error)
  151 - 158      Footer & closing tags            4  (Entity / Special Character Error, Nesting / Structure Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
