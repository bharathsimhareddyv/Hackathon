======================================================================
  REACT-11  |  React  |  Sweet Crumbs Bakery
======================================================================

File to fix      : App.jsx
Errors hidden    : 54
Difficulty       : 39 / 100   (Easy 27, Medium 22, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 17
  JavaScript Error                         x 11
  JavaScript Syntax Error                  x 10
  List & Key Error                         x 4
  Component Definition Error               x 3
  Import / Export Error                    x 2
  State Mutation Error                     x 2
  Event Handling Error                     x 2
  JSX Attribute Error                      x 2
  Props Error                              x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * State Mutation Error
    Never push/splice/++ state. Call the setter with a NEW array/object: setItems([...items, x]).

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            6  (JavaScript Error)
  19 - 38        ContactForm component            3  (JSX Syntax Error, JavaScript Syntax Error, State Mutation Error)
  39 - 51        ProductList component            2  (List & Key Error)
  52 - 64        Counter component                6  (JSX Syntax Error, JavaScript Error, JavaScript Syntax Error)
  65 - 72        Greeting component               1  (JavaScript Syntax Error)
  73 - 82        FAQItem component                2  (Event Handling Error, JavaScript Error)
  83 - 97        SearchBar component              4  (JSX Attribute Error, JSX Syntax Error)
  98 - 105       Banner component                 1  (JSX Syntax Error)
  106 - 123      Tabs component                   3  (JSX Syntax Error, JavaScript Error, JavaScript Syntax Error)
  124 - 132      Footer component                 1  (JavaScript Syntax Error)
  133 - 146      ProductCard component            2  (JSX Syntax Error)
  147 - 162      Wishlist component               5  (JSX Syntax Error, JavaScript Syntax Error, List & Key Error, State Mutation Error)
  163 - 173      Timer component                  1  (JavaScript Error)
  174 - 186      CartSummary component            3  (JSX Syntax Error, JavaScript Syntax Error)
  187 - 194      Rating component                 2  (JavaScript Syntax Error, List & Key Error)
  195 - 203      Header component                 3  (Component Definition Error, JSX Syntax Error)
  204 - 233      App component                    8  (Component Definition Error, Event Handling Error, Import / Export Error, JSX Syntax Error, JavaScript Error, Props Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
