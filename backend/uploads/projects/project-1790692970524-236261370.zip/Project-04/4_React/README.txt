======================================================================
  REACT-04  |  React  |  FixIt Mobile Care
======================================================================

File to fix      : App.jsx
Errors hidden    : 56
Difficulty       : 39 / 100   (Easy 28, Medium 22, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 17
  JavaScript Syntax Error                  x 11
  JavaScript Error                         x 8
  List & Key Error                         x 4
  JSX Attribute Error                      x 4
  Props Error                              x 3
  Component Definition Error               x 3
  Import / Export Error                    x 2
  State Mutation Error                     x 2
  Event Handling Error                     x 1
  Style Prop Error                         x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * State Mutation Error
    Never push/splice/++ state. Call the setter with a NEW array/object: setItems([...items, x]).

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

  * Style Prop Error
    style takes an object: style={{ backgroundColor: color }} (double braces, camelCase keys).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            6  (JavaScript Error, List & Key Error)
  19 - 27        Footer component                 3  (JSX Syntax Error, Props Error)
  28 - 43        Wishlist component               5  (JSX Syntax Error, JavaScript Syntax Error, List & Key Error, State Mutation Error)
  44 - 63        ContactForm component            3  (JSX Syntax Error, JavaScript Syntax Error, State Mutation Error)
  64 - 71        Rating component                 1  (JavaScript Error)
  72 - 79        Greeting component               2  (JSX Syntax Error, JavaScript Syntax Error)
  80 - 88        Header component                 2  (JSX Attribute Error, Props Error)
  89 - 102       ProductCard component            2  (JSX Syntax Error)
  103 - 115      CartSummary component            4  (JSX Syntax Error, JavaScript Syntax Error)
  116 - 128      ProductList component            4  (Component Definition Error, JSX Syntax Error, JavaScript Syntax Error, List & Key Error)
  129 - 141      Counter component                3  (JSX Syntax Error, JavaScript Syntax Error)
  142 - 156      SearchBar component              3  (Event Handling Error, JSX Attribute Error)
  157 - 174      Tabs component                   3  (JSX Attribute Error, JSX Syntax Error, JavaScript Error)
  175 - 184      FAQItem component                3  (JSX Syntax Error, JavaScript Error)
  185 - 192      Banner component                 2  (JSX Syntax Error, Style Prop Error)
  193 - 203      Timer component                  2  (JavaScript Syntax Error)
  204 - 233      App component                    7  (Component Definition Error, Import / Export Error, JSX Syntax Error, JavaScript Error, JavaScript Syntax Error, Props Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
