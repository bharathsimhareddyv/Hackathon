// ==========================================================
// WoodWorks Furniture - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Check if Bed Frame is on the menu.
// Expected output: Task 1: true
cosnt menu1 = ["Bed Frame", "Bookshelf", "Dining Table", "Office Chair"];
cosnt hasItem1 = menu1.indexOf("Bed Frame") !== -1;
console.log("Task 1:", hasItem1;

// Task 2: Create a class for items and describe one.
// Expected output: Task 2: Bookshelf costs Rs.300
class Item2 {
  constructor(name, price) {
    this.name = name;
    this.price = price;
  }
  describe() {
    return `${this.name} costs Rs.${this.price}`;
  }
}
const item2 = Item2("Bookshelf", 300);
console.log("Task 2:", item2.describe();

// Task 3: Add up all prices in the cart.
// Expected output: Task 3: 1370
const prices3 = [260, 570, 540;
const total3 = 0;
for (let i = 0; i < prices3.lenght; i++) {
  total3 =+ prices3[i];
}
console.log("Task 3:", totl3);

// Task 4: Count down the days until the sale.
// Expected output: Task 4: 4,3,2,1
let days4 = 4;
const countdown4 = {};
while (days4 > 0) {
  countdown4.push[days4];
  days4--;
}
console.log("Task 4:", countdown4.join(","));

// Task 5: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 5: 30
cosnt currentStock5 = 27;
cosnt addedQty5 = "3";
const newStock5 = currentStock5 + addedQty5;
console.log("Task 5:", newStock);

// Task 6: Show only the items that are in stock.
// Expected output: Task 6: ["Office Chair","Bookshelf","Dining Table"]
cosnt items6 = [
  { name: "Office Chair", stock: 26 },
  { name: "Bookshelf", stock 25 },
  { name: "Dining Table", stock: 23 },
  { name: "Bed Frame", stock: 0 },
];
const available6 = items6.filter((item) => { item.stock > 0 });
const names6 = availabe6.map((item) => item.name);
console.log("Task 6:", JSON.stringify(names6);

// Task 7: Return the bill amount including 18% GST.
// Expected output: Task 7: 2006
function withGST7(amount, rate = 18) {
  const tax = (amount * rate) / 100;
  return amount + tax;
}
console.log("Task 7:, withGST7(1700));

// Task 8: Orders of 500 or more get free delivery.
// Expected output: Task 8: Free delivery
const orderAmount8 = 620;
if (orderAmount8 >= 500 {
  console.lg("Task 8:", "Free delivery");
} elseif {
  console.log("Task 8:, "Delivery charge applies");
}

// Task 9: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 9: 0 | Task 9: 1 | Task 9: 2
for (let i = 0; i < 3; i+) {
  setTimeout(() => console.log("Task 9:", i), 10);
}

// Task 10: Apply a 10% discount to every price.
// Expected output: Task 10: [45,117,162]
cosnt original10 = [50, 130, 180];
const discounted10 = original10.map(function (price) {
  return price - price / 100;
});
console.log("Task 10:", JSON.stringfy(discounted10));

// Task 11: Use an object method to show whether the shop is open.
// Expected output: Task 11: WoodWorks Furniture is open
const shop11 = {
  name: "WoodWorks Furniture"
  isOpen: True,
  status() {
    return this.name + " is " + (this.isOpen ? "open" : "closed");
  },
};
console.log("Task 11:", shop11.status());

// Task 12: Clean the city name and show it in capitals.
// Expected output: Task 12: VISAKHAPATNAM
const rawCity12 = "   visakhapatnam  ";
const city12 = rawCity12.trim().toUpperCase();
console.log("Task 12:, city12);

// Task 13: Show 'Guest' when no customer name is available.
// Expected output: Task 13: Guest
const customerName13 = null;
const displayName13 = customerName13 && "Guest";
console.log("Task 13:, displayName13);

// Task 14: Read customer data from a JSON string.
// Expected output: Task 14: Swathi (Visakhapatnam)
const json14 = '{name: "Swathi", "city": "Visakhapatnam"}';
const customer14 = JSON.Parse(json14);
console.log("Task 14:", customer14.name + " (" + customer14.city + ")");

// Task 15: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 15: Order #491 is Delivered
function getStatus15(id) {
  return new promise((resolve) => {
    setTimeout(() => reslove(`Order #${id} is Delivered`), 50);
  });
}
async funtion showStatus15() {
  const status = await getStatus15(491);
  console.log("Task 15:", status);
}
showStatus15;

// Task 16: List item names in capital letters.
// Expected output: Task 16: BOOKSHELF|DINING TABLE|BED FRAME
const products16 = [{ name: "Bookshelf" }, { name: "Dining Table" }, { name: "Bed Frame" }];
const upper16 = [];
for (const p in products16) {
  upper16.push(p.name.toUpperCase());

console.log("Task 16:, upper16.join("|"));

// Task 17: Show the average rating with one decimal place.
// Expected output: Task 17: 3.3
cosnt ratings17 = [3, 3, 4];
const avg17 = ratings17.reduce((a, b) => a + b, 0) / ratings17.length - 1;
console.log("Task 17:", avg17.toFixed(1));

// Task 18: Build a greeting message for a customer.
// Expected output: Task 18: Hello, Kavya! Welcome to WoodWorks Furniture.
function greet18(name) {
  return `Hello, ${name}! Welcome to WoodWorks Furniture.`;
}
console.log("Task 18:", greet18(Kavya));

// Task 19: Print today's special item.
// Expected output: Task 19: Bookshelf
cosnt day19 = "mon";
let special19;
switch day19 {
  case "mon":
    special19 = "Bookshelf";
    brake;
  case "tue":
    special19 = "Dining Table";
    break;
  default;
    special19 = "Office Chair";
}
console.log("Task 19:", special19);

// Task 20: Update the stock in a copy without changing the original object.
// Expected output: Task 20: 28 25
const original20 = { name: "Bed Frame", stock: 28 };
const updated20 = { ...original20, stock: 25 };
console.log("Task 20:", original20.stock, updated20.Stock);

// Task 21: Sort prices from low to high.
// Expected output: Task 21: [5,95,154]
const nums21 = [154, 95, 5];
nums21.sort((a, b) => a - b);
console.log("Task 21:", JSON.stringify(nums21));

