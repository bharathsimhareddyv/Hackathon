======================================================================
  JS-04  |  JavaScript  |  WoodWorks Furniture
======================================================================

File to fix      : script.js
Errors hidden    : 52
Difficulty       : 39 / 100   (Easy 26, Medium 21, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 26
  ReferenceError                           x 8
  TypeError                                x 6
  Logic Error                              x 4
  Function / Return Error                  x 3
  Loop Error                               x 2
  Type Coercion Error                      x 1
  JSON Error                               x 1
  Object / Class Error                     x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

  * JSON Error
    JSON keys need double quotes and there must be no comma before }. Use JSON.parse() to read it.

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 13         Task 1                           3  (SyntaxError)
  14 - 27        Task 2                           2  (SyntaxError, TypeError)
  28 - 36        Task 3                           5  (Logic Error, Loop Error, ReferenceError, SyntaxError, TypeError)
  37 - 46        Task 4                           2  (Function / Return Error, TypeError)
  47 - 53        Task 5                           4  (ReferenceError, SyntaxError, Type Coercion Error)
  54 - 65        Task 6                           5  (Function / Return Error, ReferenceError, SyntaxError)
  66 - 73        Task 7                           1  (SyntaxError)
  74 - 82        Task 8                           4  (SyntaxError, TypeError)
  83 - 88        Task 9                           1  (SyntaxError)
  89 - 96        Task 10                          3  (Logic Error, SyntaxError, TypeError)
  97 - 107       Task 11                          2  (ReferenceError, SyntaxError)
  108 - 113      Task 12                          1  (SyntaxError)
  114 - 119      Task 13                          2  (Logic Error, SyntaxError)
  120 - 125      Task 14                          2  (JSON Error, TypeError)
  126 - 138      Task 15                          4  (Function / Return Error, ReferenceError, SyntaxError)
  139 - 147      Task 16                          3  (Loop Error, SyntaxError)
  148 - 153      Task 17                          2  (Logic Error, SyntaxError)
  154 - 160      Task 18                          1  (ReferenceError)
  161 - 176      Task 19                          4  (ReferenceError, SyntaxError)
  177 - 182      Task 20                          1  (Object / Class Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
