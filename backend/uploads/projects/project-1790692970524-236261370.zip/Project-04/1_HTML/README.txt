======================================================================
  HTML-04  |  HTML  |  Iron Pulse Gym
======================================================================

File to fix      : index.html
Errors hidden    : 57
Difficulty       : 38 / 100   (Easy 33, Medium 16, Hard 8)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. Open index.html in Chrome/Firefox.
  2. Go to https://validator.w3.org/#validate_by_input and paste the whole file. Fix the FIRST error, re-check, repeat.
  3. Then click every link and try the form.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 33
  Attribute Error                          x 7
  Link / Path Error                        x 4
  Table Error                              x 3
  Document Setup Error                     x 2
  Media Error                              x 2
  Nesting / Structure Error                x 2
  Form Error                               x 2
  Duplicate ID Error                       x 1
  Accessibility Error                      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Attribute Error
    Every attribute looks like name="value" - check spelling (class, href, src, required), the = sign, and BOTH quotes. a/link use href; img/script/source use src.

  * Link / Path Error
    Click every link. #links must match an id exactly. URLs start with https:// . Paths use / not \. Email = mailto: , phone = tel: .

  * Table Error
    Each row is <tr><td>..</td><td>..</td></tr>. A <th> closes with </th>, a <td> with </td>.

  * Document Setup Error
    Compare the first lines with the standard skeleton: <!DOCTYPE html>, <meta charset="UTF-8">, <meta name="viewport" content="width=device-width, initial-scale=1.0">.

  * Media Error
    The attribute is 'controls'. MIME types: video/mp4, audio/mpeg.

  * Nesting / Structure Error
    Tags close in reverse order: <li><a>..</a></li>. Lists (ul/ol) can only contain <li>.

  * Form Error
    Valid input types: text, email, tel, date, checkbox... Form method is get or post. Button type is submit. Close <textarea>.

  * Duplicate ID Error
    Use Ctrl+F on id=" - every id value must appear only once on the page.

  * Accessibility Error
    Every <img> needs alt="...". A <label for="x"> must match an input with id="x". Every <iframe> needs a title.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 10         Head (document setup)            5  (Attribute Error, Document Setup Error, Syntax Error)
  11 - 22        Header & navigation              6  (Attribute Error, Link / Path Error, Syntax Error)
  23 - 29        Hero section                     2  (Attribute Error, Syntax Error)
  30 - 41        Products list                    5  (Attribute Error, Duplicate ID Error, Syntax Error)
  42 - 53        Media section                    6  (Accessibility Error, Attribute Error, Media Error, Syntax Error)
  54 - 68        Team section                     6  (Nesting / Structure Error, Syntax Error)
  69 - 77        About section                    3  (Link / Path Error, Syntax Error)
  78 - 93        Gallery                          6  (Attribute Error, Syntax Error)
  94 - 118       Contact form                     4  (Form Error, Link / Path Error, Syntax Error)
  119 - 130      FAQ section                      4  (Syntax Error)
  131 - 150      Price table                      8  (Syntax Error, Table Error)
  151 - 158      Footer & closing tags            2  (Link / Path Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
