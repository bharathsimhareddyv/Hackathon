======================================================================
  REACT-07  |  React  |  Step Up Footwear
======================================================================

File to fix      : App.jsx
Errors hidden    : 55
Difficulty       : 39 / 100   (Easy 28, Medium 21, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 20
  JavaScript Error                         x 8
  JavaScript Syntax Error                  x 8
  Event Handling Error                     x 4
  Component Definition Error               x 4
  List & Key Error                         x 3
  JSX Attribute Error                      x 3
  Import / Export Error                    x 2
  Props Error                              x 2
  Style Prop Error                         x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

  * Style Prop Error
    style takes an object: style={{ backgroundColor: color }} (double braces, camelCase keys).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            5  (JavaScript Error, List & Key Error)
  19 - 38        ContactForm component            3  (Event Handling Error, JSX Syntax Error, JavaScript Syntax Error)
  39 - 49        Timer component                  2  (JavaScript Syntax Error)
  50 - 67        Tabs component                   3  (JSX Attribute Error, JSX Syntax Error, JavaScript Error)
  68 - 76        Footer component                 3  (JSX Syntax Error, Props Error)
  77 - 89        ProductList component            4  (Component Definition Error, JSX Syntax Error, JavaScript Syntax Error)
  90 - 104       SearchBar component              1  (Event Handling Error)
  105 - 112      Banner component                 1  (Style Prop Error)
  113 - 120      Rating component                 3  (JavaScript Error, JavaScript Syntax Error, List & Key Error)
  121 - 136      Wishlist component               4  (Event Handling Error, JSX Syntax Error, JavaScript Syntax Error, List & Key Error)
  137 - 150      ProductCard component            6  (JSX Syntax Error, JavaScript Syntax Error, Props Error)
  151 - 163      Counter component                4  (Event Handling Error, JSX Syntax Error, JavaScript Error, JavaScript Syntax Error)
  164 - 172      Header component                 3  (Component Definition Error, JSX Attribute Error, JSX Syntax Error)
  173 - 182      FAQItem component                3  (JSX Syntax Error)
  183 - 195      CartSummary component            2  (JSX Syntax Error)
  196 - 203      Greeting component               1  (JSX Syntax Error)
  204 - 233      App component                    6  (Component Definition Error, Import / Export Error, JSX Attribute Error, JSX Syntax Error, JavaScript Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
