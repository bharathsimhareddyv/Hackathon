======================================================================
  JS-07  |  JavaScript  |  Fresh Squeeze Juices
======================================================================

File to fix      : script.js
Errors hidden    : 55
Difficulty       : 39 / 100   (Easy 28, Medium 21, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 28
  ReferenceError                           x 7
  Logic Error                              x 5
  TypeError                                x 5
  String Method Error                      x 2
  Array Method Error                       x 2
  Function / Return Error                  x 2
  Object / Class Error                     x 2
  Type Coercion Error                      x 1
  Loop Error                               x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * String Method Error
    ${ } only works inside backticks ` `. Check string method names (trim, toUpperCase).

  * Array Method Error
    map() makes a new array (forEach doesn't). sort numbers with (a, b) => a - b. Give reduce a starting value 0.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 14         Task 1                           3  (ReferenceError, String Method Error, SyntaxError)
  15 - 23        Task 2                           2  (Logic Error, SyntaxError)
  24 - 31        Task 3                           5  (Array Method Error, Function / Return Error, SyntaxError, TypeError)
  32 - 41        Task 4                           3  (SyntaxError, Type Coercion Error)
  42 - 47        Task 5                           3  (Logic Error, SyntaxError)
  48 - 60        Task 6                           4  (Function / Return Error, ReferenceError, SyntaxError)
  61 - 74        Task 7                           3  (Object / Class Error, ReferenceError, TypeError)
  75 - 80        Task 8                           3  (Object / Class Error, String Method Error, SyntaxError)
  81 - 96        Task 9                           3  (Logic Error, SyntaxError)
  97 - 105       Task 10                          4  (Loop Error, SyntaxError, TypeError)
  106 - 111      Task 11                          1  (SyntaxError)
  112 - 117      Task 12                          1  (SyntaxError)
  118 - 124      Task 13                          2  (ReferenceError, SyntaxError)
  125 - 132      Task 14                          1  (ReferenceError)
  133 - 141      Task 15                          4  (SyntaxError, TypeError)
  142 - 147      Task 16                          2  (ReferenceError, SyntaxError)
  153 - 158      Task 18                          3  (Array Method Error, SyntaxError)
  165 - 176      Task 20                          5  (Logic Error, ReferenceError, SyntaxError)
  177 - 182      Task 21                          3  (Logic Error, SyntaxError, TypeError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
