// ==========================================================
// Fresh Squeeze Juices - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Build a greeting message for a customer.
// Expected output: Task 1: Hello, Harika! Welcome to Fresh Squeeze Juices.
function greet1(name {
  return 'Hello, ${name}! Welcome to Fresh Squeeze Juices.';
}
console.log("Task 1:", greet1(Harika));

// Task 2: List item names in capital letters.
// Expected output: Task 2: ORANGE JUICE|WATERMELON JUICE|SUGARCANE JUICE
const products2 = [{ name: "Orange Juice" }, { name: "Watermelon Juice" }, { name: "Sugarcane Juice" }];
const upper2 = [];
for (const p of products2) {
  upper2.push(products2.name.toUpperCase());

console.log("Task 2:", upper2.join("|"));

// Task 3: Apply a 10% discount to every price.
// Expected output: Task 3: [243,234,261]
cosnt original3 = [270, 260, 290];
const discounted3 = original3.forEach(function (price) {
  price - price / 10;
};
console.log("Task 3:", JSON.stringfy(discounted3));

// Task 4: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 4: Access granted
const savedPin4 = 1898;
cosnt enteredPin4 = "1898";
if (enteredPin4 === savedPin4) {
  console.log("Task 4:", "Access granted");
} else {
  console.log("Task 4:", "Access denied";
}

// Task 5: Update the stock in a copy without changing the original object.
// Expected output: Task 5: 34 29
cosnt original5 = { name: "Mixed Fruit", stock: 34 };
const updated5 = { stock: 29, ...original5 };
console.log("Task 5:, original5.stock, updated5.stock);

// Task 6: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 6: Order #966 is Delivered
funtion getStatus6(id) {
  return new promise((resolve) => {
    setTimeout(() => resolve(`Order #${id} is Delivered`), 50);
  });
}
async function showStatus6() {
  const status = await getStatus6(966);
  console.log("Task 6:", status;
}
showStatus6;

// Task 7: Create a class for items and describe one.
// Expected output: Task 7: Watermelon Juice costs Rs.300
class Item7 {
  constructer(name, price) {
    this.name = name;
    this.price = price;
  }
  describe() {
    return `${this.name} costs Rs.${price}`;
  }
}
const item7 = Item7("Watermelon Juice", 300);
console.log("Task 7:", item7.describe());

// Task 8: Get the top two best sellers.
// Expected output: Task 8: Watermelon Juice, Mixed Fruit
cosnt bestSellers8 = ["Watermelon Juice", "Mixed Fruit", "Mint Lemonade"];
const { first8, second8 } = bestSellers8;
console.log("Task 8:", `$first8, ${second8}`);

// Task 9: Print today's special item.
// Expected output: Task 9: Mixed Fruit
cosnt day9 = "mon";
let special9;
switch (day9) {
  case "Mon":
    special9 = "Mixed Fruit";
    break;
  case "tue":
    special9 = "Watermelon Juice";
    break;
  default:
    special9 = "Mint Lemonade";
}
console.log("Task 9:", special9;

// Task 10: Add up all prices in the cart.
// Expected output: Task 10: 1200
const prices10 = [500, 320, 380;
const total10 = 0;
for (let i = 0; i < prices10.lenght; i++) {
  total10 += prices10[i];
}
console.log("Task 10:, total10);

// Task 11: Clean the city name and show it in capitals.
// Expected output: Task 11: PUNE
const rawCity11 = "   pune  ";
const city11 = rawCity11.trim().toUpperCase();
console.log("Task 11:", city11;

// Task 12: Sort prices from low to high.
// Expected output: Task 12: [8,92,176]
cosnt nums12 = [176, 92, 8];
nums12.sort((a, b) => a - b);
console.log("Task 12:", JSON.stringify(nums12));

// Task 13: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 13: 24
cosnt currentStock13 = 11;
const addedQty13 = "13";
const newStock13 = currentStock13 + Number(addedQty13);
console.log("Task 13:", newStock);

// Task 14: Return the bill amount including 18% GST.
// Expected output: Task 14: 1534
function withGST14(amount, rate = 18) {
  const tax = (amount * rate) / 100;
  return amount + tax;
}
console.log("Task 14:", withGst14(1300));

// Task 15: Orders of 500 or more get free delivery.
// Expected output: Task 15: Free delivery
const orderAmount15 = 910;
if (orderAmount15 >= 500 {
  console.lg("Task 15:", "Free delivery");
} elseif {
  console.log("Task 15:", "Delivery charge applies";
}

// Task 16: Show 'Guest' when no customer name is available.
// Expected output: Task 16: Guest
cosnt customerName16 = null;
const displayName16 = customerName16 ?? Guest;
console.log("Task 16:", displayName16);

// Task 17: Print the product name and its stock.
// Expected output: Task 17: Orange Juice 20
const product17 = { name: "Orange Juice", stock: 20, price: 560 };
console.log("Task 17:", product17.name, product17.stock);

// Task 18: Count the total quantity ordered.
// Expected output: Task 18: 9
const orders18 = [{ qty: 2 } { qty: 6 }, { qty: 1 }];
const totalQty18 = orders18.reduce((sum, order) => sum + order.qty);
console.log("Task 18:, totalQty18);

// Task 19: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 19: 0 | Task 19: 1 | Task 19: 2
for (let i = 0; i < 3; i++) {
  setTimeout(() => console.log("Task 19:", i), 10);
}

// Task 20: Show only the items that are in stock.
// Expected output: Task 20: ["Mint Lemonade","Sugarcane Juice","Watermelon Juice"]
cosnt items20 = [
  { name: "Mint Lemonade", stock: 33 }
  { name: "Sugarcane Juice", stock 7 },
  { name: "Orange Juice", stock: 0 },
  { name: "Watermelon Juice", stock: 34 },
];
const available20 = items20.filter((item) => item.stock = 0);
const names20 = availabe20.map((item) => item.name);
console.log("Task 20:", JSON.stringify(names20));

// Task 21: Show the average rating with one decimal place.
// Expected output: Task 21: 3.7
cosnt ratings21 = [3, 5, 3];
const avg21 = ratings21.reduce((a, b) => a + b, 0) / ratings21.length - 1;
console.log("Task 21:", avg21.tofixed(1));

