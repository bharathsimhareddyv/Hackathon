======================================================================
  HTML-07  |  HTML  |  Circuit Hub
======================================================================

File to fix      : index.html
Errors hidden    : 52
Difficulty       : 37 / 100   (Easy 31, Medium 15, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. Open index.html in Chrome/Firefox.
  2. Go to https://validator.w3.org/#validate_by_input and paste the whole file. Fix the FIRST error, re-check, repeat.
  3. Then click every link and try the form.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 30
  Attribute Error                          x 8
  Link / Path Error                        x 4
  Table Error                              x 4
  Form Error                               x 2
  Document Setup Error                     x 1
  Duplicate ID Error                       x 1
  Entity / Special Character Error         x 1
  Nesting / Structure Error                x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Attribute Error
    Every attribute looks like name="value" - check spelling (class, href, src, required), the = sign, and BOTH quotes. a/link use href; img/script/source use src.

  * Link / Path Error
    Click every link. #links must match an id exactly. URLs start with https:// . Paths use / not \. Email = mailto: , phone = tel: .

  * Table Error
    Each row is <tr><td>..</td><td>..</td></tr>. A <th> closes with </th>, a <td> with </td>.

  * Form Error
    Valid input types: text, email, tel, date, checkbox... Form method is get or post. Button type is submit. Close <textarea>.

  * Document Setup Error
    Compare the first lines with the standard skeleton: <!DOCTYPE html>, <meta charset="UTF-8">, <meta name="viewport" content="width=device-width, initial-scale=1.0">.

  * Duplicate ID Error
    Use Ctrl+F on id=" - every id value must appear only once on the page.

  * Entity / Special Character Error
    Codes like &copy; &amp; &#8377; must end with a semicolon. Write &lt; instead of a raw < in text.

  * Nesting / Structure Error
    Tags close in reverse order: <li><a>..</a></li>. Lists (ul/ol) can only contain <li>.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 10         Head (document setup)            3  (Attribute Error, Document Setup Error)
  11 - 22        Header & navigation              5  (Attribute Error, Link / Path Error, Syntax Error)
  23 - 34        Media section                    2  (Attribute Error, Syntax Error)
  35 - 43        About section                    4  (Syntax Error)
  44 - 55        FAQ section                      5  (Attribute Error, Syntax Error)
  56 - 67        Products list                    4  (Duplicate ID Error, Entity / Special Character Error, Syntax Error)
  68 - 83        Gallery                          5  (Syntax Error)
  84 - 98        Team section                     3  (Nesting / Structure Error, Syntax Error)
  99 - 105       Hero section                     5  (Attribute Error, Link / Path Error, Syntax Error)
  106 - 130      Contact form                     6  (Attribute Error, Form Error, Syntax Error)
  131 - 150      Price table                      6  (Syntax Error, Table Error)
  151 - 158      Footer & closing tags            4  (Link / Path Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
