======================================================================
  CSS-07  |  CSS  |  Seaside Residency
======================================================================

File to fix      : style.css
Errors hidden    : 54
Difficulty       : 39 / 100   (Easy 26, Medium 23, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. index.html is CORRECT - do not edit it. Fix style.css only.
  2. Open index.html in the browser, press F12 > Elements, click an element and look at Styles: crossed-out lines are errors.
  3. Also paste style.css into https://jigsaw.w3.org/css-validator/#validate_by_input

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 23
  Property Name Error                      x 10
  Comment Error                            x 3
  Unit Error                               x 3
  Animation / Transition Error             x 3
  Invalid Value Error                      x 3
  Selector Error                           x 2
  Layout Error (Flexbox/Grid)              x 2
  Color Error                              x 2
  CSS Variable Error                       x 1
  Pseudo-class / Pseudo-element Error      x 1
  Font Error                               x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Property Name Error
    Look for misspelled property names (DevTools shows them crossed out). Use VS Code autocomplete to check spelling.

  * Comment Error
    CSS comments are only /* ... */ . '//' is not a comment, and every /* needs a */.

  * Unit Error
    Numbers need a unit (px, rem, %, s, deg) with NO space: 12px not 12 px. z-index and font-weight have NO unit.

  * Animation / Transition Error
    @keyframes (with s), from/to, times need 's', and the animation name must match the keyframes name exactly (case!).

  * Invalid Value Error
    The property is right but the value is not allowed. Check spelling of keywords (center, solid, absolute...), no commas in padding/margin, decimals use a dot.

  * Selector Error
    Open index.html next to style.css. Classes start with '.', ids with '#'. The name must match the HTML exactly.

  * Layout Error (Flexbox/Grid)
    display: flex / grid. Check spelling of flex values (space-between, center, column) and commas inside repeat() and minmax().

  * Color Error
    Hex colours have 3 or 6 digits using only 0-9 and a-f. Check colour names and close rgba( ).

  * CSS Variable Error
    Variables are declared as --name: value; inside :root and used as var(--name). Names must match exactly.

  * Pseudo-class / Pseudo-element Error
    :hover :focus :nth-child() use ONE colon; ::before ::after use TWO. Check spelling.

  * Font Error
    Close the quotes around font names. The generic font is sans-serif (with hyphen). font-weight: bold or 700.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  4 - 10         :root { }                        1  (CSS Variable Error)
  12 - 17        * { }                            1  (Syntax Error)
  18 - 24        body { }                         2  (Selector Error, Syntax Error)
  26 - 33        .site-header { }                 2  (Layout Error (Flexbox/Grid), Property Name Error)
  47 - 52        .nav-links a { }                 2  (Property Name Error, Syntax Error)
  53 - 57        .nav-links a:hover { }           1  (Syntax Error)
  58 - 58        Comment: Hero                    1  (Comment Error)
  59 - 66        .hero { }                        1  (Syntax Error)
  67 - 72        .hero-title { }                  1  (Unit Error)
  73 - 77        .hero-text { }                   2  (Animation / Transition Error, Syntax Error)
  78 - 78        Comment: Buttons                 1  (Comment Error)
  79 - 88        .btn { }                         4  (Animation / Transition Error, Invalid Value Error, Syntax Error)
  89 - 93        .btn:hover { }                   1  (Color Error)
  100 - 106      .card-grid { }                   3  (Syntax Error)
  116 - 121      .card-img { }                    3  (Syntax Error)
  122 - 127      .card-title { }                  1  (Syntax Error)
  128 - 132      .card-title::before { }          2  (Property Name Error, Pseudo-class / Pseudo-element Error)
  133 - 138      .price { }                       3  (Font Error, Selector Error, Syntax Error)
  139 - 150      .badge { }                       3  (Property Name Error, Syntax Error)
  152 - 158      .price-table { }                 2  (Invalid Value Error, Property Name Error)
  166 - 169      .price-table tr:nth-child(even)  2  (Property Name Error, Syntax Error)
  170 - 170      Comment: Contact Form            1  (Comment Error)
  171 - 178      .contact-form { }                2  (Layout Error (Flexbox/Grid), Syntax Error)
  179 - 186      .contact-form input, .contact-fo 3  (Property Name Error, Syntax Error)
  187 - 191      .contact-form input:focus { }    2  (Invalid Value Error, Syntax Error)
  193 - 199      .site-footer { }                 2  (Color Error, Property Name Error)
  200 - 205      .social a { }                    2  (Property Name Error)
  206 - 210      @keyframes fadeIn                2  (Animation / Transition Error, Unit Error)
  212 - 224      @media (responsive)              1  (Unit Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
