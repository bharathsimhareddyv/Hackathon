======================================================================
  JS-10  |  JavaScript  |  Rhythm Dance Studio
======================================================================

File to fix      : script.js
Errors hidden    : 52
Difficulty       : 39 / 100   (Easy 26, Medium 21, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 26
  ReferenceError                           x 9
  Logic Error                              x 4
  TypeError                                x 4
  Object / Class Error                     x 2
  String Method Error                      x 2
  Type Coercion Error                      x 1
  JSON Error                               x 1
  Loop Error                               x 1
  Array Method Error                       x 1
  Function / Return Error                  x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * String Method Error
    ${ } only works inside backticks ` `. Check string method names (trim, toUpperCase).

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

  * JSON Error
    JSON keys need double quotes and there must be no comma before }. Use JSON.parse() to read it.

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * Array Method Error
    map() makes a new array (forEach doesn't). sort numbers with (a, b) => a - b. Give reduce a starting value 0.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 13         Task 1                           1  (ReferenceError)
  14 - 29        Task 2                           4  (ReferenceError, SyntaxError)
  30 - 41        Task 3                           3  (Logic Error, Object / Class Error, SyntaxError)
  42 - 48        Task 4                           3  (ReferenceError, SyntaxError, Type Coercion Error)
  49 - 54        Task 5                           2  (SyntaxError)
  55 - 61        Task 6                           2  (ReferenceError)
  62 - 67        Task 7                           3  (JSON Error, SyntaxError, TypeError)
  68 - 73        Task 8                           3  (String Method Error, SyntaxError)
  74 - 79        Task 9                           2  (Object / Class Error, SyntaxError)
  80 - 88        Task 10                          4  (Logic Error, Loop Error, ReferenceError, TypeError)
  89 - 96        Task 11                          1  (SyntaxError)
  103 - 110      Task 13                          4  (Logic Error, SyntaxError, TypeError)
  111 - 116      Task 14                          2  (String Method Error, SyntaxError)
  117 - 121      Task 15                          2  (ReferenceError, SyntaxError)
  122 - 130      Task 16                          2  (Logic Error, SyntaxError)
  131 - 136      Task 17                          2  (SyntaxError)
  137 - 146      Task 18                          4  (SyntaxError)
  147 - 152      Task 19                          2  (ReferenceError, TypeError)
  153 - 158      Task 20                          2  (Array Method Error, SyntaxError)
  159 - 169      Task 21                          4  (Function / Return Error, ReferenceError, SyntaxError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
