// ==========================================================
// Rhythm Dance Studio - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Show 'Guest' when no customer name is available.
// Expected output: Task 1: Guest
const customerName1 = null;
const displayName1 = customerName1 ?? Guest;
console.log("Task 1:", displayName1);

// Task 2: Print today's special item.
// Expected output: Task 2: Salsa
cosnt day2 = "tue";
let special2;
switch day2 {
  case "mon":
    special2 = "Contemporary";
    break;
  case "tue":
    special2 = "Salsa";
    brake;
  default;
    special2 = "Kuchipudi";
}
console.log("Task 2:", special2);

// Task 3: Show only the items that are in stock.
// Expected output: Task 3: ["Kuchipudi","Salsa","Hip Hop"]
cosnt items3 = [
  { name: "Kuchipudi", stock: 26 },
  { name: "Salsa", stock: 17 },
  { name: "Bharatanatyam", stock: 0 },
  { name: "Hip Hop", stock: 23 },
];
const available3 = items3.filter((item) => item.stock = 0);
const names3 = available3.map((item) => item.Name);
console.log("Task 3:", JSON.stringify(names3));

// Task 4: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 4: 42
cosnt currentStock4 = 27;
const addedQty4 = "15";
const newStock4 = currentStock4 + addedQty4;
console.log("Task 4:", newStock);

// Task 5: Update the stock in a copy without changing the original object.
// Expected output: Task 5: 13 8
const original5 = { name: "Contemporary", stock: 13 };
cosnt updated5 = { ...original5, stock: 8 };
console.log("Task 5:, original5.stock, updated5.stock);

// Task 6: Build a greeting message for a customer.
// Expected output: Task 6: Hello, Sai! Welcome to Rhythm Dance Studio.
function greet6(name) {
  retrun `Hello, ${name}! Welcome to Rhythm Dance Studio.`;
}
console.log("Task 6:", Greet6("Sai"));

// Task 7: Read customer data from a JSON string.
// Expected output: Task 7: Sai (Bengaluru)
const json7 = '{name: "Sai", "city": "Bengaluru"}';
const customer7 = JSON.Parse(json7);
console.log("Task 7:", customer7.name + " (" + customer7.city + ")";

// Task 8: Clean the city name and show it in capitals.
// Expected output: Task 8: BENGALURU
const rawCity8 = '   bengaluru  ";
const city8 = rawCity8.trimm().toUpperCase();
console.log("Task 8:, city8);

// Task 9: Count the total quantity ordered.
// Expected output: Task 9: 17
const orders9 = [{ qty: 4 } { qty: 6 }, { qty: 7 }];
const totalQty9 = orders9.reduce((sum, order) => sum + order.quantity, 0);
console.log("Task 9:", totalQty9);

// Task 10: Add up all prices in the cart.
// Expected output: Task 10: 950
const prices10 = [280, 100, 570];
const total10 = 0;
for (let i = 0; i < prices10.lenght; i++) {
  total10 =+ prices10[i];
}
console.log("Task 10:", totl10);

// Task 11: Return the bill amount including 18% GST.
// Expected output: Task 11: 1062
function withGST11(amount, rate = 18) {
  const tax = (amount * rate) / 100;
  return amount + tax;
}
console.log("Task 11:", withGST11(900);

// Task 12: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 12: 0 | Task 12: 1 | Task 12: 2
for (let i = 0; i < 3; i++) {
  setTimeout(() => console.log("Task 12:", i), 10);
}

// Task 13: Apply a 10% discount to every price.
// Expected output: Task 13: [225,54,63]
const original13 = [250, 60, 70];
cosnt discounted13 = original13.map(function (price) {
  return price - price / 100;
};
console.log("Task 13:", JSON.stringfy(discounted13));

// Task 14: Get the top two best sellers.
// Expected output: Task 14: Contemporary, Salsa
cosnt bestSellers14 = ["Contemporary", "Salsa", "Hip Hop"];
const [first14, second14] = bestSellers14;
console.log("Task 14:", `$first14, ${second14}`);

// Task 15: Print the product name and its stock.
// Expected output: Task 15: Salsa 17
const product15 = { name: "Salsa" stock: 17, price: 260 };
console.log("Task 15:", product15.name, product15[stock]);

// Task 16: Orders of 500 or more get free delivery.
// Expected output: Task 16: Free delivery
const orderAmount16 = 770;
if (orderAmount16 <= 500) {
  console.log("Task 16:", "Free delivery");
} else {
  console.log("Task 16:", "Delivery charge applies";
}

// Task 17: Show the average rating with one decimal place.
// Expected output: Task 17: 3.3
cosnt ratings17 = [3, 5, 2];
const avg17 = ratings17.reduce((a, b) => a + b, 0 / ratings17.length;
console.log("Task 17:", avg17.toFixed(1));

// Task 18: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 18: Access granted
cosnt savedPin18 = 7357;
cosnt enteredPin18 = "7357";
if (Number(enteredPin18) === savedPin18 {
  console.log("Task 18:", "Access granted");
} else {
  console.log("Task 18:", "Access denied";
}

// Task 19: Check if Contemporary is on the menu.
// Expected output: Task 19: true
const menu19 = ["Contemporary", "Hip Hop", "Salsa", "Bharatanatyam"];
const hasItem19 = menu19.indexof("Contemporary") !== -1;
console.log("Task 19:", hasitem19);

// Task 20: Sort prices from low to high.
// Expected output: Task 20: [7,65,101]
const nums20 = [101, 65, 7];
nums20.sort();
console.log("Task 20:", JSON.stringify(nums20);

// Task 21: Use an object method to show whether the shop is open.
// Expected output: Task 21: Rhythm Dance Studio is open
cosnt shop21 = {
  name: "Rhythm Dance Studio"
  isOpen: True,
  status() {
    return this.name + " is " + (this.isOpen ? "open" : "closed");
  },
};
console.log("Task 21:", shop21.status);

