======================================================================
  REACT-10  |  React  |  Pixel Arena
======================================================================

File to fix      : App.jsx
Errors hidden    : 52
Difficulty       : 39 / 100   (Easy 26, Medium 21, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JavaScript Syntax Error                  x 14
  JSX Syntax Error                         x 12
  JavaScript Error                         x 10
  JSX Attribute Error                      x 4
  Props Error                              x 4
  Import / Export Error                    x 2
  List & Key Error                         x 2
  Component Definition Error               x 2
  Style Prop Error                         x 1
  Event Handling Error                     x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * Style Prop Error
    style takes an object: style={{ backgroundColor: color }} (double braces, camelCase keys).

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            5  (JavaScript Error)
  19 - 36        Tabs component                   3  (JSX Attribute Error, JSX Syntax Error, JavaScript Error)
  37 - 44        Greeting component               2  (JavaScript Syntax Error)
  45 - 60        Wishlist component               4  (JSX Syntax Error, JavaScript Syntax Error, List & Key Error)
  61 - 68        Rating component                 1  (JavaScript Error)
  69 - 79        Timer component                  1  (JavaScript Syntax Error)
  80 - 88        Header component                 2  (Component Definition Error, JSX Attribute Error)
  89 - 101       CartSummary component            1  (JSX Syntax Error)
  102 - 116      SearchBar component              3  (JSX Attribute Error, JSX Syntax Error)
  117 - 129      ProductList component            5  (JSX Syntax Error, JavaScript Syntax Error, List & Key Error, Props Error)
  130 - 138      Footer component                 1  (JavaScript Syntax Error)
  139 - 146      Banner component                 2  (JavaScript Syntax Error, Style Prop Error)
  147 - 156      FAQItem component                2  (JSX Syntax Error, JavaScript Error)
  157 - 170      ProductCard component            3  (JSX Syntax Error, Props Error)
  171 - 183      Counter component                2  (JSX Syntax Error, JavaScript Error)
  184 - 203      ContactForm component            6  (Event Handling Error, JSX Syntax Error, JavaScript Syntax Error)
  204 - 233      App component                    8  (Component Definition Error, Import / Export Error, JSX Syntax Error, JavaScript Error, JavaScript Syntax Error, Props Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
