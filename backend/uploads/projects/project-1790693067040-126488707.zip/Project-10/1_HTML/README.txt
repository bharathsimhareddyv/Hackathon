======================================================================
  HTML-10  |  HTML  |  Slice of Heaven
======================================================================

File to fix      : index.html
Errors hidden    : 52
Difficulty       : 36 / 100   (Easy 34, Medium 11, Hard 7)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. Open index.html in Chrome/Firefox.
  2. Go to https://validator.w3.org/#validate_by_input and paste the whole file. Fix the FIRST error, re-check, repeat.
  3. Then click every link and try the form.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 33
  Attribute Error                          x 5
  Link / Path Error                        x 5
  Form Error                               x 3
  Table Error                              x 2
  Document Setup Error                     x 1
  Duplicate ID Error                       x 1
  Entity / Special Character Error         x 1
  Accessibility Error                      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Attribute Error
    Every attribute looks like name="value" - check spelling (class, href, src, required), the = sign, and BOTH quotes. a/link use href; img/script/source use src.

  * Link / Path Error
    Click every link. #links must match an id exactly. URLs start with https:// . Paths use / not \. Email = mailto: , phone = tel: .

  * Form Error
    Valid input types: text, email, tel, date, checkbox... Form method is get or post. Button type is submit. Close <textarea>.

  * Table Error
    Each row is <tr><td>..</td><td>..</td></tr>. A <th> closes with </th>, a <td> with </td>.

  * Document Setup Error
    Compare the first lines with the standard skeleton: <!DOCTYPE html>, <meta charset="UTF-8">, <meta name="viewport" content="width=device-width, initial-scale=1.0">.

  * Duplicate ID Error
    Use Ctrl+F on id=" - every id value must appear only once on the page.

  * Entity / Special Character Error
    Codes like &copy; &amp; &#8377; must end with a semicolon. Write &lt; instead of a raw < in text.

  * Accessibility Error
    Every <img> needs alt="...". A <label for="x"> must match an input with id="x". Every <iframe> needs a title.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 10         Head (document setup)            4  (Attribute Error, Document Setup Error, Syntax Error)
  11 - 22        Header & navigation              3  (Link / Path Error, Syntax Error)
  23 - 31        About section                    2  (Link / Path Error, Syntax Error)
  32 - 43        FAQ section                      2  (Attribute Error, Syntax Error)
  44 - 50        Hero section                     3  (Syntax Error)
  51 - 70        Price table                      6  (Syntax Error, Table Error)
  71 - 86        Gallery                          7  (Duplicate ID Error, Link / Path Error, Syntax Error)
  87 - 98        Products list                    4  (Entity / Special Character Error, Syntax Error)
  99 - 110       Media section                    4  (Attribute Error, Syntax Error)
  111 - 125      Team section                     5  (Syntax Error)
  126 - 150      Contact form                     8  (Accessibility Error, Attribute Error, Form Error, Syntax Error)
  151 - 158      Footer & closing tags            4  (Link / Path Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
