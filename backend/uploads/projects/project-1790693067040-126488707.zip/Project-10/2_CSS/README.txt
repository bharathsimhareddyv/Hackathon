======================================================================
  CSS-10  |  CSS  |  Ink and Paper
======================================================================

File to fix      : style.css
Errors hidden    : 58
Difficulty       : 39 / 100   (Easy 24, Medium 32, Hard 2)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. index.html is CORRECT - do not edit it. Fix style.css only.
  2. Open index.html in the browser, press F12 > Elements, click an element and look at Styles: crossed-out lines are errors.
  3. Also paste style.css into https://jigsaw.w3.org/css-validator/#validate_by_input

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 18
  Property Name Error                      x 15
  Comment Error                            x 6
  Invalid Value Error                      x 5
  Color Error                              x 3
  Pseudo-class / Pseudo-element Error      x 3
  Animation / Transition Error             x 2
  Layout Error (Flexbox/Grid)              x 2
  At-rule Error                            x 1
  Font Error                               x 1
  Media Query Error                        x 1
  Unit Error                               x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Property Name Error
    Look for misspelled property names (DevTools shows them crossed out). Use VS Code autocomplete to check spelling.

  * Comment Error
    CSS comments are only /* ... */ . '//' is not a comment, and every /* needs a */.

  * Invalid Value Error
    The property is right but the value is not allowed. Check spelling of keywords (center, solid, absolute...), no commas in padding/margin, decimals use a dot.

  * Color Error
    Hex colours have 3 or 6 digits using only 0-9 and a-f. Check colour names and close rgba( ).

  * Pseudo-class / Pseudo-element Error
    :hover :focus :nth-child() use ONE colon; ::before ::after use TWO. Check spelling.

  * Animation / Transition Error
    @keyframes (with s), from/to, times need 's', and the animation name must match the keyframes name exactly (case!).

  * Layout Error (Flexbox/Grid)
    display: flex / grid. Check spelling of flex values (space-between, center, column) and commas inside repeat() and minmax().

  * At-rule Error
    @import must be spelled exactly and url("...") must be closed with ).

  * Font Error
    Close the quotes around font names. The generic font is sans-serif (with hyphen). font-weight: bold or 700.

  * Media Query Error
    Correct form: @media (max-width: 768px) { ... } - parentheses, colon, unit, space after 'and', closing }.

  * Unit Error
    Numbers need a unit (px, rem, %, s, deg) with NO space: 12px not 12 px. z-index and font-weight have NO unit.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 2          @import (fonts)                  1  (At-rule Error)
  4 - 10         :root { }                        1  (Color Error)
  12 - 17        * { }                            1  (Property Name Error)
  18 - 24        body { }                         4  (Color Error, Font Error, Invalid Value Error, Syntax Error)
  25 - 25        Comment: Header                  1  (Comment Error)
  34 - 40        .logo { }                        1  (Syntax Error)
  53 - 57        .nav-links a:hover { }           1  (Pseudo-class / Pseudo-element Error)
  58 - 58        Comment: Hero                    1  (Comment Error)
  59 - 66        .hero { }                        3  (Property Name Error, Syntax Error)
  67 - 72        .hero-title { }                  2  (Invalid Value Error, Syntax Error)
  73 - 77        .hero-text { }                   1  (Animation / Transition Error)
  78 - 78        Comment: Buttons                 1  (Comment Error)
  79 - 88        .btn { }                         3  (Invalid Value Error, Syntax Error)
  94 - 98        .btn-primary { }                 1  (Property Name Error)
  100 - 106      .card-grid { }                   2  (Layout Error (Flexbox/Grid), Syntax Error)
  107 - 115      .card { }                        3  (Property Name Error, Syntax Error)
  116 - 121      .card-img { }                    1  (Invalid Value Error)
  122 - 127      .card-title { }                  2  (Property Name Error, Syntax Error)
  128 - 132      .card-title::before { }          1  (Syntax Error)
  133 - 138      .price { }                       1  (Property Name Error)
  139 - 150      .badge { }                       2  (Property Name Error)
  151 - 151      Comment: Pricing Table           1  (Comment Error)
  159 - 165      .price-table th, .price-table td 1  (Property Name Error)
  166 - 169      .price-table tr:nth-child(even)  1  (Pseudo-class / Pseudo-element Error)
  171 - 178      .contact-form { }                3  (Property Name Error, Syntax Error)
  179 - 186      .contact-form input, .contact-fo 1  (Syntax Error)
  187 - 191      .contact-form input:focus { }    4  (Color Error, Property Name Error, Pseudo-class / Pseudo-element Error, Syntax Error)
  192 - 192      Comment: Footer                  1  (Comment Error)
  193 - 199      .site-footer { }                 4  (Property Name Error, Syntax Error)
  200 - 205      .social a { }                    2  (Property Name Error)
  206 - 210      @keyframes fadeIn                1  (Animation / Transition Error)
  211 - 211      Comment: Responsive              1  (Comment Error)
  212 - 224      @media (responsive)              4  (Layout Error (Flexbox/Grid), Media Query Error, Syntax Error, Unit Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
