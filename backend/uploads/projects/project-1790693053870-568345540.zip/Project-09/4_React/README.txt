======================================================================
  REACT-09  |  React  |  Spice Route Kitchen
======================================================================

File to fix      : App.jsx
Errors hidden    : 53
Difficulty       : 39 / 100   (Easy 26, Medium 22, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 17
  JavaScript Error                         x 10
  JavaScript Syntax Error                  x 9
  List & Key Error                         x 3
  JSX Attribute Error                      x 3
  Component Definition Error               x 3
  Import / Export Error                    x 2
  Event Handling Error                     x 2
  Props Error                              x 2
  Style Prop Error                         x 1
  State Mutation Error                     x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

  * Style Prop Error
    style takes an object: style={{ backgroundColor: color }} (double braces, camelCase keys).

  * State Mutation Error
    Never push/splice/++ state. Call the setter with a NEW array/object: setItems([...items, x]).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            6  (JavaScript Error, List & Key Error)
  19 - 31        CartSummary component            2  (JSX Syntax Error)
  32 - 40        Header component                 3  (JSX Attribute Error, JSX Syntax Error)
  41 - 55        SearchBar component              3  (JSX Attribute Error, JSX Syntax Error, JavaScript Syntax Error)
  64 - 81        Tabs component                   5  (JSX Attribute Error, JSX Syntax Error, JavaScript Error, JavaScript Syntax Error)
  82 - 94        Counter component                4  (Event Handling Error, JavaScript Error, JavaScript Syntax Error)
  95 - 114       ContactForm component            2  (JSX Syntax Error, JavaScript Syntax Error)
  115 - 123      Footer component                 1  (JSX Syntax Error)
  124 - 134      Timer component                  1  (JavaScript Error)
  135 - 144      FAQItem component                3  (JSX Syntax Error, JavaScript Syntax Error)
  145 - 160      Wishlist component               4  (JSX Syntax Error, JavaScript Syntax Error, List & Key Error)
  161 - 173      ProductList component            2  (Component Definition Error, JSX Syntax Error)
  174 - 187      ProductCard component            3  (Event Handling Error, JSX Syntax Error)
  188 - 195      Rating component                 3  (JSX Syntax Error, JavaScript Error, List & Key Error)
  196 - 203      Banner component                 2  (JSX Syntax Error, Style Prop Error)
  204 - 233      App component                    8  (Component Definition Error, Import / Export Error, JavaScript Error, JavaScript Syntax Error, Props Error, State Mutation Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
