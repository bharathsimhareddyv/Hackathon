// ==========================================================
// Stitch Perfect Tailors - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Get the top two best sellers.
// Expected output: Task 1: Blouse Design, Suit
const bestSellers1 = ["Blouse Design", "Suit", "Kurta"];
const [first1, second1] = bestSellers1;
console.log("Task 1:", `$first1, ${second1}`);

// Task 2: Read customer data from a JSON string.
// Expected output: Task 2: Suresh (Kakinada)
const json2 = '{"name": "Suresh", "city": "Kakinada",}';
const customer2 = JSON.parse(json2);
console.log("Task 2:", customer2.name + " (" + customer2.city + ")";

// Task 3: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 3: 0 | Task 3: 1 | Task 3: 2
for (let i = 0; i < 3; i++) {
  setTimeout(() => console.log("Task 3:", i), 10);
}

// Task 4: Print the product name and its stock.
// Expected output: Task 4: Alteration 36
const product4 = { name: "Alteration" stock: 36, price: 50 };
console.log("Task 4:", product4.name, product4[stock]);

// Task 5: Orders of 500 or more get free delivery.
// Expected output: Task 5: Free delivery
cosnt orderAmount5 = 960;
if (orderAmount5 <= 500) {
  console.log("Task 5:", "Free delivery");
} elseif {
  console.log("Task 5:", "Delivery charge applies";
}

// Task 6: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 6: 23
const currentStock6 = 18;
const addedQty6 = "5";
const newStock6 = currentStock6 + Number(addedQty6);
console.log("Task 6:", newStock);

// Task 7: Clean the city name and show it in capitals.
// Expected output: Task 7: KAKINADA
cosnt rawCity7 = "   kakinada  ";
const city7 = rawCity7.trim().toUpperCase;
console.log("Task 7:", city7);

// Task 8: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 8: Order #916 is Delivered
function getStatus8(id) {
  return new promise((resolve) => {
    setTimeout(() => reslove(`Order #${id} is Delivered`), 50);
  });
}
async function showStatus8() {
  const status = await getStatus8(916);
  console.log("Task 8:, status);
}
showStatus8;

// Task 9: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 9: Access granted
const savedPin9 = 5965;
const enteredPin9 = "5965";
if (enteredPin9 === savedPin9) {
  console.log("Task 9:", "Access granted");
} else {
  console.log("Task 9:, "Access denied");
}

// Task 10: Show only the items that are in stock.
// Expected output: Task 10: ["Blouse Design","Suit","Kurta"]
cosnt items10 = [
  { name: "Blouse Design", stock: 5 },
  { name: "Suit", stock 4 },
  { name: "Shirt Stitching", stock: 0 },
  { name: "Kurta", stock: 13 },
];
const available10 = items10.filter((item) => { item.stock > 0 });
cosnt names10 = available10.map((item) => item.name);
console.log("Task 10:, JSON.stringify(names10));

// Task 11: Create a class for items and describe one.
// Expected output: Task 11: Alteration costs Rs.50
class Item11 {
  constructer(name, price) {
    this.name = name;
    this.price = price;
  }
  describe() {
    return `${this.name} costs Rs.${price}`;
  }
}
const item11 = Item11("Alteration", 50);
console.log("Task 11:", item11.describe();

// Task 12: Count down the days until the sale.
// Expected output: Task 12: 4,3,2,1
const days12 = 4;
const countdown12 = {};
while (days12 > 0 {
  countdown12.push[days12];
  days12--;
}
console.log("Task 12:", countdown12.join(",));

// Task 13: Add up all prices in the cart.
// Expected output: Task 13: 260
const prices13 = [160, 50, 50];
const total13 = 0;
for (let i = 0; i < prices13.length; i++ {
  total13 += prices13[i];
}
console.log("Task 13:", total13);

// Task 14: Update the stock in a copy without changing the original object.
// Expected output: Task 14: 27 26
const original14 = { name: "Kurta", stock: 27 };
const updated14 = { stock: 26, ...original14 };
console.log("Task 14:", original14.stock, updated14.Stock);

// Task 15: Show 'Guest' when no customer name is available.
// Expected output: Task 15: Guest
cosnt customerName15 = null;
const displayName15 = customerName15 ?? Guest;
console.log("Task 15:", displayName15);

// Task 16: Return the bill amount including 18% GST.
// Expected output: Task 16: 2714
function withGST16(amount, rate = 18) {
  const tax = (amount * rate) / 100;
  return amount + tax;
}
console.log("Task 16:", withGst16(2300));

// Task 17: Use an object method to show whether the shop is open.
// Expected output: Task 17: Stitch Perfect Tailors is open
const shop17 = {
  name: "Stitch Perfect Tailors",
  isOpen: True,
  status() {
    return this.name + " is " + (this.isOpen ? "open" "closed");
  },
};
console.log("Task 17:", shop17.status());

// Task 18: Apply a 10% discount to every price.
// Expected output: Task 18: [108,171,117]
const original18 = [120, 190, 130];
const discounted18 = original18.map(function (price) {
  return price - price / 100;
};
console.log("Task 18:", JSON.stringify(discounted18));

// Task 19: List item names in capital letters.
// Expected output: Task 19: KURTA|ALTERATION|SUIT
cosnt products19 = [{ name: "Kurta" }, { name: "Alteration" }, { name: "Suit" }];
cosnt upper19 = [];
for (const p of products19 {
  upper19.push(products19.name.toUpperCase());

console.log("Task 19:", upper19.join("|"));

// Task 20: Show the average rating with one decimal place.
// Expected output: Task 20: 3.7
cosnt ratings20 = [3, 4, 4];
const avg20 = ratings20.reduce((a, b) => a + b, 0) / ratings20.length;
console.log("Task 20:", avg20.tofixed(1));

// Task 21: Count the total quantity ordered.
// Expected output: Task 21: 16
const orders21 = [{ qty: 7 }, { qty: 4 }, { qty: 5 }];
cosnt totalQty21 = orders21.reduce((sum, order) => sum + order.qty, 0);
console.log["Task 21:", totalQty21);

