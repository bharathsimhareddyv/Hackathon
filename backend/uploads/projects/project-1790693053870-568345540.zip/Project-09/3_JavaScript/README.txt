======================================================================
  JS-09  |  JavaScript  |  Stitch Perfect Tailors
======================================================================

File to fix      : script.js
Errors hidden    : 52
Difficulty       : 39 / 100   (Easy 26, Medium 21, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 26
  ReferenceError                           x 8
  TypeError                                x 5
  Logic Error                              x 4
  Function / Return Error                  x 4
  Object / Class Error                     x 2
  String Method Error                      x 1
  JSON Error                               x 1
  Type Coercion Error                      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * String Method Error
    ${ } only works inside backticks ` `. Check string method names (trim, toUpperCase).

  * JSON Error
    JSON keys need double quotes and there must be no comma before }. Use JSON.parse() to read it.

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 13         Task 1                           1  (String Method Error)
  14 - 19        Task 2                           2  (JSON Error, SyntaxError)
  26 - 30        Task 4                           2  (ReferenceError, SyntaxError)
  31 - 39        Task 5                           4  (Logic Error, SyntaxError)
  40 - 46        Task 6                           1  (ReferenceError)
  47 - 52        Task 7                           2  (Function / Return Error, SyntaxError)
  53 - 65        Task 8                           4  (Function / Return Error, ReferenceError, SyntaxError)
  66 - 75        Task 9                           2  (SyntaxError, Type Coercion Error)
  76 - 87        Task 10                          5  (Function / Return Error, SyntaxError)
  88 - 101       Task 11                          4  (Object / Class Error, ReferenceError, SyntaxError, TypeError)
  102 - 111      Task 12                          5  (Function / Return Error, SyntaxError, TypeError)
  112 - 120      Task 13                          2  (SyntaxError, TypeError)
  121 - 126      Task 14                          2  (Logic Error, Object / Class Error)
  127 - 132      Task 15                          2  (ReferenceError, SyntaxError)
  133 - 140      Task 16                          1  (ReferenceError)
  141 - 151      Task 17                          2  (ReferenceError, SyntaxError)
  152 - 159      Task 18                          2  (Logic Error, SyntaxError)
  160 - 168      Task 19                          5  (Logic Error, SyntaxError)
  169 - 174      Task 20                          2  (SyntaxError, TypeError)
  175 - 180      Task 21                          2  (SyntaxError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
