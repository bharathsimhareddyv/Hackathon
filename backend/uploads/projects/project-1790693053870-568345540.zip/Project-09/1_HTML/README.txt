======================================================================
  HTML-09  |  HTML  |  Chapter One Books
======================================================================

File to fix      : index.html
Errors hidden    : 58
Difficulty       : 42 / 100   (Easy 29, Medium 19, Hard 10)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. Open index.html in Chrome/Firefox.
  2. Go to https://validator.w3.org/#validate_by_input and paste the whole file. Fix the FIRST error, re-check, repeat.
  3. Then click every link and try the form.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 27
  Attribute Error                          x 11
  Link / Path Error                        x 5
  Form Error                               x 4
  Nesting / Structure Error                x 3
  Table Error                              x 3
  Entity / Special Character Error         x 2
  Document Setup Error                     x 1
  Accessibility Error                      x 1
  Duplicate ID Error                       x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Attribute Error
    Every attribute looks like name="value" - check spelling (class, href, src, required), the = sign, and BOTH quotes. a/link use href; img/script/source use src.

  * Link / Path Error
    Click every link. #links must match an id exactly. URLs start with https:// . Paths use / not \. Email = mailto: , phone = tel: .

  * Form Error
    Valid input types: text, email, tel, date, checkbox... Form method is get or post. Button type is submit. Close <textarea>.

  * Nesting / Structure Error
    Tags close in reverse order: <li><a>..</a></li>. Lists (ul/ol) can only contain <li>.

  * Table Error
    Each row is <tr><td>..</td><td>..</td></tr>. A <th> closes with </th>, a <td> with </td>.

  * Entity / Special Character Error
    Codes like &copy; &amp; &#8377; must end with a semicolon. Write &lt; instead of a raw < in text.

  * Document Setup Error
    Compare the first lines with the standard skeleton: <!DOCTYPE html>, <meta charset="UTF-8">, <meta name="viewport" content="width=device-width, initial-scale=1.0">.

  * Accessibility Error
    Every <img> needs alt="...". A <label for="x"> must match an input with id="x". Every <iframe> needs a title.

  * Duplicate ID Error
    Use Ctrl+F on id=" - every id value must appear only once on the page.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 10         Head (document setup)            4  (Document Setup Error, Syntax Error)
  11 - 22        Header & navigation              5  (Attribute Error, Link / Path Error, Syntax Error)
  23 - 31        About section                    6  (Link / Path Error, Nesting / Structure Error, Syntax Error)
  32 - 47        Gallery                          3  (Attribute Error, Syntax Error)
  48 - 72        Contact form                     11  (Accessibility Error, Attribute Error, Duplicate ID Error, Form Error, Link / Path Error, Syntax Error)
  73 - 84        FAQ section                      4  (Attribute Error, Syntax Error)
  85 - 96        Products list                    5  (Attribute Error, Entity / Special Character Error, Syntax Error)
  97 - 108       Media section                    2  (Attribute Error)
  109 - 123      Team section                     3  (Nesting / Structure Error, Syntax Error)
  124 - 143      Price table                      6  (Syntax Error, Table Error)
  144 - 150      Hero section                     4  (Attribute Error, Link / Path Error, Syntax Error)
  151 - 158      Footer & closing tags            5  (Link / Path Error, Nesting / Structure Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
