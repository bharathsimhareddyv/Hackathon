======================================================================
  HTML-02  |  HTML  |  Bean There Cafe
======================================================================

File to fix      : index.html
Errors hidden    : 56
Difficulty       : 34 / 100   (Easy 38, Medium 12, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. Open index.html in Chrome/Firefox.
  2. Go to https://validator.w3.org/#validate_by_input and paste the whole file. Fix the FIRST error, re-check, repeat.
  3. Then click every link and try the form.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 38
  Table Error                              x 4
  Accessibility Error                      x 4
  Attribute Error                          x 3
  Form Error                               x 3
  Document Setup Error                     x 2
  Link / Path Error                        x 2

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Table Error
    Each row is <tr><td>..</td><td>..</td></tr>. A <th> closes with </th>, a <td> with </td>.

  * Accessibility Error
    Every <img> needs alt="...". A <label for="x"> must match an input with id="x". Every <iframe> needs a title.

  * Attribute Error
    Every attribute looks like name="value" - check spelling (class, href, src, required), the = sign, and BOTH quotes. a/link use href; img/script/source use src.

  * Form Error
    Valid input types: text, email, tel, date, checkbox... Form method is get or post. Button type is submit. Close <textarea>.

  * Document Setup Error
    Compare the first lines with the standard skeleton: <!DOCTYPE html>, <meta charset="UTF-8">, <meta name="viewport" content="width=device-width, initial-scale=1.0">.

  * Link / Path Error
    Click every link. #links must match an id exactly. URLs start with https:// . Paths use / not \. Email = mailto: , phone = tel: .

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 10         Head (document setup)            6  (Document Setup Error, Syntax Error)
  11 - 22        Header & navigation              4  (Syntax Error)
  23 - 34        Products list                    4  (Syntax Error)
  35 - 54        Price table                      7  (Syntax Error, Table Error)
  55 - 63        About section                    2  (Syntax Error)
  64 - 70        Hero section                     3  (Accessibility Error, Link / Path Error, Syntax Error)
  71 - 82        Media section                    2  (Accessibility Error, Syntax Error)
  83 - 107       Contact form                     6  (Accessibility Error, Attribute Error, Form Error, Syntax Error)
  108 - 122      Team section                     4  (Syntax Error)
  123 - 134      FAQ section                      5  (Syntax Error)
  135 - 150      Gallery                          10  (Accessibility Error, Attribute Error, Syntax Error)
  151 - 158      Footer & closing tags            3  (Link / Path Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
