======================================================================
  CSS-02  |  CSS  |  CarePlus Clinic
======================================================================

File to fix      : style.css
Errors hidden    : 56
Difficulty       : 44 / 100   (Easy 22, Medium 26, Hard 8)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. index.html is CORRECT - do not edit it. Fix style.css only.
  2. Open index.html in the browser, press F12 > Elements, click an element and look at Styles: crossed-out lines are errors.
  3. Also paste style.css into https://jigsaw.w3.org/css-validator/#validate_by_input

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 20
  Invalid Value Error                      x 8
  Property Name Error                      x 8
  Selector Error                           x 4
  Unit Error                               x 4
  CSS Variable Error                       x 2
  Layout Error (Flexbox/Grid)              x 2
  Animation / Transition Error             x 2
  Comment Error                            x 2
  At-rule Error                            x 1
  Font Error                               x 1
  Pseudo-class / Pseudo-element Error      x 1
  Color Error                              x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Invalid Value Error
    The property is right but the value is not allowed. Check spelling of keywords (center, solid, absolute...), no commas in padding/margin, decimals use a dot.

  * Property Name Error
    Look for misspelled property names (DevTools shows them crossed out). Use VS Code autocomplete to check spelling.

  * Selector Error
    Open index.html next to style.css. Classes start with '.', ids with '#'. The name must match the HTML exactly.

  * Unit Error
    Numbers need a unit (px, rem, %, s, deg) with NO space: 12px not 12 px. z-index and font-weight have NO unit.

  * CSS Variable Error
    Variables are declared as --name: value; inside :root and used as var(--name). Names must match exactly.

  * Layout Error (Flexbox/Grid)
    display: flex / grid. Check spelling of flex values (space-between, center, column) and commas inside repeat() and minmax().

  * Animation / Transition Error
    @keyframes (with s), from/to, times need 's', and the animation name must match the keyframes name exactly (case!).

  * Comment Error
    CSS comments are only /* ... */ . '//' is not a comment, and every /* needs a */.

  * At-rule Error
    @import must be spelled exactly and url("...") must be closed with ).

  * Font Error
    Close the quotes around font names. The generic font is sans-serif (with hyphen). font-weight: bold or 700.

  * Pseudo-class / Pseudo-element Error
    :hover :focus :nth-child() use ONE colon; ::before ::after use TWO. Check spelling.

  * Color Error
    Hex colours have 3 or 6 digits using only 0-9 and a-f. Check colour names and close rgba( ).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 2          @import (fonts)                  1  (At-rule Error)
  4 - 10         :root { }                        1  (Syntax Error)
  12 - 17        * { }                            1  (Selector Error)
  18 - 24        body { }                         2  (CSS Variable Error, Syntax Error)
  26 - 33        .site-header { }                 2  (Layout Error (Flexbox/Grid), Selector Error)
  34 - 40        .logo { }                        1  (Font Error)
  41 - 46        .nav-links { }                   2  (Invalid Value Error, Property Name Error)
  53 - 57        .nav-links a:hover { }           3  (Invalid Value Error, Pseudo-class / Pseudo-element Error, Syntax Error)
  67 - 72        .hero-title { }                  3  (Syntax Error, Unit Error)
  73 - 77        .hero-text { }                   2  (Animation / Transition Error, Syntax Error)
  79 - 88        .btn { }                         4  (CSS Variable Error, Invalid Value Error, Property Name Error, Syntax Error)
  89 - 93        .btn:hover { }                   2  (Invalid Value Error, Syntax Error)
  99 - 99        Comment: Product Cards           1  (Comment Error)
  100 - 106      .card-grid { }                   2  (Syntax Error)
  107 - 115      .card { }                        2  (Property Name Error, Syntax Error)
  116 - 121      .card-img { }                    2  (Invalid Value Error, Unit Error)
  122 - 127      .card-title { }                  2  (Invalid Value Error, Syntax Error)
  128 - 132      .card-title::before { }          1  (Color Error)
  133 - 138      .price { }                       1  (Selector Error)
  139 - 150      .badge { }                       4  (Invalid Value Error, Property Name Error, Unit Error)
  151 - 151      Comment: Pricing Table           1  (Comment Error)
  152 - 158      .price-table { }                 1  (Syntax Error)
  171 - 178      .contact-form { }                2  (Property Name Error)
  179 - 186      .contact-form input, .contact-fo 2  (Syntax Error)
  193 - 199      .site-footer { }                 3  (Property Name Error, Syntax Error)
  200 - 205      .social a { }                    2  (Syntax Error)
  206 - 210      @keyframes fadeIn                2  (Animation / Transition Error, Unit Error)
  212 - 224      @media (responsive)              4  (Layout Error (Flexbox/Grid), Selector Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
