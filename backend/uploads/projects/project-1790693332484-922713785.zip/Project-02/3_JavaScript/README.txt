======================================================================
  JS-02  |  JavaScript  |  Frame Perfect Studio
======================================================================

File to fix      : script.js
Errors hidden    : 55
Difficulty       : 39 / 100   (Easy 28, Medium 21, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 28
  Logic Error                              x 6
  ReferenceError                           x 6
  Function / Return Error                  x 5
  TypeError                                x 4
  Object / Class Error                     x 2
  String Method Error                      x 2
  JSON Error                               x 1
  Array Method Error                       x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * String Method Error
    ${ } only works inside backticks ` `. Check string method names (trim, toUpperCase).

  * JSON Error
    JSON keys need double quotes and there must be no comma before }. Use JSON.parse() to read it.

  * Array Method Error
    map() makes a new array (forEach doesn't). sort numbers with (a, b) => a - b. Give reduce a starting value 0.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 13         Task 1                           2  (Logic Error, Object / Class Error)
  14 - 22        Task 2                           4  (Logic Error, SyntaxError, TypeError)
  29 - 38        Task 4                           4  (SyntaxError)
  39 - 47        Task 5                           4  (Function / Return Error, SyntaxError)
  48 - 59        Task 6                           2  (Function / Return Error, SyntaxError)
  60 - 65        Task 7                           1  (Logic Error)
  66 - 71        Task 8                           1  (SyntaxError)
  72 - 81        Task 9                           2  (SyntaxError, TypeError)
  82 - 88        Task 10                          1  (SyntaxError)
  89 - 94        Task 11                          1  (SyntaxError)
  95 - 107       Task 12                          5  (Function / Return Error, ReferenceError, SyntaxError)
  108 - 116      Task 13                          3  (Logic Error, ReferenceError, TypeError)
  117 - 122      Task 14                          3  (JSON Error, SyntaxError)
  123 - 128      Task 15                          2  (Object / Class Error, SyntaxError)
  129 - 144      Task 16                          4  (Logic Error, ReferenceError, SyntaxError)
  145 - 150      Task 17                          2  (String Method Error, SyntaxError)
  151 - 156      Task 18                          3  (Logic Error, SyntaxError)
  157 - 163      Task 19                          3  (ReferenceError, String Method Error, SyntaxError)
  164 - 171      Task 20                          4  (Array Method Error, Function / Return Error, SyntaxError, TypeError)
  172 - 182      Task 21                          4  (Function / Return Error, ReferenceError, SyntaxError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
