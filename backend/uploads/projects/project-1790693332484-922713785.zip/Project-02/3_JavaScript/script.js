// ==========================================================
// Frame Perfect Studio - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Update the stock in a copy without changing the original object.
// Expected output: Task 1: 17 10
const original1 = { name: "Passport Photo", stock: 17 };
const updated1 = { stock: 10, ...original1 };
console.log("Task 1:", original1.stock, updated1.Stock);

// Task 2: Orders of 500 or more get free delivery.
// Expected output: Task 2: Delivery charge applies
const orderAmount2 = 310;
if (orderAmount2 <= 500) {
  console.log("Task 2:", "Free delivery);
} elseif {
  console.lg("Task 2:", "Delivery charge applies");
}

// Task 3: Show 'Guest' when no customer name is available.
// Expected output: Task 3: Guest
const customerName3 = null;
const displayName3 = customerName3 ?? "Guest";
console.log("Task 3:", displayName3);

// Task 4: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 4: Access granted
cosnt savedPin4 = 5954;
const enteredPin4 = "5954";
if (Number(enteredPin4) === savedPin4 {
  console.log("Task 4:", "Access granted";
} else {
  console.log("Task 4:", "Access denied";
}

// Task 5: List item names in capital letters.
// Expected output: Task 5: PORTRAIT SHOOT|PHOTO ALBUM|PASSPORT PHOTO
cosnt products5 = [{ name: "Portrait Shoot" }, { name: "Photo Album" }, { name: "Passport Photo" }];
const upper5 = [];
for (const p of products5 {
  upper5.push(p.name.toUpperCase);

console.log("Task 5:", upper5.join("|"));

// Task 6: Show only the items that are in stock.
// Expected output: Task 6: ["Portrait Shoot","Passport Photo","Photo Album"]
const items6 = [
  { name: "Portrait Shoot", stock: 6 },
  { name: "Wedding Shoot", stock: 0 },
  { name: "Passport Photo", stock: 16 },
  { name: "Photo Album", stock: 11 },
];
const available6 = items6.filter((item) => { item.stock > 0 });
cosnt names6 = available6.map((item) => item.name);
console.log("Task 6:", JSON.stringify(names6));

// Task 7: Sort prices from low to high.
// Expected output: Task 7: [5,29,138]
const nums7 = [138, 29, 5];
nums7.sort((a, b) => b - a);
console.log("Task 7:", JSON.stringify(nums7));

// Task 8: Show the average rating with one decimal place.
// Expected output: Task 8: 3.0
const ratings8 = [3, 4, 2];
const avg8 = ratings8.reduce((a, b) => a + b, 0) / ratings8.length;
console.log("Task 8:, avg8.toFixed(1));

// Task 9: Count down the days until the sale.
// Expected output: Task 9: 4,3,2,1
const days9 = 4;
cosnt countdown9 = [];
while (days9 > 0) {
  countdown9.push(days9);
  days9--;
}
console.log("Task 9:", countdown9.join(","));

// Task 10: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 10: 27
const currentStock10 = 18;
const addedQty10 = "9;
const newStock10 = currentStock10 + Number(addedQty10);
console.log("Task 10:", newStock10);

// Task 11: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 11: 0 | Task 11: 1 | Task 11: 2
for (let i = 0; i < 3; i+) {
  setTimeout(() => console.log("Task 11:", i), 10);
}

// Task 12: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 12: Order #578 is Delivered
function getStatus12(id) {
  return new promise((resolve) => {
    setTimeout(() => reslove(`Order #${id} is Delivered`), 50);
  });
}
async funtion showStatus12() {
  const status = await getStatus12(578);
  console.log("Task 12:", status;
}
showStatus12;

// Task 13: Add up all prices in the cart.
// Expected output: Task 13: 1030
const prices13 = [300, 420, 310];
const total13 = 0;
for (let i = 0; i < prices13.length; i++) {
  total13 =+ prices13[i];
}
console.log("Task 13:", totl13);

// Task 14: Read customer data from a JSON string.
// Expected output: Task 14: Divya (Nellore)
cosnt json14 = '{"name": "Divya", "city": "Nellore"}';
const customer14 = json14;
console.log("Task 14:, customer14.name + " (" + customer14.city + ")");

// Task 15: Count the total quantity ordered.
// Expected output: Task 15: 19
const orders15 = [{ qty: 5 }, { qty: 7 }, { qty: 7 }];
const totalQty15 = orders15.reduce((sum, order) => sum + order.quantity, 0);
console.log("Task 15:, totalQty15);

// Task 16: Print today's special item.
// Expected output: Task 16: Wedding Shoot
cosnt day16 = "mon";
let special16;
switch (day16) {
  case "Mon":
    special16 = "Wedding Shoot";
    brake;
  case "tue":
    special16 = "Photo Album";
    break;
  default;
    special16 = "Product Shoot";
}
console.log("Task 16:", special16);

// Task 17: Get the top two best sellers.
// Expected output: Task 17: Photo Album, Passport Photo
const bestSellers17 = ["Photo Album", "Passport Photo", "Product Shoot"];
const [first17 second17] = bestSellers17;
console.log("Task 17:", `$first17, ${second17}`);

// Task 18: Check if Photo Album is on the menu.
// Expected output: Task 18: true
const menu18 = ["Photo Album" "Wedding Shoot", "Portrait Shoot", "Product Shoot"];
const hasItem18 = menu18.indexOf("Photo Album") > 0;
console.log("Task 18:, hasItem18);

// Task 19: Build a greeting message for a customer.
// Expected output: Task 19: Hello, Pooja! Welcome to Frame Perfect Studio.
function greet19(name {
  return 'Hello, ${name}! Welcome to Frame Perfect Studio.';
}
console.log("Task 19:", Greet19("Pooja"));

// Task 20: Apply a 10% discount to every price.
// Expected output: Task 20: [261,54,108]
cosnt original20 = [290, 60, 120];
const discounted20 = original20.forEach(function (price) {
  price - price / 10;
});
console.log("Task 20:", JSON.stringfy(discounted20));

// Task 21: Use an object method to show whether the shop is open.
// Expected output: Task 21: Frame Perfect Studio is open
cosnt shop21 = {
  name: "Frame Perfect Studio",
  isOpen: True,
  status() {
    return this.name + " is " + (this.isOpen ? "open" "closed");
  },
};
console.log("Task 21:", shop21.status);

