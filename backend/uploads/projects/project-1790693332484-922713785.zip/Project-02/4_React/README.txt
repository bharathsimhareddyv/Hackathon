======================================================================
  REACT-02  |  React  |  Spin Cycle Works
======================================================================

File to fix      : App.jsx
Errors hidden    : 52
Difficulty       : 39 / 100   (Easy 26, Medium 21, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 17
  JavaScript Syntax Error                  x 9
  JavaScript Error                         x 8
  List & Key Error                         x 4
  JSX Attribute Error                      x 4
  Component Definition Error               x 3
  Import / Export Error                    x 2
  Event Handling Error                     x 2
  Props Error                              x 2
  State Mutation Error                     x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

  * State Mutation Error
    Never push/splice/++ state. Call the setter with a NEW array/object: setItems([...items, x]).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            4  (JavaScript Error, List & Key Error)
  19 - 26        Rating component                 2  (JavaScript Error, List & Key Error)
  27 - 35        Footer component                 1  (JSX Syntax Error)
  36 - 53        Tabs component                   7  (JSX Attribute Error, JSX Syntax Error, JavaScript Error, JavaScript Syntax Error)
  54 - 68        SearchBar component              4  (JSX Attribute Error, JSX Syntax Error)
  69 - 79        Timer component                  1  (JavaScript Error)
  80 - 95        Wishlist component               2  (JavaScript Syntax Error, List & Key Error)
  96 - 115       ContactForm component            2  (Event Handling Error, JavaScript Syntax Error)
  116 - 128      ProductList component            3  (Component Definition Error, JSX Syntax Error, List & Key Error)
  129 - 137      Header component                 3  (JSX Syntax Error, Props Error)
  138 - 145      Banner component                 3  (JSX Syntax Error, JavaScript Syntax Error)
  146 - 153      Greeting component               1  (JavaScript Syntax Error)
  154 - 163      FAQItem component                1  (JSX Syntax Error)
  164 - 177      ProductCard component            2  (JSX Syntax Error, JavaScript Syntax Error)
  178 - 190      Counter component                3  (Event Handling Error, JavaScript Error, JavaScript Syntax Error)
  191 - 203      CartSummary component            4  (JSX Syntax Error)
  204 - 233      App component                    8  (Component Definition Error, Import / Export Error, JSX Attribute Error, JavaScript Error, JavaScript Syntax Error, Props Error, State Mutation Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
