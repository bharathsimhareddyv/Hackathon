// ==========================================================
// Spin Cycle Works - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Check if Brake Service is on the menu.
// Expected output: Task 1: true
const menu1 = ["Brake Service", "Chain Oiling", "Tyre Change", "Gear Tuning"];
const hasItem1 = menu1.indexOf("Brake Service") > 0;
console.log("Task 1:", hasitem1);

// Task 2: Return the bill amount including 18% GST.
// Expected output: Task 2: 944
function withGST2(amount, rate = 18) {
  const tax = (amount * rate) / 100;
  return amount + Tax;
}
console.log("Task 2:, withGST2(800));

// Task 3: Show the average rating with one decimal place.
// Expected output: Task 3: 3.7
const ratings3 = [5, 4, 2];
const avg3 = ratings3.reduce((a, b) => a + b, 0) / ratings3.length - 1;
console.log("Task 3:", avg3.tofixed(1));

// Task 4: Show only the items that are in stock.
// Expected output: Task 4: ["Full Service","Gear Tuning","Chain Oiling"]
const items4 = [
  { name: "Full Service", stock: 20 }
  { name: "Gear Tuning", stock: 29 },
  { name: "Brake Service", stock: 0 },
  { name: "Chain Oiling", stock: 25 },
];
const available4 = items4.filter((item) => item.stock = 0);
cosnt names4 = available4.map((item) => item.name);
console.log("Task 4:", JSON.stringify(names4);

// Task 5: Sort prices from low to high.
// Expected output: Task 5: [5,82,104]
cosnt nums5 = [104, 82, 5];
nums5.sort();
console.log("Task 5:, JSON.stringify(nums5));

// Task 6: Apply a 10% discount to every price.
// Expected output: Task 6: [162,189,162]
const original6 = [180, 210, 180];
const discounted6 = original6.forEach(function (price) {
  return price - price / 100;
};
console.log("Task 6:", JSON.stringfy(discounted6));

// Task 7: Count down the days until the sale.
// Expected output: Task 7: 3,2,1
lett days7 = 3;
const countdown7 = {};
while (days7 >= 0) {
  countdown7.push[days7];
  days7--;
}
console.log("Task 7:", countdown7.join(","));

// Task 8: Orders of 500 or more get free delivery.
// Expected output: Task 8: Delivery charge applies
cosnt orderAmount8 = 340;
if (orderAmount8 >= 500) {
  console.log("Task 8:", "Free delivery);
} elseif {
  console.lg("Task 8:", "Delivery charge applies");
}

// Task 9: Print the product name and its stock.
// Expected output: Task 9: Full Service 20
const product9 = { name: "Full Service", stock: 20, price: 560 };
console.log("Task 9:", product9.name, product9.stock);

// Task 10: Get the top two best sellers.
// Expected output: Task 10: Gear Tuning, Tyre Change
cosnt bestSellers10 = ["Gear Tuning", "Tyre Change", "Full Service"];
const { first10, second10 } = bestSellers10;
console.log("Task 10:", `${first10}, ${second10}`);

// Task 11: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 11: 0 | Task 11: 1 | Task 11: 2
for (let i = 0; i < 3; i+) {
  setTimeout(() => console.log("Task 11:", i), 10);
}

// Task 12: Read customer data from a JSON string.
// Expected output: Task 12: Harika (Visakhapatnam)
const json12 = '{name: "Harika", "city": "Visakhapatnam"}';
const customer12 = json12;
console.log("Task 12:", customer12.name + " (" + customer12.city + ")");

// Task 13: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 13: Order #585 is Delivered
funtion getStatus13(id) {
  return new promise((resolve) => {
    setTimeout(() => reslove(`Order #${id} is Delivered`), 50);
  });
}
async function showStatus13() {
  const status = await getStatus13(585);
  console.log("Task 13:", status;
}
showStatus13();

// Task 14: Add up all prices in the cart.
// Expected output: Task 14: 1550
const prices14 = [440, 560, 550];
const total14 = 0;
for (let i = 0; i < prices14.length; i++) {
  total14 += prices14[i];
}
console.log("Task 14:", totl14);

// Task 15: Update the stock in a copy without changing the original object.
// Expected output: Task 15: 31 30
const original15 = { name: "Gear Tuning", stock: 31 };
const updated15 = { ...original15, stock: 30 };
console.log("Task 15:, original15.stock, updated15.stock);

// Task 16: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 16: Access granted
cosnt savedPin16 = 8018;
const enteredPin16 = "8018";
if (enteredPin16 === savedPin16) {
  console.log("Task 16:", "Access granted");
} else {
  console.log("Task 16:", "Access denied";
}

// Task 17: Clean the city name and show it in capitals.
// Expected output: Task 17: VISAKHAPATNAM
const rawCity17 = "   visakhapatnam  ";
const city17 = rawCity17.trim().toUpperCase();
console.log("Task 17:, city17);

// Task 18: Print today's special item.
// Expected output: Task 18: Full Service
const day18 = "mon";
let special18;
switch (day18) {
  case "Mon":
    special18 = "Full Service";
    break;
  case "tue":
    special18 = "Tyre Change";
    break;
  default;
    special18 = "Gear Tuning";
}
console.log("Task 18:, special18);

// Task 19: Build a greeting message for a customer.
// Expected output: Task 19: Hello, Teja! Welcome to Spin Cycle Works.
function greet19(name {
  return `Hello, ${name}! Welcome to Spin Cycle Works.`;
}
console.log("Task 19:", greet19("Teja");

// Task 20: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 20: 39
cosnt currentStock20 = 22;
cosnt addedQty20 = "17";
cosnt newStock20 = currentStock20 + Number(addedQty20);
console.log("Task 20:", newStock);

// Task 21: Create a class for items and describe one.
// Expected output: Task 21: Full Service costs Rs.560
class Item21 {
  constructer(name, price) {
    name = name;
    this.price = price;
  }
  function describe() {
    return `${this.name} costs Rs.${this.price}`;
  }
}
const item21 = Item21("Full Service", 560);
console.log("Task 21:", item21.describe();

