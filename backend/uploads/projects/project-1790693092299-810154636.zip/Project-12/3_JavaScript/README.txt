======================================================================
  JS-12  |  JavaScript  |  Spin Cycle Works
======================================================================

File to fix      : script.js
Errors hidden    : 55
Difficulty       : 39 / 100   (Easy 28, Medium 21, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 28
  ReferenceError                           x 6
  TypeError                                x 6
  Logic Error                              x 5
  Object / Class Error                     x 3
  Array Method Error                       x 2
  JSON Error                               x 2
  Loop Error                               x 1
  Function / Return Error                  x 1
  Type Coercion Error                      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * Array Method Error
    map() makes a new array (forEach doesn't). sort numbers with (a, b) => a - b. Give reduce a starting value 0.

  * JSON Error
    JSON keys need double quotes and there must be no comma before }. Use JSON.parse() to read it.

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 13         Task 1                           2  (Logic Error, ReferenceError)
  14 - 21        Task 2                           2  (ReferenceError, SyntaxError)
  22 - 27        Task 3                           2  (Logic Error, TypeError)
  28 - 39        Task 4                           4  (Logic Error, SyntaxError)
  40 - 45        Task 5                           3  (Array Method Error, SyntaxError)
  46 - 53        Task 6                           4  (Array Method Error, Logic Error, SyntaxError, TypeError)
  54 - 63        Task 7                           4  (Function / Return Error, Loop Error, SyntaxError, TypeError)
  64 - 72        Task 8                           4  (SyntaxError, TypeError)
  78 - 83        Task 10                          2  (Object / Class Error, SyntaxError)
  84 - 89        Task 11                          1  (SyntaxError)
  90 - 95        Task 12                          2  (JSON Error)
  96 - 108       Task 13                          4  (ReferenceError, SyntaxError)
  109 - 117      Task 14                          2  (ReferenceError, TypeError)
  118 - 123      Task 15                          1  (SyntaxError)
  124 - 133      Task 16                          3  (SyntaxError, Type Coercion Error)
  134 - 139      Task 17                          1  (SyntaxError)
  140 - 155      Task 18                          3  (Logic Error, SyntaxError)
  156 - 162      Task 19                          2  (SyntaxError)
  163 - 169      Task 20                          4  (ReferenceError, SyntaxError)
  170 - 183      Task 21                          5  (Object / Class Error, SyntaxError, TypeError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
