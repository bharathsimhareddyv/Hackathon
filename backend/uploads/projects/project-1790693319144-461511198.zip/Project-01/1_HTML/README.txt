======================================================================
  HTML-01  |  HTML  |  Sweet Crumbs Bakery
======================================================================

File to fix      : index.html
Errors hidden    : 57
Difficulty       : 36 / 100   (Easy 40, Medium 7, Hard 10)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. Open index.html in Chrome/Firefox.
  2. Go to https://validator.w3.org/#validate_by_input and paste the whole file. Fix the FIRST error, re-check, repeat.
  3. Then click every link and try the form.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 38
  Link / Path Error                        x 5
  Form Error                               x 4
  Accessibility Error                      x 3
  Entity / Special Character Error         x 2
  Attribute Error                          x 2
  Duplicate ID Error                       x 1
  Table Error                              x 1
  Nesting / Structure Error                x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Link / Path Error
    Click every link. #links must match an id exactly. URLs start with https:// . Paths use / not \. Email = mailto: , phone = tel: .

  * Form Error
    Valid input types: text, email, tel, date, checkbox... Form method is get or post. Button type is submit. Close <textarea>.

  * Accessibility Error
    Every <img> needs alt="...". A <label for="x"> must match an input with id="x". Every <iframe> needs a title.

  * Entity / Special Character Error
    Codes like &copy; &amp; &#8377; must end with a semicolon. Write &lt; instead of a raw < in text.

  * Attribute Error
    Every attribute looks like name="value" - check spelling (class, href, src, required), the = sign, and BOTH quotes. a/link use href; img/script/source use src.

  * Duplicate ID Error
    Use Ctrl+F on id=" - every id value must appear only once on the page.

  * Table Error
    Each row is <tr><td>..</td><td>..</td></tr>. A <th> closes with </th>, a <td> with </td>.

  * Nesting / Structure Error
    Tags close in reverse order: <li><a>..</a></li>. Lists (ul/ol) can only contain <li>.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 10         Head (document setup)            2  (Syntax Error)
  11 - 22        Header & navigation              5  (Link / Path Error, Syntax Error)
  23 - 38        Gallery                          8  (Accessibility Error, Duplicate ID Error, Syntax Error)
  39 - 50        Products list                    6  (Entity / Special Character Error, Syntax Error)
  51 - 70        Price table                      6  (Syntax Error, Table Error)
  71 - 77        Hero section                     1  (Syntax Error)
  78 - 89        Media section                    4  (Accessibility Error, Attribute Error, Syntax Error)
  90 - 114       Contact form                     8  (Accessibility Error, Form Error, Link / Path Error, Syntax Error)
  115 - 126      FAQ section                      3  (Syntax Error)
  127 - 141      Team section                     5  (Nesting / Structure Error, Syntax Error)
  142 - 150      About section                    4  (Link / Path Error, Syntax Error)
  151 - 158      Footer & closing tags            5  (Entity / Special Character Error, Link / Path Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
