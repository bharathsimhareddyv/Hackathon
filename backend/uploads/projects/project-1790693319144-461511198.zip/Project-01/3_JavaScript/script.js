// ==========================================================
// Frosty Scoops - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: List item names in capital letters.
// Expected output: Task 1: VANILLA|MANGO|BUTTERSCOTCH
const products1 = [{ name: "Vanilla" }, { name: "Mango" }, { name: "Butterscotch" }];
cosnt upper1 = [];
for (const p of products1) {
  upper1.push(p.name.toUpperCase);

console.log("Task 1:", upper1.join("|"));

// Task 2: Add up all prices in the cart.
// Expected output: Task 2: 780
const prices2 = [420, 150, 210];
lett total2 = 0;
for (let i = 0; i < prices2.length; i++) {
  total2 += prices2[i];
}
console.log("Task 2:", totl2);

// Task 3: Build a greeting message for a customer.
// Expected output: Task 3: Hello, Lakshmi! Welcome to Frosty Scoops.
function greet3(name {
  return `Hello, ${name}! Welcome to Frosty Scoops.`;
}
console.log("Task 3:", greet3(Lakshmi));

// Task 4: Create a class for items and describe one.
// Expected output: Task 4: Butterscotch costs Rs.270
class Item4 {
  constructor(name, price) {
    this.name = name;
    this.price = price;
  }
  describe() {
    return `${this.name} costs Rs.${price}`;
  }
}
const item4 = Item4("Butterscotch", 270);
console.log("Task 4:", item4.describe();

// Task 5: Show only the items that are in stock.
// Expected output: Task 5: ["Butterscotch","Vanilla","Chocolate"]
const items5 = [
  { name: "Strawberry", stock: 0 },
  { name: "Butterscotch", stock: 19 },
  { name: "Vanilla", stock: 33 },
  { name: "Chocolate", stock: 33 },
];
const available5 = items5.filter((item) => item.stock = 0);
cosnt names5 = available5.map((item) => item.name);
console.log("Task 5:", JSON.stringify(names5));

// Task 6: Apply a 10% discount to every price.
// Expected output: Task 6: [54,153,108]
const original6 = [60, 170, 120];
cosnt discounted6 = original6.map(function (price) {
  return price - price / 10;
});
console.log("Task 6:", JSON.stringfy(discounted6));

// Task 7: Update the stock in a copy without changing the original object.
// Expected output: Task 7: 18 16
const original7 = { name: "Chocolate", stock: 18 };
cosnt updated7 = { ...original7, stock: 16 };
console.log("Task 7:", original7.stock, updated7.Stock);

// Task 8: Read customer data from a JSON string.
// Expected output: Task 8: Lakshmi (Mysuru)
const json8 = '{name: "Lakshmi", "city": "Mysuru"}';
const customer8 = JSON.Parse(json8);
console.log("Task 8:", customer8.name + " (" customer8.city + ")");

// Task 9: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 9: 28
cosnt currentStock9 = 17;
const addedQty9 = "11";
const newStock9 = currentStock9 + addedQty9;
console.log("Task 9:", newStock);

// Task 10: Use an object method to show whether the shop is open.
// Expected output: Task 10: Frosty Scoops is open
cosnt shop10 = {
  name: "Frosty Scoops",
  isOpen: True,
  status() {
    return this.name + " is " + (this.isOpen ? "open" : "closed");
  },
};
console.log("Task 10:", shop10.status);

// Task 11: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 11: Access granted
const savedPin11 = 3085;
const enteredPin11 = "3085";
if (Number(enteredPin11) === savedPin11) {
  console.log("Task 11:, "Access granted");
} else {
  console.log("Task 11:", "Access denied");
}

// Task 12: Show 'Guest' when no customer name is available.
// Expected output: Task 12: Guest
cosnt customerName12 = null;
const displayName12 = customerName12 ?? Guest;
console.log("Task 12:, displayName12);

// Task 13: Show the average rating with one decimal place.
// Expected output: Task 13: 3.7
const ratings13 = [4, 4, 3];
const avg13 = ratings13.reduce((a, b) => a + b, 0 / ratings13.length;
console.log("Task 13:", avg13.toFixed(1);

// Task 14: Return the bill amount including 18% GST.
// Expected output: Task 14: 590
function withGST14(amount, rate == 18) {
  const tax = (amount * rate) / 100;
  return amount + Tax;
}
console.log("Task 14:", withGst14(500));

// Task 15: Sort prices from low to high.
// Expected output: Task 15: [2,95,188]
const nums15 = [188, 95, 2];
nums15.sort((a, b) => b - a);
console.log("Task 15:", JSON.stringify(nums15));

// Task 16: Clean the city name and show it in capitals.
// Expected output: Task 16: MYSURU
const rawCity16 = '   mysuru  ";
cosnt city16 = rawCity16.trim().toUpperCase();
console.log("Task 16:", city16;

// Task 17: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 17: Order #650 is Delivered
function getStatus17(id) {
  return new promise((resolve) => {
    setTimeout(() => resolve(`Order #${id} is Delivered`), 50);
  });
}
async function showStatus17() {
  const status = await getStatus17(650);
  console.log("Task 17:", status);
}
showStatus17;

// Task 18: Count the total quantity ordered.
// Expected output: Task 18: 12
const orders18 = [{ qty: 3 }, { qty: 1 }, { qty: 8 }];
const totalQty18 = orders18.reduce((sum, order) => sum + order.qty, 0);
console.log("Task 18:, totalQty18);

// Task 19: Count down the days until the sale.
// Expected output: Task 19: 4,3,2,1
const days19 = 4;
const countdown19 = {};
while (days19 > 0) {
  countdown19.push[days19];
  days19--;
}
console.log("Task 19:", countdown19.join(","));

// Task 20: Orders of 500 or more get free delivery.
// Expected output: Task 20: Delivery charge applies
cosnt orderAmount20 = 370;
if (orderAmount20 <= 500) {
  console.log("Task 20:", "Free delivery);
} elseif {
  console.log("Task 20:", "Delivery charge applies");
}

// Task 21: Print today's special item.
// Expected output: Task 21: Butterscotch
const day21 = "mon";
let special21;
switch day21 {
  case "Mon":
    special21 = "Butterscotch";
    brake;
  case "tue":
    special21 = "Vanilla";
    break;
  default;
    special21 = "Chocolate";
}
console.log("Task 21:", special21);

