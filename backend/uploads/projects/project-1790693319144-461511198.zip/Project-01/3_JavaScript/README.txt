======================================================================
  JS-01  |  JavaScript  |  Frosty Scoops
======================================================================

File to fix      : script.js
Errors hidden    : 52
Difficulty       : 39 / 100   (Easy 26, Medium 21, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 26
  ReferenceError                           x 10
  TypeError                                x 5
  Function / Return Error                  x 4
  Logic Error                              x 4
  Object / Class Error                     x 1
  JSON Error                               x 1
  Type Coercion Error                      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * JSON Error
    JSON keys need double quotes and there must be no comma before }. Use JSON.parse() to read it.

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 16         Task 1                           3  (Function / Return Error, SyntaxError)
  17 - 25        Task 2                           2  (ReferenceError, SyntaxError)
  26 - 32        Task 3                           2  (ReferenceError, SyntaxError)
  33 - 46        Task 4                           3  (ReferenceError, SyntaxError, TypeError)
  47 - 58        Task 5                           2  (Logic Error, SyntaxError)
  59 - 66        Task 6                           2  (SyntaxError, TypeError)
  67 - 72        Task 7                           2  (Object / Class Error, SyntaxError)
  73 - 78        Task 8                           3  (JSON Error, SyntaxError, TypeError)
  79 - 85        Task 9                           3  (ReferenceError, SyntaxError, Type Coercion Error)
  86 - 96        Task 10                          3  (Function / Return Error, ReferenceError, SyntaxError)
  97 - 106       Task 11                          1  (SyntaxError)
  107 - 112      Task 12                          3  (ReferenceError, SyntaxError)
  113 - 118      Task 13                          2  (SyntaxError)
  119 - 126      Task 14                          3  (ReferenceError, SyntaxError)
  127 - 132      Task 15                          1  (Logic Error)
  133 - 138      Task 16                          3  (SyntaxError)
  139 - 151      Task 17                          2  (Function / Return Error, ReferenceError)
  152 - 157      Task 18                          1  (SyntaxError)
  158 - 167      Task 19                          3  (Function / Return Error, TypeError)
  168 - 176      Task 20                          4  (Logic Error, SyntaxError)
  177 - 192      Task 21                          4  (Logic Error, ReferenceError, SyntaxError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
