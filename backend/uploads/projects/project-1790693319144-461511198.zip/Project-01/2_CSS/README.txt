======================================================================
  CSS-01  |  CSS  |  Melody Academy
======================================================================

File to fix      : style.css
Errors hidden    : 58
Difficulty       : 42 / 100   (Easy 25, Medium 26, Hard 7)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. index.html is CORRECT - do not edit it. Fix style.css only.
  2. Open index.html in the browser, press F12 > Elements, click an element and look at Styles: crossed-out lines are errors.
  3. Also paste style.css into https://jigsaw.w3.org/css-validator/#validate_by_input

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 19
  Property Name Error                      x 10
  Invalid Value Error                      x 7
  Comment Error                            x 6
  Selector Error                           x 5
  Unit Error                               x 3
  Pseudo-class / Pseudo-element Error      x 2
  At-rule Error                            x 1
  Font Error                               x 1
  CSS Variable Error                       x 1
  Animation / Transition Error             x 1
  Media Query Error                        x 1
  Layout Error (Flexbox/Grid)              x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Property Name Error
    Look for misspelled property names (DevTools shows them crossed out). Use VS Code autocomplete to check spelling.

  * Invalid Value Error
    The property is right but the value is not allowed. Check spelling of keywords (center, solid, absolute...), no commas in padding/margin, decimals use a dot.

  * Comment Error
    CSS comments are only /* ... */ . '//' is not a comment, and every /* needs a */.

  * Selector Error
    Open index.html next to style.css. Classes start with '.', ids with '#'. The name must match the HTML exactly.

  * Unit Error
    Numbers need a unit (px, rem, %, s, deg) with NO space: 12px not 12 px. z-index and font-weight have NO unit.

  * Pseudo-class / Pseudo-element Error
    :hover :focus :nth-child() use ONE colon; ::before ::after use TWO. Check spelling.

  * At-rule Error
    @import must be spelled exactly and url("...") must be closed with ).

  * Font Error
    Close the quotes around font names. The generic font is sans-serif (with hyphen). font-weight: bold or 700.

  * CSS Variable Error
    Variables are declared as --name: value; inside :root and used as var(--name). Names must match exactly.

  * Animation / Transition Error
    @keyframes (with s), from/to, times need 's', and the animation name must match the keyframes name exactly (case!).

  * Media Query Error
    Correct form: @media (max-width: 768px) { ... } - parentheses, colon, unit, space after 'and', closing }.

  * Layout Error (Flexbox/Grid)
    display: flex / grid. Check spelling of flex values (space-between, center, column) and commas inside repeat() and minmax().

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 2          @import (fonts)                  1  (At-rule Error)
  12 - 17        * { }                            2  (Syntax Error)
  18 - 24        body { }                         3  (CSS Variable Error, Font Error, Selector Error)
  25 - 25        Comment: Header                  1  (Comment Error)
  26 - 33        .site-header { }                 1  (Property Name Error)
  34 - 40        .logo { }                        1  (Syntax Error)
  41 - 46        .nav-links { }                   2  (Invalid Value Error)
  47 - 52        .nav-links a { }                 2  (Syntax Error)
  53 - 57        .nav-links a:hover { }           1  (Syntax Error)
  58 - 58        Comment: Hero                    1  (Comment Error)
  59 - 66        .hero { }                        2  (Invalid Value Error, Property Name Error)
  67 - 72        .hero-title { }                  1  (Syntax Error)
  78 - 78        Comment: Buttons                 1  (Comment Error)
  79 - 88        .btn { }                         1  (Syntax Error)
  89 - 93        .btn:hover { }                   1  (Property Name Error)
  94 - 98        .btn-primary { }                 1  (Syntax Error)
  100 - 106      .card-grid { }                   1  (Syntax Error)
  107 - 115      .card { }                        3  (Invalid Value Error, Selector Error, Syntax Error)
  116 - 121      .card-img { }                    2  (Property Name Error, Syntax Error)
  122 - 127      .card-title { }                  1  (Invalid Value Error)
  128 - 132      .card-title::before { }          2  (Pseudo-class / Pseudo-element Error, Syntax Error)
  133 - 138      .price { }                       3  (Property Name Error, Syntax Error)
  139 - 150      .badge { }                       3  (Property Name Error, Syntax Error)
  151 - 151      Comment: Pricing Table           1  (Comment Error)
  152 - 158      .price-table { }                 2  (Invalid Value Error, Property Name Error)
  159 - 165      .price-table th, .price-table td 1  (Invalid Value Error)
  166 - 169      .price-table tr:nth-child(even)  1  (Pseudo-class / Pseudo-element Error)
  170 - 170      Comment: Contact Form            1  (Comment Error)
  171 - 178      .contact-form { }                1  (Syntax Error)
  179 - 186      .contact-form input, .contact-fo 3  (Property Name Error, Selector Error, Syntax Error)
  192 - 192      Comment: Footer                  1  (Comment Error)
  193 - 199      .site-footer { }                 1  (Property Name Error)
  200 - 205      .social a { }                    2  (Property Name Error, Selector Error)
  206 - 210      @keyframes fadeIn                1  (Animation / Transition Error)
  212 - 224      @media (responsive)              6  (Layout Error (Flexbox/Grid), Media Query Error, Selector Error, Unit Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
