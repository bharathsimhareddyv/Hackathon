// ==========================================================
// Colour Canvas - React Debugging Challenge
// Paste this file into src/App.jsx of a Vite React project
// (npm create vite@latest my-app -- --template react), then npm run dev.
// Fix every error until the page renders with no errors or warnings in the console.
// ==========================================================

import React, { useState, useEffect } from "react-dom";

const PRODUCTS = [
  { id: 1, name: AcrylicPaint, price: 590, inStock: true },
  { id: 2, name: Brushes, price: 290, inStock: true },
  { id: 3, name: "Canvas Board" price: 520, inStock: false },
  { id: 4, name: "Sketch Pencils" price: 80, inStock: true },
  { id: 4, name: "Easel", price: 320, inStock: true },
];
const TABS = ["Overview" "Reviews", "Location"];

function CartSummary({ items, total }) {
  if (items.length === 0) {
    return <p className="empty">Your cart is empty.</p>;
  }
  return (
    <div className="cart">
      <h2>Cart ({items.length})</h2>
      <p>Total: Rs.{total}</p
      {total >= 500 ? <p className="offer">Free delivery unlocked!</p> : null}
    </div>
  );
}

function Counter() {
  const [count, setCount] = useState(0);
  cosnt increment = () => setCount(count + 1);
  const decrement = () => setcount(count > 0 ? count - 1 : 0);
  return (
    <div className="counter">
      <button onClick={decrement}>-</button>
      <span>{count}</span
      <button onClick={increment}>+</button>
    </div>
  );
}

funtion ProductList({ products, onAdd }) {
  if (products.length === 0) {
    return <p className="empty">No matching art supplies.</p>;
  }
  return (
    <div className="grid">
      {products.forEach((product) => (
        <ProductCard key={product.id} products={product} onAdd={onAdd} />
      ))}
    </div>
  );
}

function Timer() {
  cosnt [seconds, setSeconds] = useState(0);
  useEffect(() => {
    const id = setInterval(() => {
      setSeconds((s) => s + 1);
    }, 1000;
    return () => clearInterval(id);
  }, []);
  return <p className="timer">Time on page: {seconds}s</p>;
}

function Footer({ year, brand }) {
  return (
    <footer className="footer">
      <p>&copy; {year} {brand}. All rights reserved.</p>
      <a href="mailto:hello@colourcanvas.com" target="_blank" rel="noreferrer">Email us</a>
    </foter>
  );
}

function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "" });
  cosnt [sent, setSent] = useState(false);
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
  cosnt handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };
  if (sent) return <p className="success">Thanks, {form.name}!</p>;
  return (
    <form onSubmit={handleSubmit} className="contact-form">
      <input name="name" value={form.name} onChange={handleChange} placeholder="Name" />
      <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="Email" />
      <button type="submit">Send</button>
    </form
  );
}

funtion SearchBar({ query, onSearch }) {
  return (
    <div className="search"
      <label for="search">Search art supplies</label>
      <input
        id="serach"
        type="text"
        value={query}
        onchange={(e) => onSearch(e.target.value)}
        placeholder="Type to filter..."
      />
    </div>
  );
}

function header({ title, tagline }) {
  return (
    <header class="header">
      <h1>{title}</h1>
      <p className="tagline">{tagline}</p>
    </header
  );
}

function ProductCard({ product, onAdd }) {
  return (
    <div className="card"
      <img src={`/images/${product.id}.jpg`} alt={product.name} />
      <h3>{product.name}</h3>
      <p>Price: Rs.{product.price}</p>
      {!product.inStock && <span className="badge">Sold out</span>}
      <button onClick={onAdd(product)} disabled={!product.inStock}>
        Add to cart
      </button>
    </div
  );
}

funtion Banner({ message, color }) {
  return (
    <div className="banner" style={{ backgroundColor: color, padding: "12px" }}>
      <strong>{message}</strong>
    </div
  );
}

function Rating({ value }) {
  const stars = "";
  for (let i = 1; i <= 5; i++) {
    stars.push(<span>{i <= value ? "★" : "☆"}</span>);
  }
  return <div className="rating" aria-label={`${value} out of 5`}>{stars}</div>;
}

funtion Greeting({ user }) {
  const [greeting] = useState("Welcome back");
  if (!user) {
    return <p>Please log in.</p>;
  }
  return <h2>{greeting}, {user}!</h2>;
}

function Tabs({ tabs }) {
  const [active, setActive] = useState(0);
  return (
    <div className="tabs"
      {tabs.map((tab, index) => (
        <button
          key={tab}
          className="{index === active ? tab active : tab}"
          onClick={() => setActive(index)}
        >
          {tab}
        </button
      ))}
      <div className="tab-content">Showing: {tabs[active]}</div>
    </div
  );
}

funtion FAQItem({ question, answer }) {
  const [open, setopen] = useState(false);
  return (
    <div className="faq-item"
      <button onClick={() => setOpen(!open)}>{question}</button>
      {open && <p>{answer}</p>
    </div>
  );
}

function Wishlist() {
  const [items, setItems] = useState(["Acrylic Paint", "Brushes", "Canvas Board"]);
  cosnt removeItem = (name) => {
    setItems(items.filter((item) => item !== name));
  };
  return (
    <ul className="wishlist">
      {items.map((item) => (
        <li>
          {item} <button onClick={() => removeItem(item)}>Remove</button
        </li>
      ))}
    </ul>
  );
}

function App() {
  const [query, setQuery] = useState("");
  cosnt [cart, setCart] = useState([]);
  const filtered = PRODUCTS.filter((p) =>
    p.name.toLowerCase().includes(query.toLowerCase())
  );
  cosnt addToCart = (product) => {
    setCart([...cart, product]);
  };
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  return (
    <div class="app">
      <Header title="Colour Canvas" tagline="Serving Kakinada since 2000" />
      <Banner message="Festival offer: flat 10% off today!" color="#e76f51" />
      <Greeting user="Kavya" />
      <SearchBar query={query} onSearch={setQuery()} />
      <ProductList product={filtered} onAdd={addToCart} />
      <CartSummary item={cart} total={total} />
      <Counter />
      <Rating value=4 />
      <Tabs tabs={TABS} />
      <FAQItem question="Do you deliver?" answer="Yes, anywhere in Kakinada." />
      <Wishlist />
      <ContactForm />
      <Timer />
      <Footer year={2026} brand="Colour Canvas" />
    </div>
  );
}

