======================================================================
  REACT-01  |  React  |  Colour Canvas
======================================================================

File to fix      : App.jsx
Errors hidden    : 55
Difficulty       : 39 / 100   (Easy 28, Medium 21, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 16
  JavaScript Syntax Error                  x 12
  JavaScript Error                         x 9
  JSX Attribute Error                      x 5
  List & Key Error                         x 4
  Props Error                              x 3
  Event Handling Error                     x 3
  Import / Export Error                    x 2
  Component Definition Error               x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            6  (JavaScript Error, List & Key Error)
  19 - 31        CartSummary component            1  (JSX Syntax Error)
  32 - 44        Counter component                3  (JSX Syntax Error, JavaScript Error, JavaScript Syntax Error)
  45 - 57        ProductList component            3  (JavaScript Syntax Error, List & Key Error, Props Error)
  58 - 68        Timer component                  2  (JavaScript Error, JavaScript Syntax Error)
  69 - 77        Footer component                 1  (JSX Syntax Error)
  78 - 97        ContactForm component            3  (JSX Syntax Error, JavaScript Syntax Error)
  98 - 112       SearchBar component              5  (Event Handling Error, JSX Attribute Error, JSX Syntax Error, JavaScript Syntax Error)
  113 - 121      Header component                 3  (Component Definition Error, JSX Attribute Error, JSX Syntax Error)
  122 - 135      ProductCard component            3  (Event Handling Error, JSX Syntax Error)
  136 - 143      Banner component                 2  (JSX Syntax Error, JavaScript Syntax Error)
  144 - 151      Rating component                 2  (JavaScript Error, List & Key Error)
  152 - 159      Greeting component               1  (JavaScript Syntax Error)
  160 - 177      Tabs component                   4  (JSX Attribute Error, JSX Syntax Error)
  178 - 187      FAQItem component                4  (JSX Syntax Error, JavaScript Error, JavaScript Syntax Error)
  188 - 203      Wishlist component               3  (JSX Syntax Error, JavaScript Syntax Error, List & Key Error)
  204 - 233      App component                    8  (Event Handling Error, Import / Export Error, JSX Attribute Error, JSX Syntax Error, JavaScript Syntax Error, Props Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
