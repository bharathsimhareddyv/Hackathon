======================================================================
  JS-06  |  JavaScript  |  Tiny Treasures Toys
======================================================================

File to fix      : script.js
Errors hidden    : 54
Difficulty       : 39 / 100   (Easy 27, Medium 22, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 27
  TypeError                                x 6
  Logic Error                              x 5
  ReferenceError                           x 5
  Object / Class Error                     x 5
  String Method Error                      x 2
  Function / Return Error                  x 2
  Loop Error                               x 1
  Array Method Error                       x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * String Method Error
    ${ } only works inside backticks ` `. Check string method names (trim, toUpperCase).

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * Array Method Error
    map() makes a new array (forEach doesn't). sort numbers with (a, b) => a - b. Give reduce a starting value 0.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  14 - 19        Task 2                           2  (SyntaxError, TypeError)
  20 - 27        Task 3                           4  (Logic Error, SyntaxError, TypeError)
  28 - 33        Task 4                           2  (SyntaxError)
  34 - 42        Task 5                           4  (Logic Error, SyntaxError)
  43 - 50        Task 6                           2  (ReferenceError, SyntaxError)
  51 - 56        Task 7                           2  (Logic Error, Object / Class Error)
  57 - 68        Task 8                           4  (Logic Error, Object / Class Error, SyntaxError)
  69 - 74        Task 9                           2  (Object / Class Error, String Method Error)
  75 - 81        Task 10                          2  (String Method Error, SyntaxError)
  82 - 91        Task 11                          3  (Loop Error, SyntaxError, TypeError)
  92 - 101       Task 12                          3  (SyntaxError)
  107 - 112      Task 14                          3  (ReferenceError, SyntaxError)
  113 - 125      Task 15                          4  (Function / Return Error, ReferenceError, SyntaxError)
  126 - 141      Task 16                          3  (Logic Error, ReferenceError, SyntaxError)
  142 - 150      Task 17                          3  (SyntaxError)
  151 - 156      Task 18                          3  (SyntaxError, TypeError)
  157 - 162      Task 19                          1  (Array Method Error)
  163 - 176      Task 20                          4  (Object / Class Error, ReferenceError, TypeError)
  177 - 187      Task 21                          3  (Function / Return Error, SyntaxError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
