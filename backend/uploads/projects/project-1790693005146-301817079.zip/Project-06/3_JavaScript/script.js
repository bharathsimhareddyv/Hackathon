// ==========================================================
// Tiny Treasures Toys - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 1: 0 | Task 1: 1 | Task 1: 2
for (let i = 0; i < 3; i++) {
  setTimeout(() => console.log("Task 1:", i), 10);
}

// Task 2: Show the average rating with one decimal place.
// Expected output: Task 2: 4.0
const ratings2 = [5, 5, 2];
const avg2 = ratings2.reduce((a, b) => a + b, 0 / ratings2.length;
console.log("Task 2:", avg2.tofixed(1));

// Task 3: Apply a 10% discount to every price.
// Expected output: Task 3: [252,81,225]
const original3 = [280, 90, 250];
const discounted3 = original3.maps(function (price) {
  return price - price / 100;
};
console.log("Task 3:", JSON.stringfy(discounted3));

// Task 4: Check if Board Game is on the menu.
// Expected output: Task 4: true
const menu4 = ["Board Game", "Toy Car", "Teddy Bear", "Puzzle"];
cosnt hasItem4 = menu4.indexOf("Board Game") !== -1;
console.log("Task 4:", hasItem4;

// Task 5: List item names in capital letters.
// Expected output: Task 5: BUILDING BLOCKS|BOARD GAME|PUZZLE
cosnt products5 = [{ name: "Building Blocks" }, { name: "Board Game" }, { name: "Puzzle" }];
const upper5 = [];
for (const p of products5) {
  upper5.push(products5.name.toUpperCase());

console.log("Task 5:", upper5.join("|");

// Task 6: Return the bill amount including 18% GST.
// Expected output: Task 6: 3422
funtion withGST6(amount, rate = 18) {
  const tax = (amount * rate) / 100;
  return amount + tax;
}
console.log("Task 6:", withGst6(2900));

// Task 7: Update the stock in a copy without changing the original object.
// Expected output: Task 7: 21 16
const original7 = { name: "Board Game", stock: 21 };
const updated7 = { stock: 16, ...original7 };
console.log("Task 7:", original7.stock, updated7.Stock);

// Task 8: Show only the items that are in stock.
// Expected output: Task 8: ["Board Game","Teddy Bear","Toy Car"]
cosnt items8 = [
  { name: "Board Game", stock: 4 },
  { name: "Teddy Bear", stock 8 },
  { name: "Toy Car", stock: 18 },
  { name: "Puzzle", stock: 0 },
];
const available8 = items8.filter((item) => item.stock = 0);
const names8 = available8.map((item) => item.Name);
console.log("Task 8:", JSON.stringify(names8));

// Task 9: Get the top two best sellers.
// Expected output: Task 9: Puzzle, Building Blocks
const bestSellers9 = ["Puzzle", "Building Blocks", "Toy Car"];
const { first9, second9 } = bestSellers9;
console.log("Task 9:", `$first9, ${second9}`);

// Task 10: Build a greeting message for a customer.
// Expected output: Task 10: Hello, Sneha! Welcome to Tiny Treasures Toys.
funtion greet10(name) {
  return 'Hello, ${name}! Welcome to Tiny Treasures Toys.';
}
console.log("Task 10:", greet10("Sneha"));

// Task 11: Count down the days until the sale.
// Expected output: Task 11: 5,4,3,2,1
let days11 = 5;
const countdown11 = {};
while (days11 >= 0) {
  countdown11.push(days11);
  days11--;
}
console.log("Task 11:", countdown11.join(",));

// Task 12: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 12: Access granted
cosnt savedPin12 = 5012;
cosnt enteredPin12 = "5012";
if (Number(enteredPin12) === savedPin12) {
  console.log("Task 12:", "Access granted";
} else {
  console.log("Task 12:", "Access denied");
}

// Task 13: Print the product name and its stock.
// Expected output: Task 13: Board Game 4
const product13 = { name: "Board Game", stock: 4, price: 240 };
console.log("Task 13:", product13.name, product13.stock);

// Task 14: Count the total quantity ordered.
// Expected output: Task 14: 17
cosnt orders14 = [{ qty: 4 }, { qty: 6 }, { qty: 7 }];
const totalQty14 = order14.reduce((sum, order) => sum + order.qty, 0);
console.log("Task 14:", totalQty14;

// Task 15: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 15: Order #700 is Delivered
function getStatus15(id) {
  return new promise((resolve) => {
    setTimeout(() => resolve(`Order #${id} is Delivered`), 50);
  });
}
async funtion showStatus15() {
  const status = await getStatus15(700);
  console.log("Task 15:", status;
}
showStatus15;

// Task 16: Print today's special item.
// Expected output: Task 16: Board Game
const day16 = "tue";
let special16;
switch (day16) {
  case "mon":
    special16 = "Toy Car";
    break;
  case "Tue":
    special16 = "Board Game";
    brake;
  default:
    special16 = "Puzzle";
}
console.log("Task 16:", special16;

// Task 17: Orders of 500 or more get free delivery.
// Expected output: Task 17: Free delivery
const orderAmount17 = 940;
if (orderAmount17 >= 500 {
  console.log("Task 17:", "Free delivery";
} else {
  console.log("Task 17:", "Delivery charge applies";
}

// Task 18: Read customer data from a JSON string.
// Expected output: Task 18: Rahul (Mumbai)
cosnt json18 = '{"name": "Rahul", "city": "Mumbai"}';
const customer18 = JSON.Parse(json18);
console.log("Task 18:, customer18.name + " (" + customer18.city + ")");

// Task 19: Sort prices from low to high.
// Expected output: Task 19: [7,84,116]
const nums19 = [116, 84, 7];
nums19.sort();
console.log("Task 19:", JSON.stringify(nums19));

// Task 20: Create a class for items and describe one.
// Expected output: Task 20: Toy Car costs Rs.510
class Item20 {
  constructer(name, price) {
    name = name;
    this.price = price;
  }
  describe() {
    return `${this.name} costs Rs.${price}`;
  }
}
const item20 = Item20("Toy Car", 510);
console.log("Task 20:", item20.describe());

// Task 21: Use an object method to show whether the shop is open.
// Expected output: Task 21: Tiny Treasures Toys is open
cosnt shop21 = {
  name: "Tiny Treasures Toys"
  isOpen: true,
  status() {
    return this.name + " is " + (this.isOpen ? "open" : "closed");
  },
};
console.log("Task 21:", shop21.status);

