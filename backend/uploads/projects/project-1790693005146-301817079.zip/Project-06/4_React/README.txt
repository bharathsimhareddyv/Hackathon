======================================================================
  REACT-06  |  React  |  BrightMinds Tuition
======================================================================

File to fix      : App.jsx
Errors hidden    : 53
Difficulty       : 39 / 100   (Easy 26, Medium 22, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 16
  JavaScript Syntax Error                  x 10
  JavaScript Error                         x 9
  JSX Attribute Error                      x 5
  Event Handling Error                     x 3
  Component Definition Error               x 3
  Import / Export Error                    x 2
  List & Key Error                         x 2
  Props Error                              x 2
  Style Prop Error                         x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

  * Style Prop Error
    style takes an object: style={{ backgroundColor: color }} (double braces, camelCase keys).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            4  (JavaScript Error)
  19 - 26        Banner component                 4  (JSX Syntax Error, JavaScript Syntax Error, Style Prop Error)
  27 - 34        Rating component                 1  (List & Key Error)
  35 - 42        Greeting component               1  (JavaScript Syntax Error)
  43 - 53        Timer component                  1  (JavaScript Error)
  54 - 66        Counter component                4  (JSX Syntax Error, JavaScript Error, JavaScript Syntax Error)
  67 - 80        ProductCard component            4  (JSX Syntax Error)
  81 - 96        Wishlist component               1  (JavaScript Syntax Error)
  97 - 106       FAQItem component                2  (JavaScript Error, Props Error)
  107 - 119      CartSummary component            1  (JavaScript Syntax Error)
  120 - 137      Tabs component                   4  (JSX Attribute Error, JSX Syntax Error, JavaScript Error, JavaScript Syntax Error)
  138 - 146      Header component                 2  (JSX Attribute Error, JSX Syntax Error)
  147 - 166      ContactForm component            5  (Event Handling Error, JSX Syntax Error, JavaScript Syntax Error)
  167 - 179      ProductList component            4  (Component Definition Error, JSX Syntax Error, JavaScript Syntax Error, List & Key Error)
  180 - 194      SearchBar component              3  (Event Handling Error, JSX Attribute Error)
  195 - 203      Footer component                 3  (JSX Syntax Error, JavaScript Syntax Error)
  204 - 233      App component                    8  (Component Definition Error, Import / Export Error, JSX Attribute Error, JSX Syntax Error, JavaScript Error, Props Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
