======================================================================
  CSS-06  |  CSS  |  CodeCraft Academy
======================================================================

File to fix      : style.css
Errors hidden    : 52
Difficulty       : 38 / 100   (Easy 24, Medium 25, Hard 3)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. index.html is CORRECT - do not edit it. Fix style.css only.
  2. Open index.html in the browser, press F12 > Elements, click an element and look at Styles: crossed-out lines are errors.
  3. Also paste style.css into https://jigsaw.w3.org/css-validator/#validate_by_input

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 21
  Property Name Error                      x 13
  Invalid Value Error                      x 5
  Unit Error                               x 4
  Comment Error                            x 3
  Layout Error (Flexbox/Grid)              x 2
  Color Error                              x 1
  Pseudo-class / Pseudo-element Error      x 1
  Selector Error                           x 1
  Animation / Transition Error             x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Property Name Error
    Look for misspelled property names (DevTools shows them crossed out). Use VS Code autocomplete to check spelling.

  * Invalid Value Error
    The property is right but the value is not allowed. Check spelling of keywords (center, solid, absolute...), no commas in padding/margin, decimals use a dot.

  * Unit Error
    Numbers need a unit (px, rem, %, s, deg) with NO space: 12px not 12 px. z-index and font-weight have NO unit.

  * Comment Error
    CSS comments are only /* ... */ . '//' is not a comment, and every /* needs a */.

  * Layout Error (Flexbox/Grid)
    display: flex / grid. Check spelling of flex values (space-between, center, column) and commas inside repeat() and minmax().

  * Color Error
    Hex colours have 3 or 6 digits using only 0-9 and a-f. Check colour names and close rgba( ).

  * Pseudo-class / Pseudo-element Error
    :hover :focus :nth-child() use ONE colon; ::before ::after use TWO. Check spelling.

  * Selector Error
    Open index.html next to style.css. Classes start with '.', ids with '#'. The name must match the HTML exactly.

  * Animation / Transition Error
    @keyframes (with s), from/to, times need 's', and the animation name must match the keyframes name exactly (case!).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  4 - 10         :root { }                        4  (Color Error, Syntax Error, Unit Error)
  12 - 17        * { }                            1  (Property Name Error)
  25 - 25        Comment: Header                  1  (Comment Error)
  26 - 33        .site-header { }                 2  (Layout Error (Flexbox/Grid), Property Name Error)
  34 - 40        .logo { }                        3  (Property Name Error, Syntax Error, Unit Error)
  41 - 46        .nav-links { }                   2  (Property Name Error, Syntax Error)
  47 - 52        .nav-links a { }                 1  (Syntax Error)
  53 - 57        .nav-links a:hover { }           1  (Invalid Value Error)
  59 - 66        .hero { }                        2  (Property Name Error, Syntax Error)
  67 - 72        .hero-title { }                  1  (Syntax Error)
  73 - 77        .hero-text { }                   1  (Syntax Error)
  79 - 88        .btn { }                         2  (Property Name Error)
  89 - 93        .btn:hover { }                   2  (Invalid Value Error, Property Name Error)
  94 - 98        .btn-primary { }                 2  (Invalid Value Error, Property Name Error)
  100 - 106      .card-grid { }                   3  (Property Name Error, Syntax Error)
  107 - 115      .card { }                        2  (Invalid Value Error, Syntax Error)
  116 - 121      .card-img { }                    4  (Property Name Error, Syntax Error)
  122 - 127      .card-title { }                  1  (Invalid Value Error)
  128 - 132      .card-title::before { }          1  (Syntax Error)
  133 - 138      .price { }                       1  (Property Name Error)
  139 - 150      .badge { }                       2  (Syntax Error, Unit Error)
  151 - 151      Comment: Pricing Table           1  (Comment Error)
  159 - 165      .price-table th, .price-table td 2  (Property Name Error, Syntax Error)
  166 - 169      .price-table tr:nth-child(even)  1  (Pseudo-class / Pseudo-element Error)
  171 - 178      .contact-form { }                1  (Syntax Error)
  179 - 186      .contact-form input, .contact-fo 2  (Selector Error, Syntax Error)
  192 - 192      Comment: Footer                  1  (Comment Error)
  193 - 199      .site-footer { }                 1  (Syntax Error)
  206 - 210      @keyframes fadeIn                1  (Animation / Transition Error)
  212 - 224      @media (responsive)              3  (Layout Error (Flexbox/Grid), Syntax Error, Unit Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
