======================================================================
  HTML-06  |  HTML  |  Petal Palace
======================================================================

File to fix      : index.html
Errors hidden    : 55
Difficulty       : 35 / 100   (Easy 33, Medium 18, Hard 4)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. Open index.html in Chrome/Firefox.
  2. Go to https://validator.w3.org/#validate_by_input and paste the whole file. Fix the FIRST error, re-check, repeat.
  3. Then click every link and try the form.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 32
  Attribute Error                          x 8
  Table Error                              x 4
  Form Error                               x 4
  Document Setup Error                     x 2
  Link / Path Error                        x 2
  Nesting / Structure Error                x 1
  Entity / Special Character Error         x 1
  Accessibility Error                      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Attribute Error
    Every attribute looks like name="value" - check spelling (class, href, src, required), the = sign, and BOTH quotes. a/link use href; img/script/source use src.

  * Table Error
    Each row is <tr><td>..</td><td>..</td></tr>. A <th> closes with </th>, a <td> with </td>.

  * Form Error
    Valid input types: text, email, tel, date, checkbox... Form method is get or post. Button type is submit. Close <textarea>.

  * Document Setup Error
    Compare the first lines with the standard skeleton: <!DOCTYPE html>, <meta charset="UTF-8">, <meta name="viewport" content="width=device-width, initial-scale=1.0">.

  * Link / Path Error
    Click every link. #links must match an id exactly. URLs start with https:// . Paths use / not \. Email = mailto: , phone = tel: .

  * Nesting / Structure Error
    Tags close in reverse order: <li><a>..</a></li>. Lists (ul/ol) can only contain <li>.

  * Entity / Special Character Error
    Codes like &copy; &amp; &#8377; must end with a semicolon. Write &lt; instead of a raw < in text.

  * Accessibility Error
    Every <img> needs alt="...". A <label for="x"> must match an input with id="x". Every <iframe> needs a title.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 10         Head (document setup)            5  (Attribute Error, Document Setup Error, Syntax Error)
  11 - 22        Header & navigation              1  (Syntax Error)
  23 - 34        FAQ section                      5  (Attribute Error, Syntax Error)
  35 - 54        Price table                      8  (Syntax Error, Table Error)
  55 - 69        Team section                     5  (Nesting / Structure Error, Syntax Error)
  70 - 85        Gallery                          6  (Attribute Error, Syntax Error)
  86 - 97        Media section                    3  (Attribute Error, Syntax Error)
  98 - 109       Products list                    6  (Attribute Error, Entity / Special Character Error, Syntax Error)
  110 - 116      Hero section                     2  (Attribute Error, Syntax Error)
  117 - 141      Contact form                     8  (Accessibility Error, Attribute Error, Form Error, Link / Path Error, Syntax Error)
  142 - 150      About section                    3  (Link / Path Error, Syntax Error)
  151 - 158      Footer & closing tags            3  (Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
