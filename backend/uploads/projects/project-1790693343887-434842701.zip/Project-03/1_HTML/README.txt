======================================================================
  HTML-03  |  HTML  |  Open Pages Library
======================================================================

File to fix      : index.html
Errors hidden    : 57
Difficulty       : 38 / 100   (Easy 37, Medium 9, Hard 11)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. Open index.html in Chrome/Firefox.
  2. Go to https://validator.w3.org/#validate_by_input and paste the whole file. Fix the FIRST error, re-check, repeat.
  3. Then click every link and try the form.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 36
  Attribute Error                          x 6
  Link / Path Error                        x 5
  Duplicate ID Error                       x 3
  Nesting / Structure Error                x 2
  Form Error                               x 2
  Table Error                              x 1
  Accessibility Error                      x 1
  Entity / Special Character Error         x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Attribute Error
    Every attribute looks like name="value" - check spelling (class, href, src, required), the = sign, and BOTH quotes. a/link use href; img/script/source use src.

  * Link / Path Error
    Click every link. #links must match an id exactly. URLs start with https:// . Paths use / not \. Email = mailto: , phone = tel: .

  * Duplicate ID Error
    Use Ctrl+F on id=" - every id value must appear only once on the page.

  * Nesting / Structure Error
    Tags close in reverse order: <li><a>..</a></li>. Lists (ul/ol) can only contain <li>.

  * Form Error
    Valid input types: text, email, tel, date, checkbox... Form method is get or post. Button type is submit. Close <textarea>.

  * Table Error
    Each row is <tr><td>..</td><td>..</td></tr>. A <th> closes with </th>, a <td> with </td>.

  * Accessibility Error
    Every <img> needs alt="...". A <label for="x"> must match an input with id="x". Every <iframe> needs a title.

  * Entity / Special Character Error
    Codes like &copy; &amp; &#8377; must end with a semicolon. Write &lt; instead of a raw < in text.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 10         Head (document setup)            3  (Attribute Error, Syntax Error)
  11 - 22        Header & navigation              5  (Syntax Error)
  23 - 42        Price table                      5  (Syntax Error, Table Error)
  43 - 54        FAQ section                      4  (Syntax Error)
  55 - 66        Products list                    4  (Duplicate ID Error, Syntax Error)
  67 - 81        Team section                     5  (Nesting / Structure Error, Syntax Error)
  82 - 90        About section                    6  (Link / Path Error, Nesting / Structure Error, Syntax Error)
  91 - 115       Contact form                     7  (Attribute Error, Duplicate ID Error, Form Error, Syntax Error)
  116 - 127      Media section                    3  (Attribute Error, Syntax Error)
  128 - 134      Hero section                     1  (Accessibility Error)
  135 - 150      Gallery                          9  (Attribute Error, Duplicate ID Error, Link / Path Error, Syntax Error)
  151 - 158      Footer & closing tags            5  (Entity / Special Character Error, Link / Path Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
