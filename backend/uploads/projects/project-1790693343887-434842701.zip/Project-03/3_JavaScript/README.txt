======================================================================
  JS-03  |  JavaScript  |  Celebrate Events
======================================================================

File to fix      : script.js
Errors hidden    : 56
Difficulty       : 39 / 100   (Easy 28, Medium 22, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 28
  ReferenceError                           x 7
  TypeError                                x 5
  Logic Error                              x 4
  Object / Class Error                     x 4
  Function / Return Error                  x 3
  Loop Error                               x 2
  Type Coercion Error                      x 2
  String Method Error                      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

  * String Method Error
    ${ } only works inside backticks ` `. Check string method names (trim, toUpperCase).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 17         Task 1                           5  (Function / Return Error, Loop Error, SyntaxError, TypeError)
  18 - 25        Task 2                           3  (Function / Return Error, Logic Error, SyntaxError)
  26 - 31        Task 3                           3  (ReferenceError, SyntaxError)
  32 - 41        Task 4                           4  (SyntaxError, Type Coercion Error)
  42 - 48        Task 5                           3  (ReferenceError, SyntaxError, Type Coercion Error)
  49 - 54        Task 6                           2  (SyntaxError)
  55 - 60        Task 7                           3  (SyntaxError, TypeError)
  61 - 73        Task 8                           4  (Function / Return Error, ReferenceError, SyntaxError)
  74 - 78        Task 9                           1  (Object / Class Error)
  79 - 86        Task 10                          3  (Logic Error, SyntaxError, TypeError)
  87 - 102       Task 11                          3  (ReferenceError, SyntaxError)
  103 - 109      Task 12                          3  (ReferenceError, String Method Error, SyntaxError)
  110 - 115      Task 13                          3  (SyntaxError)
  122 - 127      Task 15                          2  (Object / Class Error, SyntaxError)
  128 - 133      Task 16                          1  (SyntaxError)
  134 - 139      Task 17                          2  (Object / Class Error, SyntaxError)
  140 - 148      Task 18                          3  (Logic Error, SyntaxError, TypeError)
  149 - 162      Task 19                          4  (Object / Class Error, ReferenceError, SyntaxError)
  169 - 177      Task 21                          4  (Logic Error, Loop Error, ReferenceError, SyntaxError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
