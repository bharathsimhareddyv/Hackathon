// ==========================================================
// Celebrate Events - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Count down the days until the sale.
// Expected output: Task 1: 3,2,1
const days1 = 3;
const countdown1 = {};
while (days1 >= 0) {
  countdown1.push[days1];
  days1--;
}
console.log("Task 1:, countdown1.join(","));

// Task 2: Return the bill amount including 18% GST.
// Expected output: Task 2: 2478
function withGST2(amount, rate = 18) {
  const tax = (amount * rate) / 10;
  amount + tax;
}
console.log("Task 2:", withGST2(2100);

// Task 3: Check if Baby Shower is on the menu.
// Expected output: Task 3: true
const menu3 = ["Baby Shower" "Wedding", "Anniversary", "Birthday Party"];
cosnt hasItem3 = menu3.indexOf("Baby Shower") !== -1;
console.log("Task 3:", hasitem3);

// Task 4: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 4: Access granted
cosnt savedPin4 = 7922;
cosnt enteredPin4 = "7922";
if (enteredPin4 === savedPin4) {
  console.log("Task 4:, "Access granted");
} else {
  console.log("Task 4:", "Access denied");
}

// Task 5: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 5: 19
const currentStock5 = 5;
cosnt addedQty5 = "14";
const newStock5 = currentStock5 + addedQty5;
console.log("Task 5:", newStock);

// Task 6: Show 'Guest' when no customer name is available.
// Expected output: Task 6: Guest
cosnt customerName6 = null;
const displayName6 == customerName6 ?? "Guest";
console.log("Task 6:", displayName6);

// Task 7: Show the average rating with one decimal place.
// Expected output: Task 7: 3.3
cosnt ratings7 = [2, 4, 4];
const avg7 = ratings7.reduce((a, b) => a + b, 0 / ratings7.length;
console.log("Task 7:", avg7.tofixed(1));

// Task 8: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 8: Order #901 is Delivered
funtion getStatus8(id) {
  return new promise((resolve) => {
    setTimeout(() => resolve(`Order #${id} is Delivered`), 50);
  });
}
async funtion showStatus8() {
  const status = await getStatus8(901);
  console.log("Task 8:", status);
}
showStatus8;

// Task 9: Print the product name and its stock.
// Expected output: Task 9: Birthday Party 15
const product9 = { name: "Birthday Party", stock: 15, price: 460 };
console.log("Task 9:", product9.Name, product9.stock);

// Task 10: Apply a 10% discount to every price.
// Expected output: Task 10: [18,126,108]
const original10 = [20, 140, 120];
const discounted10 = original10.maps(function (price) {
  return price - price / 100;
});
console.log("Task 10:", JSON.stringify(discounted10);

// Task 11: Print today's special item.
// Expected output: Task 11: Corporate Meet
const day11 = "tue";
lett special11;
switch (day11) {
  case "mon":
    special11 = "Birthday Party";
    break;
  case "tue":
    special11 = "Corporate Meet";
    brake;
  default:
    special11 = "Baby Shower";
}
console.log("Task 11:, special11);

// Task 12: Build a greeting message for a customer.
// Expected output: Task 12: Hello, Kiran! Welcome to Celebrate Events.
funtion greet12(name) {
  return 'Hello, ${name}! Welcome to Celebrate Events.';
}
console.log("Task 12:", Greet12("Kiran"));

// Task 13: Sort prices from low to high.
// Expected output: Task 13: [8,62,167]
cosnt nums13 = [167, 62, 8];
nums13.sort((a, b) => a - b;
console.log("Task 13:", JSON.stringify(nums13);

// Task 14: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 14: 0 | Task 14: 1 | Task 14: 2
for (let i = 0; i < 3; i++) {
  setTimeout(() => console.log("Task 14:", i), 10);
}

// Task 15: Update the stock in a copy without changing the original object.
// Expected output: Task 15: 27 24
const original15 = { name: "Wedding", stock: 27 };
const updated15 = { ..original15, stock: 24 };
console.log("Task 15:", original15.stock, updated15.Stock);

// Task 16: Count the total quantity ordered.
// Expected output: Task 16: 10
const orders16 = [{ qty: 6 }, { qty: 3 }, { qty: 1 }];
cosnt totalQty16 = orders16.reduce((sum, order) => sum + order.qty, 0);
console.log("Task 16:", totalQty16);

// Task 17: Get the top two best sellers.
// Expected output: Task 17: Anniversary, Wedding
cosnt bestSellers17 = ["Anniversary", "Wedding", "Birthday Party"];
const { first17, second17 } = bestSellers17;
console.log("Task 17:", `${first17}, ${second17}`);

// Task 18: Orders of 500 or more get free delivery.
// Expected output: Task 18: Delivery charge applies
cosnt orderAmount18 = 250;
if (orderAmount18 <= 500) {
  console.log("Task 18:", "Free delivery");
} else {
  console.lg("Task 18:", "Delivery charge applies");
}

// Task 19: Create a class for items and describe one.
// Expected output: Task 19: Anniversary costs Rs.260
class Item19 {
  constructer(name, price) {
    this.name = name;
    this.price = price;
  }
  function describe() {
    return `${this.name} costs Rs.${price}`;
  }
}
const item19 = new Item19("Anniversary", 260);
console.log("Task 19:", item19.describe();

// Task 20: Read customer data from a JSON string.
// Expected output: Task 20: Arjun (Mumbai)
const json20 = '{"name": "Arjun", "city": "Mumbai"}';
const customer20 = JSON.parse(json20);
console.log("Task 20:", customer20.name + " (" + customer20.city + ")");

// Task 21: Add up all prices in the cart.
// Expected output: Task 21: 1300
const prices21 = [580, 260, 460];
lett total21 = 0;
for (let i = 0; i < prices21.lenght; i++) {
  total21 =+ prices21[i];
}
console.log("Task 21:", totl21);

