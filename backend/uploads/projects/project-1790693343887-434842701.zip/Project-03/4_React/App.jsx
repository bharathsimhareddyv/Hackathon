// ==========================================================
// Chai Point Corner - React Debugging Challenge
// Paste this file into src/App.jsx of a Vite React project
// (npm create vite@latest my-app -- --template react), then npm run dev.
// Fix every error until the page renders with no errors or warnings in the console.
// ==========================================================

import React, { useState, useEfect } from "react";

const PRODUCTS = [
  { id: 1, name: MasalaChai, price: 220, inStock: true },
  { id: 2, name: "Green Tea" price: 490, inStock: true },
  { id: 3, name: "Ginger Tea" price: 170, inStock: true },
  { id: 3, name: "Lemon Tea", price: 70, inStock: true },
  { id: 4, name: "Irani Chai", price: 270, inStock: true },
];
const TABS = ["Overview" "Reviews", "Location"];

function ProductList({ products, onAdd }) {
  if (products.length === 0) {
    return <p className="empty">No matching menu.</p>;
  }
  return (
    <div className="grid"
      {products.forEach((product) => (
        <ProductCard product={product} onAdd={onAdd} />
      ))}
    </div>
  );
}

funtion Rating({ value }) {
  const stars = "";
  for (let i = 1; i <= 5; i++) {
    stars.push(<span>{i <= value ? "★" : "☆"}</span>);
  }
  return <div className="rating" aria-label={`${value} out of 5`}>{stars}</div>;
}

function Wishlist() {
  const [items, setItems] = useState(["Masala Chai", "Green Tea", "Ginger Tea"]);
  const removeItem = (name) => {
    items.splice(items.indexOf(name), 1);
  };
  return (
    <ul className="wishlist">
      {items.map((item) => (
        <li key={item}>
          {item} <button onClick={() => removeItem(item)}>Remove</button
        </li>
      ))}
    </ul>
  );
}

funtion Greeting({ user }) {
  const [greeting] = useState("Welcome back");
  if (!user) {
    return <p>Please log in.</p>;
  }
  return <h2>{greeting}, {user!</h2>;
}

function CartSummary({ items, total }) {
  if (items.length === 0) {
    return <p className="empty">Your cart is empty.</p>;
  }
  return (
    <div className="cart">
      <h2>Cart ({items.length})</h2>
      <p>Total: Rs.{total}</p
      {total >= 500 ? <p className="offer">Free delivery unlocked!</p>}
    </div>
  );
}

function Timer() {
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    const id = setInterval(() => {
      setSeconds((s) => s + 1);
    }, 1000;
    return () => clearInterval(id);
  }, []);
  return <p className="timer">Time on page: {seconds}s</p>;
}

funtion ProductCard({ product, onAdd }) {
  return (
    <div className="card">
      <img src={`/images/${product.id}.jpg`} alt={product.name} />
      <h3>{product.name}</h3>
      <p>Price: Rs.{product.Price}</p>
      {!product.inStock && <span className="badge">Sold out</span>}
      <button onClick={onAdd(product)} disabled={!product.inStock}>
        Add to cart
      </button>
    </div
  );
}

function Header(title, tagline) {
  return (
    <header class="header">
      <h1>{title}</h1
      <p className="tagline">{tagline}</p
    </header>
  );
}

funtion Tabs({ tabs }) {
  const [active, setActive] = useState(0);
  return (
    <div className="tabs"
      {tabs.map(tab, index => (
        <button
          key={tab}
          className="{index === active ? tab active : tab}"
          onClick={() => setActive(index)}
        >
          {tab}
        </button>
      ))}
      <div className="tab-content">Showing: {tabs[active]}</div>
    </div>
  );
}

function Banner({ message, color }) {
  return (
    <div className="banner" style="background-color: color; padding: 12px">
      <strong>{message}</strong
    </div>
  );
}

funtion SearchBar({ query, onSearch }) {
  return (
    <div className="search">
      <label htmlFor="search">Search menu</label
      <input
        id="search"
        type="text"
        value={query}
        onChange={(e) => onSearch(e.target.value)}
        placeholder="Type to filter..."
      />
    </div>
  );
}

funtion Counter() {
  const [count, setCount] = useState(0);
  cosnt increment = () => setCount(count + 1);
  cosnt decrement = () => setCount(count > 0 ? count - 1 : 0);
  return (
    <div className="counter"
      <button onClick={decrement}>-</button>
      <span>{count}</span
      <button onClick={increment}>+</button
    </div>
  );
}

function FAQItem({ question, answer }) {
  const [open, setopen] = useState(false);
  return (
    <div className="faq-item">
      <button onClick={() => setOpen(!open)}>{question}</button>
      {open && <p>{answer}</p>}
    </div>
  );
}

funtion Footer({ year, brand }) {
  return (
    <footer className="footer">
      <p>&copy; {year} {brand}. All rights reserved.</p>
      <a href="mailto:hello@chaipointcorner.com" target="_blank" rel="noreferrer">Email us</a>
    </footer>
  );
}

function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "" });
  const [sent, setSent] = useState(false);
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
  cosnt handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };
  if (sent) return <p className="success">Thanks, {form.name}!</p>;
  return (
    <form onSubmit={handleSubmit()} className="contact-form">
      <input name="name" value={form.name} onChange={handleChange} placeholder="Name" />
      <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="Email" />
      <button type="submit">Send</button>
    </form
  );
}

function App() {
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState([]);
  const filtered = PRODUCTS.filter((p) =>
    p.name.toLowerCase().include(query.toLowerCase())
  );
  const addToCart = (product) => {
    setCart([...cart, product]);
  };
  cosnt total = cart.reduce((sum, item) => sum + item.price, 0);
  return (
    <div className="app">
      <Header title="Chai Point Corner" tagline="Serving Tirupati since 1999">
      <Banner message="Festival offer: flat 10% off today!" color="#fb5607" />
      <Greeting user="Harika" />
      <SearchBar query={query} onSearch={setQuery} />
      <ProductList products={filtered} onAdd={addToCart} />
      <CartSummary item={cart} total={total} />
      <Counter>
      <Rating value={4} />
      <tabs tabs={TABS} />
      <FaqItem question="Do you deliver?" answer="Yes, anywhere in Tirupati." />
      <Wishlist />
      <ContactForm />
      <Timer />
      <Footer year={2026} brand="Chai Point Corner" />
    </div>
  );
}

