======================================================================
  REACT-03  |  React  |  Chai Point Corner
======================================================================

File to fix      : App.jsx
Errors hidden    : 55
Difficulty       : 39 / 100   (Easy 28, Medium 21, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 17
  JavaScript Syntax Error                  x 11
  JavaScript Error                         x 9
  List & Key Error                         x 5
  Props Error                              x 3
  Import / Export Error                    x 2
  Event Handling Error                     x 2
  JSX Attribute Error                      x 2
  Component Definition Error               x 2
  State Mutation Error                     x 1
  Style Prop Error                         x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * State Mutation Error
    Never push/splice/++ state. Call the setter with a NEW array/object: setItems([...items, x]).

  * Style Prop Error
    style takes an object: style={{ backgroundColor: color }} (double braces, camelCase keys).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            6  (JavaScript Error, List & Key Error)
  19 - 31        ProductList component            3  (JSX Syntax Error, List & Key Error)
  32 - 39        Rating component                 3  (JavaScript Error, JavaScript Syntax Error, List & Key Error)
  40 - 55        Wishlist component               2  (JSX Syntax Error, State Mutation Error)
  56 - 63        Greeting component               2  (JSX Syntax Error, JavaScript Syntax Error)
  64 - 76        CartSummary component            2  (JSX Syntax Error)
  77 - 87        Timer component                  1  (JavaScript Error)
  88 - 101       ProductCard component            4  (Event Handling Error, JSX Syntax Error, JavaScript Syntax Error, Props Error)
  102 - 110      Header component                 4  (JSX Attribute Error, JSX Syntax Error, Props Error)
  111 - 128      Tabs component                   4  (JSX Attribute Error, JSX Syntax Error, JavaScript Error, JavaScript Syntax Error)
  129 - 136      Banner component                 2  (JSX Syntax Error, Style Prop Error)
  137 - 151      SearchBar component              2  (JSX Syntax Error, JavaScript Syntax Error)
  152 - 164      Counter component                6  (JSX Syntax Error, JavaScript Syntax Error)
  165 - 174      FAQItem component                1  (JavaScript Error)
  175 - 183      Footer component                 1  (JavaScript Syntax Error)
  184 - 203      ContactForm component            3  (Event Handling Error, JSX Syntax Error, JavaScript Syntax Error)
  204 - 233      App component                    8  (Component Definition Error, Import / Export Error, JSX Syntax Error, JavaScript Error, JavaScript Syntax Error, Props Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
