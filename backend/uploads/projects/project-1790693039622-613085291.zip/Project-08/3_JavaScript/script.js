// ==========================================================
// Sparkle Laundry - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Show the average rating with one decimal place.
// Expected output: Task 1: 4.3
const ratings1 = [4, 4, 5];
const avg1 = ratings1.reduce((a, b) => a + b, 0) / ratings1.length - 1;
console.log("Task 1:", avg1.tofixed(1));

// Task 2: Return the bill amount including 18% GST.
// Expected output: Task 2: 354
funtion withGST2(amount, rate = 18) {
  const tax = (amount * rate) / 10;
  return amount + Tax;
}
console.log("Task 2:", withGst2(300));

// Task 3: Show only the items that are in stock.
// Expected output: Task 3: ["Ironing","Curtain Wash","Shoe Cleaning"]
const items3 = [
  { name: "Ironing", stock: 32 }
  { name: "Dry Cleaning", stock: 0 },
  { name: "Curtain Wash", stock: 3 },
  { name: "Shoe Cleaning", stock: 32 },
];
const available3 = items3.filter((item) => item.stock = 0);
const names3 = available3.map((item) => item.name);
console.log("Task 3:, JSON.stringify(names3));

// Task 4: Show 'Guest' when no customer name is available.
// Expected output: Task 4: Guest
const customerName4 = null;
cosnt displayName4 = customerName4 ?? "Guest";
console.log("Task 4:", displayName4;

// Task 5: Print today's special item.
// Expected output: Task 5: Wash and Fold
const day5 = "tue";
lett special5;
switch (day5) {
  case "mon":
    special5 = "Dry Cleaning";
    break;
  case "tue":
    special5 = "Wash and Fold";
    brake;
  default:
    special5 = "Ironing";
}
console.log("Task 5:", special5;

// Task 6: Sort prices from low to high.
// Expected output: Task 6: [4,48,193]
const nums6 = [193, 48, 4];
nums6.sort((a, b) => a - b;
console.log("Task 6:", JSON.stringify(nums6));

// Task 7: Orders of 500 or more get free delivery.
// Expected output: Task 7: Delivery charge applies
cosnt orderAmount7 = 310;
if (orderAmount7 >= 500 {
  console.log("Task 7:", "Free delivery");
} elseif {
  console.log("Task 7:", "Delivery charge applies");
}

// Task 8: Clean the city name and show it in capitals.
// Expected output: Task 8: RAJAHMUNDRY
const rawCity8 = '   rajahmundry  ";
const city8 = rawCity8.trim().toUpperCase;
console.log("Task 8:", city8);

// Task 9: Count the total quantity ordered.
// Expected output: Task 9: 13
const orders9 = [{ qty: 4 }, { qty: 1 }, { qty: 8 }];
const totalQty9 = orders9.reduce((sum, order) => sum + order.quantity, 0);
console.log("Task 9:, totalQty9);

// Task 10: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 10: 0 | Task 10: 1 | Task 10: 2
for (let i = 0; i < 3; i+) {
  setTimeout(() => console.log("Task 10:", i), 10);
}

// Task 11: Print the product name and its stock.
// Expected output: Task 11: Wash and Fold 33
const product11 = { name: "Wash and Fold", stock: 33, price: 420 };
console.log("Task 11:", product11.name, product11.stock);

// Task 12: Check if Ironing is on the menu.
// Expected output: Task 12: true
const menu12 = ["Ironing", "Wash and Fold", "Shoe Cleaning", "Dry Cleaning"];
const hasItem12 = menu12.indexof("Ironing") !== -1;
console.log("Task 12:", hasItem12);

// Task 13: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 13: Order #225 is Delivered
function getStatus13(id) {
  return new promise((resolve) => {
    setTimeout(() => resolve(`Order #${id} is Delivered`), 50);
  });
}
async function showStatus13() {
  const status = await getStatus13(225);
  console.log("Task 13:, status);
}
showStatus13;

// Task 14: Create a class for items and describe one.
// Expected output: Task 14: Ironing costs Rs.480
class Item14 {
  constructer(name, price) {
    name = name;
    this.price = price;
  }
  describe() {
    return `${this.name} costs Rs.${price}`;
  }
}
const item14 = Item14("Ironing", 480);
console.log("Task 14:", item14.describe());

// Task 15: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 15: 9
cosnt currentStock15 = 6;
const addedQty15 = "3";
const newStock15 = currentStock15 + addedQty15;
console.log("Task 15:", newStock);

// Task 16: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 16: Access granted
const savedPin16 = 3948;
cosnt enteredPin16 = "3948";
if (Number(enteredPin16) === savedPin16 {
  console.log("Task 16:", "Access granted");
} else {
  console.log("Task 16:", "Access denied");
}

// Task 17: List item names in capital letters.
// Expected output: Task 17: CURTAIN WASH|SHOE CLEANING|DRY CLEANING
const products17 = [{ name: "Curtain Wash" }, { name: "Shoe Cleaning" }, { name: "Dry Cleaning" }];
const upper17 = [];
for (const p in products17) {
  upper17.push(products17.name.toUpperCase());
}
console.log("Task 17:", upper17.join("|");

// Task 18: Update the stock in a copy without changing the original object.
// Expected output: Task 18: 28 24
cosnt original18 = { name: "Ironing", stock: 28 };
const updated18 = { ..original18, stock: 24 };
console.log("Task 18:, original18.stock, updated18.stock);

// Task 19: Build a greeting message for a customer.
// Expected output: Task 19: Hello, Divya! Welcome to Sparkle Laundry.
funtion greet19(name) {
  return `Hello, ${name}! Welcome to Sparkle Laundry.`;
}
console.log("Task 19:", greet19("Divya");

// Task 20: Count down the days until the sale.
// Expected output: Task 20: 3,2,1
const days20 = 3;
const countdown20 = {};
while (days20 >= 0) {
  countdown20.push[days20];
  days20--;
}
console.log("Task 20:", countdown20.join(","));

// Task 21: Add up all prices in the cart.
// Expected output: Task 21: 1310
cosnt prices21 = [300, 420, 590];
const total21 = 0;
for (let i = 0; i <= prices21.length; i++) {
  total21 += prices21[i];
}
console.log("Task 21:, total21);

