======================================================================
  JS-08  |  JavaScript  |  Sparkle Laundry
======================================================================

File to fix      : script.js
Errors hidden    : 52
Difficulty       : 39 / 100   (Easy 26, Medium 21, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 26
  TypeError                                x 6
  ReferenceError                           x 6
  Logic Error                              x 4
  Function / Return Error                  x 3
  Object / Class Error                     x 3
  Loop Error                               x 3
  Type Coercion Error                      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 13         Task 1                           2  (Logic Error, TypeError)
  14 - 21        Task 2                           4  (Logic Error, ReferenceError, SyntaxError)
  22 - 33        Task 3                           3  (Logic Error, SyntaxError)
  34 - 39        Task 4                           2  (SyntaxError)
  40 - 55        Task 5                           3  (ReferenceError, SyntaxError)
  56 - 61        Task 6                           1  (SyntaxError)
  62 - 70        Task 7                           3  (SyntaxError)
  71 - 76        Task 8                           2  (Function / Return Error, SyntaxError)
  77 - 82        Task 9                           2  (Object / Class Error, SyntaxError)
  83 - 88        Task 10                          1  (SyntaxError)
  94 - 99        Task 12                          1  (TypeError)
  100 - 112      Task 13                          3  (Function / Return Error, ReferenceError, SyntaxError)
  113 - 126      Task 14                          4  (Object / Class Error, ReferenceError, TypeError)
  127 - 133      Task 15                          3  (ReferenceError, SyntaxError, Type Coercion Error)
  134 - 143      Task 16                          2  (SyntaxError)
  144 - 152      Task 17                          3  (Logic Error, Loop Error, SyntaxError)
  153 - 158      Task 18                          3  (SyntaxError)
  159 - 165      Task 19                          2  (SyntaxError)
  166 - 175      Task 20                          4  (Function / Return Error, Loop Error, TypeError)
  176 - 184      Task 21                          4  (Loop Error, SyntaxError, TypeError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
