======================================================================
  REACT-08  |  React  |  Golden Glow Jewellers
======================================================================

File to fix      : App.jsx
Errors hidden    : 56
Difficulty       : 39 / 100   (Easy 28, Medium 22, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 16
  JavaScript Syntax Error                  x 12
  JavaScript Error                         x 9
  JSX Attribute Error                      x 5
  Props Error                              x 5
  Component Definition Error               x 3
  List & Key Error                         x 3
  Import / Export Error                    x 1
  Style Prop Error                         x 1
  Event Handling Error                     x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * Style Prop Error
    style takes an object: style={{ backgroundColor: color }} (double braces, camelCase keys).

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            5  (JavaScript Error)
  19 - 36        Tabs component                   6  (JSX Attribute Error, JSX Syntax Error, JavaScript Syntax Error)
  37 - 45        Header component                 3  (Component Definition Error, JSX Attribute Error, JSX Syntax Error)
  46 - 53        Banner component                 2  (JavaScript Syntax Error, Style Prop Error)
  54 - 61        Rating component                 2  (JavaScript Error, List & Key Error)
  62 - 76        SearchBar component              3  (JSX Attribute Error, JSX Syntax Error)
  77 - 89        ProductList component            3  (JSX Syntax Error, List & Key Error, Props Error)
  90 - 99        FAQItem component                2  (JSX Syntax Error, JavaScript Error)
  100 - 119      ContactForm component            4  (JSX Syntax Error, JavaScript Syntax Error)
  120 - 128      Footer component                 3  (JSX Syntax Error, Props Error)
  129 - 142      ProductCard component            4  (JSX Syntax Error, JavaScript Syntax Error, Props Error)
  143 - 155      CartSummary component            1  (JSX Syntax Error)
  156 - 166      Timer component                  2  (JavaScript Error, JavaScript Syntax Error)
  167 - 174      Greeting component               2  (JavaScript Syntax Error)
  175 - 190      Wishlist component               2  (JSX Syntax Error, List & Key Error)
  191 - 203      Counter component                2  (JSX Syntax Error, JavaScript Syntax Error)
  204 - 233      App component                    9  (Component Definition Error, Event Handling Error, JSX Attribute Error, JSX Syntax Error, JavaScript Error, JavaScript Syntax Error, Props Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
