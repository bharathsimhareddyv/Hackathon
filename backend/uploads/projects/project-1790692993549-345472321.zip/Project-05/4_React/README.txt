======================================================================
  REACT-05  |  React  |  Daily Needs Mart
======================================================================

File to fix      : App.jsx
Errors hidden    : 52
Difficulty       : 39 / 100   (Easy 26, Medium 21, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. npm create vite@latest my-app -- --template react
  2. cd my-app  &&  npm install
  3. Copy this App.jsx over my-app/src/App.jsx, then run:  npm run dev
  4. Open the link shown, press F12 > Console. Fix errors until the page shows with no red/yellow messages.
  5. Then click every button, type in the inputs and wait for the timer - some errors only appear when you use the page.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  JSX Syntax Error                         x 14
  JavaScript Syntax Error                  x 12
  JavaScript Error                         x 7
  List & Key Error                         x 5
  Event Handling Error                     x 4
  JSX Attribute Error                      x 4
  Import / Export Error                    x 2
  Component Definition Error               x 2
  Style Prop Error                         x 1
  Props Error                              x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * JSX Syntax Error
    The Vite overlay shows the line. Every JSX tag must close, <img /> and <input /> self-close, and { } must be balanced.

  * JavaScript Syntax Error
    Look for misspelled keywords: cosnt -> const, funtion -> function.

  * JavaScript Error
    Plain JavaScript mistakes inside React: missing commas, True instead of true, wrong names or brackets.

  * List & Key Error
    Use .map() to render lists and give each item key={...}. Ids must be unique.

  * Event Handling Error
    onClick / onChange (camelCase) must receive a function: onClick={handle} or onClick={() => handle(x)}. Never onClick={handle()}.

  * JSX Attribute Error
    In JSX: class -> className, for -> htmlFor, and expressions go inside { } not quotes.

  * Import / Export Error
    Hooks are imported from "react". The App must be 'export default function App()'.

  * Component Definition Error
    Component names start with a CAPITAL letter and must be spelled the same where defined and where used.

  * Style Prop Error
    style takes an object: style={{ backgroundColor: color }} (double braces, camelCase keys).

  * Props Error
    The prop name in the parent must match the name the child reads. Components receive ONE object: function Card({ a, b }).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 9          Imports                          1  (Import / Export Error)
  10 - 18        Data (PRODUCTS, TABS)            4  (JavaScript Error, List & Key Error)
  19 - 34        Wishlist component               5  (Event Handling Error, JSX Syntax Error, JavaScript Syntax Error, List & Key Error)
  35 - 54        ContactForm component            5  (Event Handling Error, JavaScript Syntax Error)
  55 - 68        ProductCard component            1  (JavaScript Syntax Error)
  69 - 79        Timer component                  1  (JavaScript Error)
  80 - 92        Counter component                2  (JavaScript Error, JavaScript Syntax Error)
  93 - 105       CartSummary component            3  (JSX Syntax Error, JavaScript Syntax Error)
  106 - 115      FAQItem component                2  (Event Handling Error, JSX Syntax Error)
  116 - 124      Header component                 2  (JSX Attribute Error, JSX Syntax Error)
  125 - 139      SearchBar component              4  (JSX Attribute Error, JSX Syntax Error, JavaScript Syntax Error)
  140 - 152      ProductList component            4  (JSX Syntax Error, List & Key Error)
  153 - 160      Rating component                 2  (JavaScript Error, List & Key Error)
  161 - 169      Footer component                 1  (JSX Syntax Error)
  170 - 187      Tabs component                   3  (JSX Attribute Error, JSX Syntax Error, JavaScript Error)
  188 - 195      Banner component                 2  (JSX Syntax Error, Style Prop Error)
  204 - 233      App component                    10  (Component Definition Error, Import / Export Error, JSX Syntax Error, JavaScript Syntax Error, Props Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
