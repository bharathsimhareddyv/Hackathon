======================================================================
  CSS-05  |  CSS  |  Green Basket Organics
======================================================================

File to fix      : style.css
Errors hidden    : 53
Difficulty       : 42 / 100   (Easy 21, Medium 27, Hard 5)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. index.html is CORRECT - do not edit it. Fix style.css only.
  2. Open index.html in the browser, press F12 > Elements, click an element and look at Styles: crossed-out lines are errors.
  3. Also paste style.css into https://jigsaw.w3.org/css-validator/#validate_by_input

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 20
  Property Name Error                      x 11
  Unit Error                               x 5
  Invalid Value Error                      x 4
  Color Error                              x 3
  Selector Error                           x 2
  Animation / Transition Error             x 2
  Layout Error (Flexbox/Grid)              x 2
  Font Error                               x 1
  CSS Variable Error                       x 1
  Comment Error                            x 1
  Media Query Error                        x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Property Name Error
    Look for misspelled property names (DevTools shows them crossed out). Use VS Code autocomplete to check spelling.

  * Unit Error
    Numbers need a unit (px, rem, %, s, deg) with NO space: 12px not 12 px. z-index and font-weight have NO unit.

  * Invalid Value Error
    The property is right but the value is not allowed. Check spelling of keywords (center, solid, absolute...), no commas in padding/margin, decimals use a dot.

  * Color Error
    Hex colours have 3 or 6 digits using only 0-9 and a-f. Check colour names and close rgba( ).

  * Selector Error
    Open index.html next to style.css. Classes start with '.', ids with '#'. The name must match the HTML exactly.

  * Animation / Transition Error
    @keyframes (with s), from/to, times need 's', and the animation name must match the keyframes name exactly (case!).

  * Layout Error (Flexbox/Grid)
    display: flex / grid. Check spelling of flex values (space-between, center, column) and commas inside repeat() and minmax().

  * Font Error
    Close the quotes around font names. The generic font is sans-serif (with hyphen). font-weight: bold or 700.

  * CSS Variable Error
    Variables are declared as --name: value; inside :root and used as var(--name). Names must match exactly.

  * Comment Error
    CSS comments are only /* ... */ . '//' is not a comment, and every /* needs a */.

  * Media Query Error
    Correct form: @media (max-width: 768px) { ... } - parentheses, colon, unit, space after 'and', closing }.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  4 - 10         :root { }                        2  (Syntax Error, Unit Error)
  12 - 17        * { }                            1  (Invalid Value Error)
  18 - 24        body { }                         4  (CSS Variable Error, Font Error, Property Name Error, Selector Error)
  26 - 33        .site-header { }                 1  (Selector Error)
  34 - 40        .logo { }                        3  (Property Name Error, Syntax Error, Unit Error)
  47 - 52        .nav-links a { }                 1  (Syntax Error)
  53 - 57        .nav-links a:hover { }           2  (Invalid Value Error, Syntax Error)
  59 - 66        .hero { }                        3  (Property Name Error, Syntax Error, Unit Error)
  67 - 72        .hero-title { }                  1  (Unit Error)
  73 - 77        .hero-text { }                   1  (Animation / Transition Error)
  79 - 88        .btn { }                         3  (Property Name Error, Syntax Error)
  89 - 93        .btn:hover { }                   2  (Color Error, Invalid Value Error)
  94 - 98        .btn-primary { }                 1  (Property Name Error)
  100 - 106      .card-grid { }                   2  (Property Name Error, Syntax Error)
  107 - 115      .card { }                        2  (Property Name Error, Syntax Error)
  116 - 121      .card-img { }                    1  (Syntax Error)
  122 - 127      .card-title { }                  1  (Property Name Error)
  128 - 132      .card-title::before { }          2  (Color Error, Syntax Error)
  133 - 138      .price { }                       1  (Property Name Error)
  139 - 150      .badge { }                       5  (Invalid Value Error, Syntax Error, Unit Error)
  152 - 158      .price-table { }                 1  (Syntax Error)
  159 - 165      .price-table th, .price-table td 1  (Syntax Error)
  171 - 178      .contact-form { }                1  (Layout Error (Flexbox/Grid))
  179 - 186      .contact-form input, .contact-fo 2  (Property Name Error, Syntax Error)
  187 - 191      .contact-form input:focus { }    1  (Color Error)
  193 - 199      .site-footer { }                 1  (Syntax Error)
  200 - 205      .social a { }                    1  (Syntax Error)
  206 - 210      @keyframes fadeIn                2  (Animation / Transition Error, Syntax Error)
  211 - 211      Comment: Responsive              1  (Comment Error)
  212 - 224      @media (responsive)              3  (Layout Error (Flexbox/Grid), Media Query Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
