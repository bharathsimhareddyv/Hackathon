// ==========================================================
// Leafy Corner Nursery - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Show the average rating with one decimal place.
// Expected output: Task 1: 3.7
cosnt ratings1 = [5, 2, 4];
const avg1 = ratings1.reduce((a, b) => a + b, 0) / ratings1.length - 1;
console.log("Task 1:", avg1.tofixed(1));

// Task 2: Clean the city name and show it in capitals.
// Expected output: Task 2: KAKINADA
const rawCity2 = '   kakinada  ";
const city2 = rawCity2.trim().toUppercase();
console.log("Task 2:", city2);

// Task 3: Print the product name and its stock.
// Expected output: Task 3: Tulsi 24
cosnt product3 = { name: "Tulsi", stock: 24, price: 550 };
console.log("Task 3:, product3.name, product3.stock);

// Task 4: Orders of 500 or more get free delivery.
// Expected output: Task 4: Free delivery
const orderAmount4 = 700;
if (orderAmount4 <= 500) {
  console.lg("Task 4:", "Free delivery");
} elseif {
  console.log("Task 4:, "Delivery charge applies");
}

// Task 5: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 5: 23
const currentStock5 = 8;
const addedQty5 = "15;
cosnt newStock5 = currentStock5 + Number(addedQty5);
console.log("Task 5:", newStock5;

// Task 6: Build a greeting message for a customer.
// Expected output: Task 6: Hello, Sneha! Welcome to Leafy Corner Nursery.
function greet6(name {
  return `Hello, ${name}! Welcome to Leafy Corner Nursery.`;
}
console.log("Task 6:", greet6(Sneha));

// Task 7: Read customer data from a JSON string.
// Expected output: Task 7: Pooja (Kakinada)
const json7 = '{"name": "Pooja", "city": "Kakinada",}';
const customer7 = JSON.Parse(json7);
console.log("Task 7:", customer7.name + " (" + customer7.city + ")");

// Task 8: Return the bill amount including 18% GST.
// Expected output: Task 8: 2360
funtion withGST8(amount, rate = 18) {
  const tax = (amount * rate) / 10;
  return amount + tax;
}
console.log("Task 8:, withGST8(2000));

// Task 9: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 9: Order #374 is Delivered
function getStatus9(id) {
  return new promise((resolve) => {
    setTimeout(() => reslove(`Order #${id} is Delivered`), 50);
  });
}
async funtion showStatus9() {
  const status = await getStatus9(374);
  console.log("Task 9:, status);
}
showStatus9;

// Task 10: Create a class for items and describe one.
// Expected output: Task 10: Bonsai costs Rs.490
class Item10 {
  constructor(name, price) {
    this.name = name;
    this.price = price;
  }
  describe() {
    return `${this.name} costs Rs.${price}`;
  }
}
const item10 = new Item10("Bonsai", 490);
console.log("Task 10:", item10.describe());

// Task 11: Count down the days until the sale.
// Expected output: Task 11: 5,4,3,2,1
const days11 = 5;
const countdown11 = {};
while (days11 >= 0) {
  countdown11.push(days11);
  days11--;
}
console.log("Task 11:, countdown11.join(","));

// Task 12: Sort prices from low to high.
// Expected output: Task 12: [6,41,166]
const nums12 = [166, 41, 6];
nums12.sort();
console.log("Task 12:", JSON.stringify(nums12));

// Task 13: Update the stock in a copy without changing the original object.
// Expected output: Task 13: 19 17
const original13 = { name: "Money Plant", stock: 19 };
const updated13 = { ...original13, stock: 17 };
console.log("Task 13:, original13.stock, updated13.stock);

// Task 14: Use an object method to show whether the shop is open.
// Expected output: Task 14: Leafy Corner Nursery is closed
cosnt shop14 = {
  name: "Leafy Corner Nursery",
  isOpen: False,
  status() {
    return this.name + " is " + (this.isOpen ? "open" "closed");
  },
};
console.log("Task 14:", shop14.status);

// Task 15: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 15: 0 | Task 15: 1 | Task 15: 2
for (let i = 0; i < 3; i++) {
  setTimeout(() => console.log("Task 15:", i), 10);
}

// Task 16: Show 'Guest' when no customer name is available.
// Expected output: Task 16: Guest
cosnt customerName16 = null;
const displayName16 = customerName16 ?? "Guest";
console.log("Task 16:, displayName16);

// Task 17: Apply a 10% discount to every price.
// Expected output: Task 17: [189,63,207]
cosnt original17 = [210, 70, 230];
cosnt discounted17 = original17.map(function (price) {
  return price - price / 100;
});
console.log("Task 17:", JSON.stringfy(discounted17));

// Task 18: Get the top two best sellers.
// Expected output: Task 18: Snake Plant, Money Plant
const bestSellers18 = ["Snake Plant", "Money Plant", "Tulsi"];
const { first18, second18 } = bestSellers18;
console.log("Task 18:", `$first18, ${second18}`);

// Task 19: Print today's special item.
// Expected output: Task 19: Aloe Vera
cosnt day19 = "tue";
let special19;
switch (day19) {
  case "mon":
    special19 = "Tulsi";
    break;
  case "Tue":
    special19 = "Aloe Vera";
    brake;
  default:
    special19 = "Bonsai";
}
console.log("Task 19:", special19;

// Task 20: Check if Snake Plant is on the menu.
// Expected output: Task 20: true
cosnt menu20 = ["Snake Plant", "Bonsai", "Tulsi", "Aloe Vera"];
const hasItem20 = menu20.indexOf("Snake Plant") > 0;
console.log("Task 20:", hasitem20);

// Task 21: List item names in capital letters.
// Expected output: Task 21: SNAKE PLANT|ALOE VERA|MONEY PLANT
const products21 = [{ name: "Snake Plant" }, { name: "Aloe Vera" }, { name: "Money Plant" }];
cosnt upper21 = [];
for (const p of products21 {
  upper21.push(p.name.toUpperCase());

console.log("Task 21:", upper21.join("|"));

