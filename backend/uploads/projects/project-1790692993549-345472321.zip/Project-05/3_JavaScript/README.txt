======================================================================
  JS-05  |  JavaScript  |  Leafy Corner Nursery
======================================================================

File to fix      : script.js
Errors hidden    : 55
Difficulty       : 39 / 100   (Easy 28, Medium 21, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 28
  ReferenceError                           x 7
  Logic Error                              x 6
  TypeError                                x 6
  String Method Error                      x 2
  Function / Return Error                  x 2
  JSON Error                               x 1
  Loop Error                               x 1
  Array Method Error                       x 1
  Object / Class Error                     x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * String Method Error
    ${ } only works inside backticks ` `. Check string method names (trim, toUpperCase).

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * JSON Error
    JSON keys need double quotes and there must be no comma before }. Use JSON.parse() to read it.

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * Array Method Error
    map() makes a new array (forEach doesn't). sort numbers with (a, b) => a - b. Give reduce a starting value 0.

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 13         Task 1                           3  (Logic Error, SyntaxError, TypeError)
  14 - 19        Task 2                           2  (String Method Error, SyntaxError)
  20 - 24        Task 3                           2  (SyntaxError)
  25 - 33        Task 4                           4  (Logic Error, SyntaxError, TypeError)
  34 - 40        Task 5                           3  (SyntaxError)
  41 - 47        Task 6                           2  (ReferenceError, SyntaxError)
  48 - 53        Task 7                           2  (JSON Error, TypeError)
  54 - 61        Task 8                           3  (Logic Error, SyntaxError)
  62 - 74        Task 9                           5  (Function / Return Error, ReferenceError, SyntaxError)
  75 - 88        Task 10                          1  (ReferenceError)
  89 - 98        Task 11                          4  (Loop Error, SyntaxError, TypeError)
  99 - 104       Task 12                          1  (Array Method Error)
  105 - 110      Task 13                          1  (SyntaxError)
  111 - 121      Task 14                          4  (Function / Return Error, ReferenceError, SyntaxError)
  128 - 133      Task 16                          2  (SyntaxError)
  134 - 141      Task 17                          4  (Logic Error, SyntaxError, TypeError)
  142 - 147      Task 18                          2  (Object / Class Error, String Method Error)
  148 - 163      Task 19                          4  (Logic Error, ReferenceError, SyntaxError)
  164 - 169      Task 20                          3  (Logic Error, ReferenceError, SyntaxError)
  170 - 178      Task 21                          3  (SyntaxError)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
