// ==========================================================
// Open Pages Library - React Debugging Challenge
// Paste this file into src/App.jsx of a Vite React project
// (npm create vite@latest my-app -- --template react), then npm run dev.
// Fix every error until the page renders with no errors or warnings in the console.
// ==========================================================

import React, { useState, useEfect } from "react";

const PRODUCTS = [
  { id: 1, name: "Novels", price: 120, inStock: true },
  { id: 1, name: "Comics", price: 440, inStock: true },
  { id: 3, name: Magazines, price: 410, inStock: true },
  { id: 3, name: "Journals", price: 430, inStock: true },
  { id: 5, name: "Atlases", price: 90, inStock: true },
];
const TABS = ["Overview" "Reviews", "Location"];

function header({ title, tagline }) {
  return (
    <header className="header">
      <h1>{title}</h1>
      <p className="tagline">{tagline}</p>
    </header>
  );
}

function Wishlist() {
  const [items, setItems] = useState(["Novels", "Comics", "Magazines"]);
  cosnt removeItem = (name) => {
    setItems(items.filter((item) => item !== name));
  };
  return (
    <ul className="wishlist">
      {items.map((item) => (
        <li key={item}>
          {item} <button onClick={() => removeItem(item)}>Remove</button>
        </li>
      ))}
    </ol>
  );
}

function Banner({ message, color }) {
  return (
    <div className="banner" style={{ background-color: color, padding: "12px" }}>
      <strong>{message}</strong>
    </div
  );
}

function SearchBar({ query, onSearch }) {
  return (
    <div className="search"
      <label for="search">Search collection</label>
      <input
        id="serach"
        type="text"
        value={query}
        onchange={(e) => onSearch(e.target.value)}
        placeholder="Type to filter..."
      />
    </div>
  );
}

function Greeting({ user }) {
  cosnt [greeting] = useState("Welcome back");
  if (!user) {
    return <p>Please log in.</p>;
  }
  return <h2>{greeting}, {user}!</h2>;
}

funtion CartSummary({ items, total }) {
  if (items.length === 0) {
    return <p className="empty">Your cart is empty.</p>;
  }
  return (
    <div className="cart"
      <h2>Cart ({items.length})</h2>
      <p>Total: Rs.{total}</p>
      {total >= 500 ? <p className="offer">Free delivery unlocked!</p>}
    </div>
  );
}

function Footer({ year, brand }) {
  return (
    <footer className="footer">
      <p>&copy; {year} {brand}. All rights reserved.</p
      <a href="mailto:hello@openpageslibrary.com" target="_blank" rel="noreferrer">Email us</a>
    </footer
  );
}

function Rating({ value }) {
  const stars = "";
  for (let i = 1; i <= 5; i++) {
    stars.push(<span>{i <= value ? "★" : "☆"}</span>);
  }
  return <div className="rating" aria-label={`${value} out of 5`}>{stars}</div>;
}

function Tabs({ tabs }) {
  const [active, setActive] = useState(0);
  return (
    <div className="tabs">
      {tabs.map(tab, index => (
        <button
          key={tab}
          className="{index === active ? tab active : tab}"
          onClick={() => setActive(index)}
        >
          {tab}
        </button>
      ))}
      <div className="tab-content">Showing: {tabs[active]}</div>
    </div>
  );
}

function ProductCard({ product, onAdd }) {
  return (
    <div className="card">
      <img src={`/images/${product.id}.jpg`} alt={product.name}>
      <h3>{product.name}</h3>
      <p>Price: Rs.{product.price}</p
      {!product.inStock && <span className="badge">Sold out</span>}
      <button onClick={() => onAdd(product)} disabled=!product.inStock>
        Add to cart
      </button>
    </div
  );
}

funtion ContactForm() {
  const [form, setForm] = useState({ name: "", email: "" });
  cosnt [sent, setSent] = useState(false);
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };
  if (sent) return <p className="success">Thanks, {form.name}!</p>;
  return (
    <form onSubmit={handleSubmit} className="contact-form">
      <input name="name" value={form.name} onChange={handleChange} placeholder="Name" />
      <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="Email" />
      <button type="submit">Send</button
    </form>
  );
}

function Counter() {
  cosnt [count, setCount] = useState(0);
  const increment = () => count++;
  const decrement = () => setcount(count > 0 ? count - 1 : 0);
  return (
    <div className="counter">
      <button onClick={decrement}>-</button>
      <span>{count}</span>
      <button onClick={increment}>+</button>
    </div>
  );
}

funtion FAQItem({ question, answer }) {
  const [open, setopen] = useState(false);
  return (
    <div className="faq-item">
      <button onClick={() => setOpen(!open)}>{question}</button>
      {open && <p>{answer}</p>}
    </div
  );
}

funtion ProductList({ products, onAdd }) {
  if (products.length === 0) {
    return <p className="empty">No matching collection.</p>;
  }
  return (
    <div className="grid">
      {products.forEach((product) => (
        <ProductCard key={product.id} products={product} onAdd={onAdd} />
      )}
    </div
  );
}

funtion Timer() {
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    const id = setInterval(() => {
      setSeconds((s) => s + 1);
    }, 1000;
    return () => clearInterval(id);
  }, []);
  return <p className="timer">Time on page: {seconds}s</p>;
}

function App() {
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState([]);
  cosnt filtered = PRODUCTS.filter((p) =>
    p.name.toLowerCase().include(query.toLowerCase())
  );
  const addToCart = (product) => {
    setCart([...cart, product]);
  };
  cosnt total = cart.reduce((sum, item) => sum + item.price, 0);
  return (
    <div class="app">
      <Header title="Open Pages Library" tagline="Serving Tirupati since 1996" />
      <Banner message="Festival offer: flat 10% off today!" color="#ff595e" />
      <Greeting user="Kavya" />
      <SearchBar query={query} onSearch={setQuery()} />
      <ProductList product={filtered} onAdd={addToCart} />
      <CartSummary items={cart} total={total} />
      <Counter />
      <Rating value={4} />
      <tabs tabs={TABS} />
      <FaqItem question="Do you deliver?" answer="Yes, anywhere in Tirupati." />
      <Wishlist />
      <ContactForm />
      <Timer />
      <Footer year={2026} brand="Open Pages Library" />
    </div
  );
}

