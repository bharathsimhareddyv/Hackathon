======================================================================
  HTML-13  |  HTML  |  Glow Studio
======================================================================

File to fix      : index.html
Errors hidden    : 55
Difficulty       : 37 / 100   (Easy 35, Medium 11, Hard 9)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. Open index.html in Chrome/Firefox.
  2. Go to https://validator.w3.org/#validate_by_input and paste the whole file. Fix the FIRST error, re-check, repeat.
  3. Then click every link and try the form.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 34
  Attribute Error                          x 7
  Link / Path Error                        x 3
  Accessibility Error                      x 3
  Nesting / Structure Error                x 2
  Form Error                               x 2
  Media Error                              x 1
  Duplicate ID Error                       x 1
  Table Error                              x 1
  Entity / Special Character Error         x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Attribute Error
    Every attribute looks like name="value" - check spelling (class, href, src, required), the = sign, and BOTH quotes. a/link use href; img/script/source use src.

  * Link / Path Error
    Click every link. #links must match an id exactly. URLs start with https:// . Paths use / not \. Email = mailto: , phone = tel: .

  * Accessibility Error
    Every <img> needs alt="...". A <label for="x"> must match an input with id="x". Every <iframe> needs a title.

  * Nesting / Structure Error
    Tags close in reverse order: <li><a>..</a></li>. Lists (ul/ol) can only contain <li>.

  * Form Error
    Valid input types: text, email, tel, date, checkbox... Form method is get or post. Button type is submit. Close <textarea>.

  * Media Error
    The attribute is 'controls'. MIME types: video/mp4, audio/mpeg.

  * Duplicate ID Error
    Use Ctrl+F on id=" - every id value must appear only once on the page.

  * Table Error
    Each row is <tr><td>..</td><td>..</td></tr>. A <th> closes with </th>, a <td> with </td>.

  * Entity / Special Character Error
    Codes like &copy; &amp; &#8377; must end with a semicolon. Write &lt; instead of a raw < in text.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  1 - 10         Head (document setup)            3  (Attribute Error, Syntax Error)
  11 - 22        Header & navigation              8  (Attribute Error, Link / Path Error, Syntax Error)
  23 - 34        Media section                    4  (Attribute Error, Media Error, Syntax Error)
  35 - 46        FAQ section                      5  (Attribute Error, Syntax Error)
  47 - 55        About section                    5  (Link / Path Error, Nesting / Structure Error, Syntax Error)
  56 - 62        Hero section                     1  (Syntax Error)
  63 - 77        Team section                     5  (Nesting / Structure Error, Syntax Error)
  78 - 93        Gallery                          5  (Accessibility Error, Duplicate ID Error, Syntax Error)
  94 - 113       Price table                      5  (Syntax Error, Table Error)
  114 - 138      Contact form                     5  (Accessibility Error, Form Error, Syntax Error)
  139 - 150      Products list                    7  (Attribute Error, Entity / Special Character Error, Syntax Error)
  151 - 158      Footer & closing tags            2  (Link / Path Error, Syntax Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
