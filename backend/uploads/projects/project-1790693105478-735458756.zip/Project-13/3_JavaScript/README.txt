======================================================================
  JS-13  |  JavaScript  |  Chai Point Corner
======================================================================

File to fix      : script.js
Errors hidden    : 56
Difficulty       : 39 / 100   (Easy 28, Medium 22, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. In a terminal in this folder run:   node script.js
  2. (or open index.html and press F12 > Console)
  3. Fix the error it reports, run again. Repeat until every task prints its 'Expected output'.

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  SyntaxError                              x 28
  ReferenceError                           x 9
  TypeError                                x 6
  Logic Error                              x 5
  Function / Return Error                  x 3
  Array Method Error                       x 2
  Loop Error                               x 1
  Object / Class Error                     x 1
  Type Coercion Error                      x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * SyntaxError
    Nothing prints? Read the SyntaxError line number. Look for missing ( ) [ ] { }, missing quotes, missing commas, and misspelled keywords (cosnt, funtion, lett).

  * ReferenceError
    'X is not defined' - check the spelling and capital letters of the name, and put quotes around text.

  * TypeError
    'x is not a function' - the method name is misspelled (check MDN). 'Assignment to constant' - change const to let.

  * Logic Error
    The code runs but prints the wrong value. Compare with the Expected output comment and check operators (>=, <=, +=, ===) and maths.

  * Function / Return Error
    A function must 'return' its answer. Methods need () to run: toUpperCase().

  * Array Method Error
    map() makes a new array (forEach doesn't). sort numbers with (a, b) => a - b. Give reduce a starting value 0.

  * Loop Error
    Loops should use i < array.length (not <=), spell .length correctly, and use for...of to get items.

  * Object / Class Error
    Property names are case-sensitive. In a class use 'constructor' and 'this.'. Arrays destructure with [ ].

  * Type Coercion Error
    Text from a form is a string. Convert it with Number() before adding or comparing.

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  8 - 19         Task 1                           5  (Logic Error, ReferenceError, SyntaxError)
  20 - 25        Task 2                           3  (Logic Error, ReferenceError, SyntaxError)
  26 - 33        Task 3                           3  (Function / Return Error, TypeError)
  34 - 39        Task 4                           1  (SyntaxError)
  40 - 49        Task 5                           4  (Function / Return Error, SyntaxError, TypeError)
  50 - 55        Task 6                           3  (Logic Error, SyntaxError)
  56 - 61        Task 7                           2  (Array Method Error, SyntaxError)
  62 - 77        Task 8                           1  (ReferenceError)
  78 - 90        Task 9                           2  (Function / Return Error, SyntaxError)
  91 - 97        Task 10                          3  (ReferenceError, SyntaxError)
  98 - 106       Task 11                          3  (Loop Error, ReferenceError, TypeError)
  107 - 117      Task 12                          3  (SyntaxError)
  118 - 123      Task 13                          2  (SyntaxError)
  124 - 129      Task 14                          2  (Logic Error, SyntaxError)
  130 - 143      Task 15                          3  (Object / Class Error, ReferenceError, SyntaxError)
  144 - 149      Task 16                          3  (Array Method Error, SyntaxError)
  150 - 157      Task 17                          2  (ReferenceError, SyntaxError)
  158 - 166      Task 18                          4  (Logic Error, SyntaxError, TypeError)
  167 - 172      Task 19                          2  (SyntaxError)
  173 - 179      Task 20                          2  (ReferenceError, SyntaxError)
  180 - 189      Task 21                          3  (SyntaxError, Type Coercion Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
