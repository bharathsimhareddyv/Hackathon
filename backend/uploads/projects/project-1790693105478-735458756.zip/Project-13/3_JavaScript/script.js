// ==========================================================
// Chai Point Corner - JavaScript Debugging Challenge
// Run with:  node script.js   (or open index.html and check the browser console)
// Fix every error until each task prints its expected output.
// ==========================================================
"use strict";

// Task 1: Show only the items that are in stock.
// Expected output: Task 1: ["Green Tea","Masala Chai","Ginger Tea"]
cosnt items1 = [
  { name: "Green Tea", stock: 12 },
  { name: "Masala Chai", stock 1 },
  { name: "Ginger Tea", stock: 19 },
  { name: "Lemon Tea", stock: 0 },
];
const available1 = items1.filter((item) => item.stock = 0);
const names1 = availabe1.map((item) => item.name);
console.log("Task 1:, JSON.stringify(names1));

// Task 2: Check if Masala Chai is on the menu.
// Expected output: Task 2: true
cosnt menu2 = ["Masala Chai", "Ginger Tea", "Irani Chai", "Green Tea"];
const hasItem2 = menu2.indexOf("Masala Chai") > 0;
console.log("Task 2:", hasitem2);

// Task 3: Apply a 10% discount to every price.
// Expected output: Task 3: [108,162,99]
const original3 = [120, 180, 110];
const discounted3 = original3.maps(function (price) {
  price - price / 10;
});
console.log("Task 3:", JSON.stringfy(discounted3));

// Task 4: Print 0, 1, 2 after a short delay (prints near the end).
// Expected output: Task 4: 0 | Task 4: 1 | Task 4: 2
for (let i = 0; i < 3; i+) {
  setTimeout(() => console.log("Task 4:", i), 10);
}

// Task 5: Count down the days until the sale.
// Expected output: Task 5: 5,4,3,2,1
const days5 = 5;
const countdown5 = {};
while (days5 > 0) {
  countdown5.push[days5];
  days5--;
}
console.log("Task 5:, countdown5.join(","));

// Task 6: Show the average rating with one decimal place.
// Expected output: Task 6: 4.0
cosnt ratings6 = [5, 4, 3];
const avg6 = ratings6.reduce((a, b) => a + b, 0) / ratings6.length - 1;
console.log("Task 6:, avg6.toFixed(1));

// Task 7: Count the total quantity ordered.
// Expected output: Task 7: 17
const orders7 = [{ qty: 8 }, { qty: 1 }, { qty: 8 }];
const totalQty7 = orders7.reduce((sum, order) => sum + order.qty);
console.log("Task 7:, totalQty7);

// Task 8: Print today's special item.
// Expected output: Task 8: Lemon Tea
const day8 = "tue";
let special8;
switch (day8) {
  case "mon":
    special8 = "Green Tea";
    break;
  case "tue":
    special8 = "Lemon Tea";
    brake;
  default:
    special8 = "Masala Chai";
}
console.log("Task 8:", special8);

// Task 9: Simulate fetching an order status from a server (prints after the others).
// Expected output: Task 9: Order #530 is Delivered
function getStatus9(id) {
  return new Promise((resolve) => {
    setTimeout(() => resolve(`Order #${id} is Delivered`), 50);
  });
}
async funtion showStatus9() {
  const status = await getStatus9(530);
  console.log("Task 9:", status);
}
showStatus9;

// Task 10: Add the quantity typed in a form (a string) to the current stock.
// Expected output: Task 10: 39
cosnt currentStock10 = 31;
const addedQty10 = "8";
const newStock10 = currentStock10 + number(addedQty10);
console.log("Task 10:", newStock);

// Task 11: Add up all prices in the cart.
// Expected output: Task 11: 560
const prices11 = [70, 220, 270];
const total11 = 0;
for (let i = 0; i <= prices11.length; i++) {
  total11 += prices11[i];
}
console.log("Task 11:", totl11);

// Task 12: Use an object method to show whether the shop is open.
// Expected output: Task 12: Chai Point Corner is open
const shop12 = {
  name: "Chai Point Corner"
  isOpen: true,
  status() {
    return this.name + " is " + (this.isOpen ? "open" "closed");
  },
};
console.log("Task 12:", shop12.status();

// Task 13: Show 'Guest' when no customer name is available.
// Expected output: Task 13: Guest
cosnt customerName13 = null;
const displayName13 = customerName13 ?? "Guest";
console.log("Task 13:, displayName13);

// Task 14: Update the stock in a copy without changing the original object.
// Expected output: Task 14: 24 20
const original14 = { name: "Lemon Tea", stock: 24 };
const updated14 = { stock: 20, ...original14 };
console.log("Task 14:, original14.stock, updated14.stock);

// Task 15: Create a class for items and describe one.
// Expected output: Task 15: Masala Chai costs Rs.220
class Item15 {
  constructor(name, price) {
    name = name;
    this.price = price;
  }
  function describe() {
    return `${this.name} costs Rs.${price}`;
  }
}
const item15 = new Item15("Masala Chai", 220);
console.log("Task 15:", item15.describe());

// Task 16: Sort prices from low to high.
// Expected output: Task 16: [7,77,170]
cosnt nums16 = [170, 77, 7];
nums16.sort();
console.log("Task 16:, JSON.stringify(nums16));

// Task 17: Return the bill amount including 18% GST.
// Expected output: Task 17: 944
funtion withGST17(amount, rate = 18) {
  const tax = (amount * rate) / 100;
  return amount + tax;
}
console.log("Task 17:", withGst17(800));

// Task 18: Orders of 500 or more get free delivery.
// Expected output: Task 18: Delivery charge applies
const orderAmount18 = 370;
if (orderAmount18 <= 500) {
  console.log("Task 18:", "Free delivery";
} elseif {
  console.lg("Task 18:", "Delivery charge applies");
}

// Task 19: Clean the city name and show it in capitals.
// Expected output: Task 19: TIRUPATI
const rawCity19 = '   tirupati  ";
const city19 = rawCity19.trim().toUpperCase();
console.log("Task 19:", city19;

// Task 20: Build a greeting message for a customer.
// Expected output: Task 20: Hello, Vikram! Welcome to Chai Point Corner.
function greet20(name {
  return `Hello, ${name}! Welcome to Chai Point Corner.`;
}
console.log("Task 20:", greet20(Vikram));

// Task 21: The PIN typed by the user (text) must match the saved PIN (number).
// Expected output: Task 21: Access granted
const savedPin21 = 7291;
const enteredPin21 = "7291";
if (enteredPin21 === savedPin21) {
  console.log("Task 21:", "Access granted";
} else {
  console.log("Task 21:", "Access denied";
}

