======================================================================
  CSS-13  |  CSS  |  Celebrate Events
======================================================================

File to fix      : style.css
Errors hidden    : 57
Difficulty       : 44 / 100   (Easy 20, Medium 31, Hard 6)

RULES
  - Fix each error on the line where it is. Do NOT add or delete lines.
  - Write down: line number, what was wrong, what you changed.

HOW TO RUN / CHECK
  1. index.html is CORRECT - do not edit it. Fix style.css only.
  2. Open index.html in the browser, press F12 > Elements, click an element and look at Styles: crossed-out lines are errors.
  3. Also paste style.css into https://jigsaw.w3.org/css-validator/#validate_by_input

----------------------------------------------------------------------
HINT LEVEL 1 - Error types in this page
----------------------------------------------------------------------
  Syntax Error                             x 17
  Property Name Error                      x 16
  Unit Error                               x 6
  Invalid Value Error                      x 5
  Selector Error                           x 4
  Comment Error                            x 3
  Pseudo-class / Pseudo-element Error      x 2
  Layout Error (Flexbox/Grid)              x 1
  CSS Variable Error                       x 1
  Color Error                              x 1
  Animation / Transition Error             x 1

----------------------------------------------------------------------
HINT LEVEL 2 - What to look for (one tip per error type)
----------------------------------------------------------------------
  * Syntax Error
    Check every tag: correct spelling, has both < and >, and closes with the SAME name (</p> for <p>). Void tags (img, input, hr, br, meta, link) never get a closing tag. In CSS: every property needs ':' and ';', and every '{' needs a '}'.

  * Property Name Error
    Look for misspelled property names (DevTools shows them crossed out). Use VS Code autocomplete to check spelling.

  * Unit Error
    Numbers need a unit (px, rem, %, s, deg) with NO space: 12px not 12 px. z-index and font-weight have NO unit.

  * Invalid Value Error
    The property is right but the value is not allowed. Check spelling of keywords (center, solid, absolute...), no commas in padding/margin, decimals use a dot.

  * Selector Error
    Open index.html next to style.css. Classes start with '.', ids with '#'. The name must match the HTML exactly.

  * Comment Error
    CSS comments are only /* ... */ . '//' is not a comment, and every /* needs a */.

  * Pseudo-class / Pseudo-element Error
    :hover :focus :nth-child() use ONE colon; ::before ::after use TWO. Check spelling.

  * Layout Error (Flexbox/Grid)
    display: flex / grid. Check spelling of flex values (space-between, center, column) and commas inside repeat() and minmax().

  * CSS Variable Error
    Variables are declared as --name: value; inside :root and used as var(--name). Names must match exactly.

  * Color Error
    Hex colours have 3 or 6 digits using only 0-9 and a-f. Check colour names and close rgba( ).

  * Animation / Transition Error
    @keyframes (with s), from/to, times need 's', and the animation name must match the keyframes name exactly (case!).

----------------------------------------------------------------------
HINT LEVEL 3 - Where the errors are (use only if you are stuck!)
----------------------------------------------------------------------
  Lines          Section                          Errors
  3 - 3          Comment: Theme Variables         1  (Comment Error)
  12 - 17        * { }                            1  (Selector Error)
  18 - 24        body { }                         2  (Property Name Error, Syntax Error)
  26 - 33        .site-header { }                 3  (Layout Error (Flexbox/Grid), Property Name Error, Syntax Error)
  34 - 40        .logo { }                        2  (Unit Error)
  41 - 46        .nav-links { }                   1  (Invalid Value Error)
  47 - 52        .nav-links a { }                 2  (Property Name Error, Syntax Error)
  53 - 57        .nav-links a:hover { }           3  (Property Name Error, Pseudo-class / Pseudo-element Error, Syntax Error)
  59 - 66        .hero { }                        2  (Syntax Error, Unit Error)
  67 - 72        .hero-title { }                  1  (Property Name Error)
  73 - 77        .hero-text { }                   1  (Syntax Error)
  78 - 78        Comment: Buttons                 1  (Comment Error)
  79 - 88        .btn { }                         1  (CSS Variable Error)
  89 - 93        .btn:hover { }                   1  (Color Error)
  94 - 98        .btn-primary { }                 1  (Invalid Value Error)
  99 - 99        Comment: Product Cards           1  (Comment Error)
  107 - 115      .card { }                        1  (Invalid Value Error)
  116 - 121      .card-img { }                    1  (Syntax Error)
  122 - 127      .card-title { }                  2  (Invalid Value Error, Property Name Error)
  128 - 132      .card-title::before { }          1  (Property Name Error)
  139 - 150      .badge { }                       5  (Property Name Error, Syntax Error)
  152 - 158      .price-table { }                 3  (Invalid Value Error, Syntax Error)
  159 - 165      .price-table th, .price-table td 3  (Property Name Error, Syntax Error)
  179 - 186      .contact-form input, .contact-fo 3  (Property Name Error, Selector Error)
  187 - 191      .contact-form input:focus { }    3  (Property Name Error, Pseudo-class / Pseudo-element Error, Syntax Error)
  193 - 199      .site-footer { }                 2  (Property Name Error)
  200 - 205      .social a { }                    3  (Property Name Error, Selector Error, Syntax Error)
  206 - 210      @keyframes fadeIn                2  (Animation / Transition Error, Unit Error)
  212 - 224      @media (responsive)              4  (Selector Error, Syntax Error, Unit Error)

Tip: fix errors from the TOP of the file downwards - one early mistake can
cause many confusing errors after it. Good luck!
